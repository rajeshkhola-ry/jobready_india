import 'package:archive/archive.dart';
import 'package:flutter/material.dart';
import '../Widgets/target_size_selector.dart';
import '../Widgets/apple_button.dart';
import '../Widgets/download_result_dialog.dart';
import '../Services/compression_service.dart';
import '../Services/file_picker_service.dart';
import '../Services/upload_context_service.dart';
import 'dart:typed_data';

/// Compression Tool Page - Main UI for file compression
/// User uploads file → Sets target size → Compresses → Downloads result
class CompressionToolPage extends StatefulWidget {
  const CompressionToolPage({super.key});

  @override
  State<CompressionToolPage> createState() => _CompressionToolPageState();
}

class _CompressionToolPageState extends State<CompressionToolPage> {
  final _compressionService = const CompressionService();

  int? _targetSizeBytes;
  String? _selectedUnit;
  bool _isCompressing = false;
  String _statusMessage = 'Ready to compress';

  List<PickedFileData> _selectedFiles = [];
  Uint8List? _selectedFile;
  String? _selectedFileName;

  // Compression result
  int? _originalFileSize;
  int? _compressedFileSize;
  double? _compressionRatio;
  Uint8List? _lastOutputBytes;
  String? _lastOutputName;

  @override
  void initState() {
    super.initState();
    _hydrateFromHomeUpload();
  }

  void _hydrateFromHomeUpload() {
    final files = UploadContextService.getCompatibleFiles([
      'pdf',
      'jpg',
      'jpeg',
      'png',
    ]);

    if (files.isEmpty) {
      return;
    }

    _selectedFiles = files;
    _selectedFile = files.first.bytes;
    _selectedFileName = files.first.name;
    _originalFileSize = files.first.size;
    _statusMessage = files.length == 1
        ? '✓ ${files.first.name} loaded from Home upload'
        : '✓ ${files.length} file(s) loaded from Home upload';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF1F2937),
        iconTheme: const IconThemeData(
          color: Color(0xFFFFC72C),
          size: 30,
        ),
        actions: [
          IconButton(
            tooltip: 'Home',
            onPressed: () {
              Navigator.of(context).pushNamedAndRemoveUntil('/home', (route) => false);
            },
            icon: const Icon(Icons.home_rounded, color: Color(0xFFFFC72C)),
          ),
        ],
        title: const Text(
          'Compress File',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Step 1: Upload File
            _buildStepCard(
              step: 1,
              title: 'Choose File',
              content: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (_selectedFile == null)
                    AppleButton(
                      label: 'Select File(s) to Compress',
                      icon: Icons.upload_file,
                      onPressed: _selectFile,
                      isPrimary: true,
                      isFullWidth: true,
                    )
                  else
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.green.shade50,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.green.shade300),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Icon(
                                Icons.check_circle,
                                color: Colors.green,
                                size: 24,
                              ),
                              const SizedBox(width: 12),
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      _selectedFiles.length > 1
                                          ? '${_selectedFiles.length} file(s) selected'
                                          : (_selectedFileName ?? 'File selected'),
                                      style: const TextStyle(
                                        fontSize: 14,
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    const SizedBox(height: 4),
                                    Text(
                                      _selectedFiles.length > 1
                                          ? 'Total size: ${_formatBytes(_selectedFiles.fold<int>(0, (sum, file) => sum + file.size))}'
                                          : 'Size: ${_formatBytes(_selectedFile!.length)}',
                                      style: const TextStyle(
                                        fontSize: 12,
                                        color: Colors.grey,
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              AppleButton(
                                label: 'Change',
                                onPressed: _selectFile,
                                isPrimary: false,
                                height: 36,
                              ),
                            ],
                          ),
                          if (_selectedFiles.length > 1) ...[
                            const SizedBox(height: 10),
                            ..._selectedFiles.take(4).map(
                              (file) => Padding(
                                padding: const EdgeInsets.only(bottom: 4),
                                child: Text(
                                  '${file.name} • ${_formatBytes(file.size)}',
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontSize: 12, color: Colors.grey),
                                ),
                              ),
                            ),
                            if (_selectedFiles.length > 4)
                              Text(
                                '+${_selectedFiles.length - 4} more file(s)',
                                style: const TextStyle(fontSize: 11, color: Colors.grey),
                              ),
                          ],
                        ],
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Step 2: Set Target Size
            if (_selectedFile != null)
              _buildStepCard(
                step: 2,
                title: 'Set Target Size',
                content: TargetSizeSelector(
                  onTargetSet: (targetBytes, unit) {
                    setState(() {
                      _targetSizeBytes = targetBytes;
                      _selectedUnit = unit;
                    });
                  },
                  initialValue: _targetSizeBytes != null
                      ? (_selectedUnit == 'KB'
                          ? _targetSizeBytes! ~/ 1024
                          : _targetSizeBytes! ~/ (1024 * 1024))
                      : null,
                  initialUnit: _selectedUnit ?? 'MB',
                ),
              ),
            const SizedBox(height: 20),

            // Step 3: Compress
            if (_selectedFile != null && _targetSizeBytes != null)
              _buildStepCard(
                step: 3,
                title: 'Compress File',
                content: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CompactTargetSizeDisplay(
                      targetBytes: _targetSizeBytes!,
                      unit: _selectedUnit ?? 'MB',
                    ),
                    const SizedBox(height: 16),
                    AppleButton(
                        label: _isCompressing
                          ? 'Compressing...'
                          : (_selectedFiles.length > 1 ? 'Start Batch Compression' : 'Start Compression'),
                      icon: _isCompressing ? Icons.hourglass_empty : Icons.compress,
                      onPressed: _isCompressing ? null : _startCompression,
                      isPrimary: true,
                      isFullWidth: true,
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 20),

            // Status
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _getStatusColor().withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: _getStatusColor(),
                ),
              ),
              child: Text(
                _statusMessage,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  color: _getStatusColor(),
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Results
            if (_compressedFileSize != null)
              _buildResultsCard(),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: Container(
          color: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: const Text(
            'getreadyjob.com',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: Color(0xFF1F4E79),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStepCard({
    required int step,
    required String title,
    required Widget content,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  color: const Color(0xFF0051BA),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Center(
                  child: Text(
                    '$step',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF1F2937),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          content,
        ],
      ),
    );
  }

  Widget _buildResultsCard() {
    final originalMB = _originalFileSize! / (1024 * 1024);
    final compressedMB = _compressedFileSize! / (1024 * 1024);
    final reduction =
        ((_originalFileSize! - _compressedFileSize!) / _originalFileSize!) * 100;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.green.shade50,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.green.shade300),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(
                Icons.check_circle,
                color: Colors.green,
                size: 24,
              ),
              SizedBox(width: 12),
              Text(
                'Compression Complete!',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.green,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _buildResultRow(
            'Original Size',
            '${originalMB.toStringAsFixed(2)} MB',
          ),
          const SizedBox(height: 8),
          _buildResultRow(
            'Compressed Size',
            '${compressedMB.toStringAsFixed(2)} MB',
            isHighlight: true,
          ),
          const SizedBox(height: 8),
          _buildResultRow(
            'Size Reduction',
            '${reduction.toStringAsFixed(1)}%',
            isHighlight: true,
          ),
          const SizedBox(height: 16),
          AppleButton(
            label: 'Download Compressed File',
            icon: Icons.download,
            onPressed: _downloadCompressed,
            isPrimary: true,
            isFullWidth: true,
          ),
        ],
      ),
    );
  }

  Widget _buildResultRow(String label, String value, {bool isHighlight = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 14,
            color: Colors.grey,
          ),
        ),
        Text(
          value,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: isHighlight ? const Color(0xFF007AFF) : Colors.black,
          ),
        ),
      ],
    );
  }

  void _selectFile() async {
    try {
      final files = await FilePickerService.pickMultipleFileData(
        allowedExtensions: ['pdf', 'jpg', 'jpeg', 'png'],
      );

      if (files.isEmpty) {
        setState(() {
          _statusMessage = 'File selection cancelled';
        });
        return;
      }

      setState(() {
        _selectedFiles = files;
        _selectedFile = files.first.bytes;
        _selectedFileName = files.first.name;
        _statusMessage = files.length == 1
            ? '✓ File selected: ${files.first.name}'
            : '✓ ${files.length} files selected';
        _originalFileSize = files.first.size;
        _compressedFileSize = null; // Reset previous results
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _startCompression() async {
    if (_selectedFile == null || _targetSizeBytes == null || _selectedFiles.isEmpty) return;

    setState(() {
      _isCompressing = true;
      _statusMessage = _selectedFiles.length > 1
          ? 'Compressing ${_selectedFiles.length} files...'
          : 'Compressing file...';
    });

    try {
      if (_selectedFiles.length == 1) {
        final selected = _selectedFiles.first;
        final compressed = await _compressSingleFile(selected);

        if (!mounted) return;

        setState(() {
          _compressedFileSize = compressed.length;
          _originalFileSize = selected.size;
          _compressionRatio = compressed.length / selected.size;
          _lastOutputBytes = compressed;
          _lastOutputName = selected.name;
          _isCompressing = false;
          _statusMessage = '✓ Compressed successfully to ${_formatBytes(compressed.length)}';
        });

        await showDialog(
          context: context,
          builder: (_) => DownloadResultDialog(
            outputFormat: 'Compressed File',
            fileName: selected.name,
            outputBytes: compressed,
          ),
        );
        return;
      }

      final archive = Archive();
      int totalOriginal = 0;
      int totalCompressed = 0;

      for (final file in _selectedFiles) {
        final compressed = await _compressSingleFile(file);
        totalOriginal += file.size;
        totalCompressed += compressed.length;
        archive.addFile(ArchiveFile(file.name, compressed.length, compressed));
      }

      final zipBytes = ZipEncoder().encode(archive);
      if (zipBytes == null) {
        throw Exception('Unable to build ZIP download.');
      }

      if (!mounted) return;

      setState(() {
        _compressedFileSize = totalCompressed;
        _originalFileSize = totalOriginal;
        _compressionRatio = totalCompressed / totalOriginal;
        _lastOutputBytes = Uint8List.fromList(zipBytes);
        _lastOutputName = 'jobready_compressed_files.zip';
        _isCompressing = false;
        _statusMessage = '✓ ${_selectedFiles.length} files compressed successfully';
      });

      await showDialog(
        context: context,
        builder: (_) => DownloadResultDialog(
          outputFormat: 'Compressed ZIP',
          fileName: 'jobready_compressed_files.zip',
          outputBytes: Uint8List.fromList(zipBytes),
        ),
      );
    } catch (e) {
      setState(() {
        _isCompressing = false;
        _statusMessage = '✗ Compression failed: $e';
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<Uint8List> _compressSingleFile(PickedFileData file) async {
    final lowerName = file.name.toLowerCase();
    if (lowerName.endsWith('.pdf')) {
      return _compressionService.compressPdf(file.bytes, _targetSizeBytes!, file.name);
    }

    if (lowerName.endsWith('.jpg') || lowerName.endsWith('.jpeg') || lowerName.endsWith('.png')) {
      return _compressionService.compressImage(file.bytes, _targetSizeBytes!, file.name);
    }

    throw Exception('Unsupported file for compression: ${file.name}');
  }

  void _downloadCompressed() {
    if (_lastOutputBytes == null || _lastOutputName == null) {
      return;
    }

    showDialog(
      context: context,
      builder: (_) => DownloadResultDialog(
        outputFormat: 'Compressed File',
        fileName: _lastOutputName!,
        outputBytes: _lastOutputBytes!,
      ),
    );
  }

  String _formatBytes(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(2)} KB';
    return '${(bytes / 1024 / 1024).toStringAsFixed(2)} MB';
  }

  Color _getStatusColor() {
    if (_statusMessage.startsWith('✓')) return Colors.green;
    if (_statusMessage.startsWith('✗')) return Colors.red;
    if (_statusMessage.startsWith('Compressing')) return Colors.blue;
    return Colors.grey;
  }
}
