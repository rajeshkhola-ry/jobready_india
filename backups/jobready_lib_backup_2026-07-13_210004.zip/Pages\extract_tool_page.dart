import 'package:archive/archive.dart';
import 'package:flutter/material.dart';
import 'dart:typed_data';
import '../Widgets/apple_button.dart';
import '../Widgets/download_result_dialog.dart';
import '../Services/conversion_service.dart';
import '../Services/pdf_editor_service.dart';
import '../Services/file_picker_service.dart';
import '../Services/upload_context_service.dart';

/// Extract Tool Page - Extract text, images, or pages from PDF
/// User selects file → Chooses extraction type → Extracts
class ExtractToolPage extends StatefulWidget {
  const ExtractToolPage({super.key});

  @override
  State<ExtractToolPage> createState() => _ExtractToolPageState();
}

class _ExtractToolPageState extends State<ExtractToolPage> {
  final PdfEditorService _pdfEditorService = const PdfEditorService();
  final ConversionService _conversionService = const ConversionService();
  String? _selectedFile;
  Uint8List? _selectedFileBytes;
  int? _selectedFileSize;
  String _extractType = 'text'; // 'text', 'images', 'pages'
  bool _isExtracting = false;
  String _statusMessage = 'Ready to extract';

  @override
  void initState() {
    super.initState();
    _hydrateFromHomeUpload();
  }

  void _hydrateFromHomeUpload() {
    final file = UploadContextService.getFirstCompatibleFile([
      'pdf',
      'jpg',
      'jpeg',
      'png',
      'doc',
      'docx',
    ]);
    if (file == null) {
      return;
    }

    _selectedFile = file.name;
    _selectedFileBytes = file.bytes;
    _selectedFileSize = file.size;
    _statusMessage = '✓ ${file.name} loaded from Home upload';
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF1F2937),
        iconTheme: const IconThemeData(
          color: Color(0xFFFFC72C),
          size: 30,
        ),
        actions: [
          IconButton(
            tooltip: 'Home',
            onPressed: () {
              Navigator.of(context).pushNamedAndRemoveUntil('/home', (route) => false);
            },
            icon: const Icon(Icons.home_rounded, color: Color(0xFFFFC72C)),
          ),
        ],
        title: const Text(
          'Extract from PDF',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Step 1: Select File
            _buildStepCard(
              step: 1,
              title: 'Select File',
              content: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  AppleButton(
                    label: 'Select PDF File',
                    icon: Icons.upload_file,
                    onPressed: _selectFile,
                    isPrimary: true,
                    isFullWidth: true,
                  ),
                  const SizedBox(height: 12),
                  if (_selectedFile != null)
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.green.shade50,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.green.shade300),
                      ),
                      child: Row(
                        children: [
                          const Icon(
                            Icons.check_circle,
                            color: Colors.green,
                            size: 20,
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  _selectedFile!,
                                  style: const TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                if (_selectedFileSize != null)
                                  Text(
                                    _formatBytes(_selectedFileSize!),
                                    style: const TextStyle(
                                      fontSize: 11,
                                      color: Colors.grey,
                                    ),
                                  ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Step 2: Choose Extraction Type
            if (_selectedFile != null)
              _buildStepCard(
                step: 2,
                title: 'What to Extract',
                content: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildExtractionOption('text', 'Extract Text', Icons.text_fields),
                    const SizedBox(height: 8),
                    _buildExtractionOption('images', 'Extract Images', Icons.image),
                    const SizedBox(height: 8),
                    _buildExtractionOption('pages', 'Extract as Images', Icons.photo),
                  ],
                ),
              ),
            const SizedBox(height: 20),

            // Step 3: Extract
            if (_selectedFile != null)
              _buildStepCard(
                step: 3,
                title: 'Extract',
                content: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: const Color(0xFF007AFF).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Row(
                        children: [
                          const Icon(
                            Icons.info,
                            color: Color(0xFF007AFF),
                            size: 20,
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              _getExtractionTypeLabel(),
                              style: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w500,
                                color: Color(0xFF007AFF),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    AppleButton(
                      label: _isExtracting ? 'Extracting...' : 'Start Extract',
                      icon: _isExtracting ? Icons.hourglass_empty : Icons.download,
                      onPressed: _isExtracting ? null : _startExtract,
                      isPrimary: true,
                      isFullWidth: true,
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 20),

            // Status
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _getStatusColor().withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _getStatusColor()),
              ),
              child: Text(
                _statusMessage,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  color: _getStatusColor(),
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        top: false,
        child: Container(
          color: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 8),
          child: const Text(
            'getreadyjob.com',
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: Color(0xFF1F4E79),
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildStepCard({
    required int step,
    required String title,
    required Widget content,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  color: const Color(0xFF0051BA),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Center(
                  child: Text(
                    '$step',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF1F2937),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          content,
        ],
      ),
    );
  }

  Widget _buildExtractionOption(String value, String label, IconData icon) {
    final isSelected = _extractType == value;
    return GestureDetector(
      onTap: () {
        setState(() {
          _extractType = value;
        });
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF007AFF).withOpacity(0.1) : Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: isSelected ? const Color(0xFF007AFF) : Colors.grey.shade300,
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              color: isSelected ? const Color(0xFF007AFF) : Colors.grey.shade600,
              size: 22,
            ),
            const SizedBox(width: 12),
            Text(
              label,
              style: TextStyle(
                fontSize: 14,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                color: isSelected ? const Color(0xFF007AFF) : Colors.grey.shade700,
              ),
            ),
            const Spacer(),
            if (isSelected)
              const Icon(
                Icons.check_circle,
                color: Color(0xFF007AFF),
                size: 22,
              ),
          ],
        ),
      ),
    );
  }

  void _selectFile() async {
    try {
      final file = await FilePickerService.pickFileData(
        allowedExtensions: ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx'],
      );

      if (file == null) {
        setState(() {
          _statusMessage = 'File selection cancelled';
        });
        return;
      }

      setState(() {
        _selectedFile = file.name;
        _selectedFileBytes = file.bytes;
        _selectedFileSize = file.size;
        _statusMessage = '✓ ${file.name} selected';
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _startExtract() async {
    if (_selectedFileBytes == null || _selectedFile == null) return;

    setState(() {
      _isExtracting = true;
      _statusMessage = 'Extracting $_extractType from PDF...';
    });

    try {
      if (_extractType == 'text') {
        final result = await _conversionService.convert(
          inputBytes: _selectedFileBytes!,
          inputFileName: _selectedFile!,
          outputFormat: 'Text (.txt)',
        );

        if (!result.success || result.outputBytes == null || result.outputFileName == null) {
          throw Exception(result.message);
        }

        if (!mounted) return;
        setState(() {
          _isExtracting = false;
          _statusMessage = '✓ Extraction completed successfully';
        });

        await showDialog(
          context: context,
          builder: (_) => DownloadResultDialog(
            outputFormat: 'Extracted Text',
            fileName: result.outputFileName!,
            outputBytes: result.outputBytes!,
          ),
        );
        return;
      }

      final pages = _extractType == 'pages'
          ? _pageNumbersFromSelection()
          : [for (var page = 1; page <= 5; page++) page];
      final files = await _pdfEditorService.extractPageImages(
        _selectedFileBytes!,
        _selectedFile!,
        pages,
      );
      if (files.isEmpty) {
        throw Exception('No extractable output was generated.');
      }

      final archive = Archive();
      for (final file in files) {
        archive.addFile(ArchiveFile(file.name, file.bytes.length, file.bytes));
      }
      final zipBytes = ZipEncoder().encode(archive);
      if (zipBytes == null) {
        throw Exception('Unable to create extraction ZIP output.');
      }

      if (!mounted) return;
      setState(() {
        _isExtracting = false;
        _statusMessage = '✓ Extraction completed successfully';
      });

      await showDialog(
        context: context,
        builder: (_) => DownloadResultDialog(
          outputFormat: 'Extracted Images',
          fileName: 'jobready_extracted_files.zip',
          outputBytes: Uint8List.fromList(zipBytes),
        ),
      );
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isExtracting = false;
        _statusMessage = '✗ Extraction failed: $e';
      });
    }
  }

  List<int> _pageNumbersFromSelection() {
    return [1];
  }

  String _getExtractionTypeLabel() {
    switch (_extractType) {
      case 'text':
        return 'Extract text from PDF';
      case 'images':
        return 'Extract images from PDF';
      case 'pages':
        return 'Extract pages as images';
      default:
        return 'Extract from PDF';
    }
  }

  Color _getStatusColor() {
    if (_statusMessage.startsWith('✓')) return Colors.green;
    if (_statusMessage.startsWith('✗')) return Colors.red;
    if (_statusMessage.startsWith('Extracting')) return Colors.blue;
    return Colors.grey;
  }

  String _formatBytes(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(2)} KB';
    return '${(bytes / 1024 / 1024).toStringAsFixed(2)} MB';
  }
}
