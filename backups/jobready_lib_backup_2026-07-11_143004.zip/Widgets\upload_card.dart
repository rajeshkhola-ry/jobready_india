import 'package:flutter/material.dart';

class UploadCard extends StatelessWidget {
  const UploadCard({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,

      padding: const EdgeInsets.all(35),

      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(22),
        border: Border.all(
          color: Colors.grey.shade300,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.grey.withOpacity(.12),
            blurRadius: 18,
            offset: const Offset(0, 8),
          ),
        ],
      ),

      child: Column(
        children: [

          const Icon(
            Icons.cloud_upload_rounded,
            size: 80,
            color: Color(0xFFFFC72C),
          ),

          const SizedBox(height: 18),

          const Text(
            "Drag & Drop your document here",
            style: TextStyle(
              fontSize: 24,
              fontWeight: FontWeight.bold,
              color: Color(0xFF1F2937),
            ),
          ),

          const SizedBox(height: 10),

          const Text(
            "PDF • Word • Excel • PowerPoint • Images",
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey,
            ),
          ),

          const SizedBox(height: 28),

          ElevatedButton.icon(
            onPressed: () {},

            icon: const Icon(Icons.upload_file),

            label: const Padding(
              padding: EdgeInsets.symmetric(
                horizontal: 20,
                vertical: 14,
              ),
              child: Text(
                "Choose File",
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),

            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFFFFC72C),
              foregroundColor: Colors.black,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
            ),
          ),
        ],
      ),
    );
  }
}