import 'dart:typed_data';

import 'package:flutter/material.dart';

import '../Services/file_picker_service.dart';
import 'selected_file_card.dart';

class UploadCardV2 extends StatefulWidget {
  const UploadCardV2({super.key});

  @override
  State<UploadCardV2> createState() => _UploadCardV2State();
}

class _UploadCardV2State extends State<UploadCardV2> {
  String? _fileName;
  String? _fileSize;
  Uint8List? _fileBytes;

  Future<void> _pickFile() async {
    final file = await FilePickerService.pickFile();

    if (file == null) return;

    final bytes = file.bytes;

    if (bytes == null) {
      return;
    }

    String size;

    if (file.size < 1024) {
      size = "${file.size} B";
    } else if (file.size < 1024 * 1024) {
      size = "${(file.size / 1024).toStringAsFixed(1)} KB";
    } else {
      size = "${(file.size / 1024 / 1024).toStringAsFixed(2)} MB";
    }

    setState(() {
      _fileName = file.name;
      _fileSize = size;
      _fileBytes = bytes;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 6,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(22),
      ),
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            const Icon(
              Icons.cloud_upload_outlined,
              size: 50,
              color: Color(0xFF1F4E79),
            ),

            const SizedBox(height: 18),

            const Text(
              "Upload your document",
              style: TextStyle(
                fontSize: 22,
                fontWeight: FontWeight.bold,
                color: Color(0xFF1F2937),
              ),
            ),

            const SizedBox(height: 10),

            const Text(
              "Drag & Drop your file here",
              style: TextStyle(
                fontSize: 14,
                color: Colors.black87,
              ),
            ),

            const SizedBox(height: 8),

            const Text(
              "Supported: PDF • DOCX • XLSX • PPT • JPG • PNG",
              textAlign: TextAlign.center,
              style: TextStyle(
                fontSize: 11,
                color: Colors.grey,
              ),
            ),

            const SizedBox(height: 25),

            SizedBox(
              width: 220,
              height: 50,
              child: ElevatedButton.icon(
                onPressed: _pickFile,
                icon: const Icon(Icons.upload_file),
                label: const Text(
                  "Browse Files",
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1F4E79),
                  foregroundColor: Colors.white,
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
              ),
            ),

            const SizedBox(height: 18),

            const Text(
              "Maximum file size: 100 MB",
              style: TextStyle(
                color: Colors.grey,
                fontSize: 13,
              ),
            ),

            const SizedBox(height: 20),

            if (_fileName != null && _fileBytes != null)
              SelectedFileCard(
                fileName: _fileName!,
                fileSize: _fileSize ?? "",
                fileBytes: _fileBytes!,
              ),
          ],
        ),
      ),
    );
  }
}