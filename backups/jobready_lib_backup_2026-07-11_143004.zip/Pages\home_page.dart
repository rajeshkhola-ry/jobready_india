import 'package:flutter/material.dart';

import '../Widgets/upload_card.dart';
import '../Widgets/tool_selector.dart';
import '../Widgets/offer_card.dart';
import '../Widgets/pricing_card.dart';
import '../Widgets/why_choose_card.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(

      backgroundColor: Colors.grey.shade100,

      appBar: AppBar(
        elevation: 0,
        backgroundColor: const Color(0xFF1F2937),

        title: const Text(
          "JOBREADY",
          style: TextStyle(
            color: Color(0xFFFFC72C),
            fontWeight: FontWeight.bold,
            fontSize: 28,
          ),
        ),
      ),

      body: SingleChildScrollView(

        padding: const EdgeInsets.all(25),

        child: Column(

          crossAxisAlignment: CrossAxisAlignment.start,

          children: [

            const Text(
              "🚀 What would you like to do today?",
              style: TextStyle(
                fontSize: 34,
                fontWeight: FontWeight.bold,
                color: Color(0xFF1F2937),
              ),
            ),

            const SizedBox(height: 12),

            const Text(
              "Upload your document once and choose any tool instantly.",
              style: TextStyle(
                fontSize: 18,
                color: Colors.grey,
              ),
            ),

            const SizedBox(height: 30),

            const UploadCard(),

            const SizedBox(height: 30),

            const ToolSelector(),

            const SizedBox(height: 30),

            const OfferCard(),

            const SizedBox(height: 30),

            const PricingCard(),

            const SizedBox(height: 30),

            const WhyChooseCard(),

            const SizedBox(height: 40),
          ],
        ),
      ),
    );
  }
}