# JOBREADY Pricing

Simple pricing. Powerful document tools.

Website: getreadyjob.com  
Support: hello@getreadyjob.com

Launch note: English only at first. More languages will be added in future updates.

---

## Choose Your Plan

### Free
$0/month

Best for getting started.

What you get:
- Core PDF tools for everyday use.
- Standard processing speed.
- Fair daily limits on AI and OCR features.
- Ads in reserved spaces only.

### Basic
$4.99/month or $49/year

Best for regular users and professionals.

What you get:
- No ads.
- Faster processing.
- Higher limits for AI, OCR, conversion, and batch tools.
- Larger file support.
- Priority support.

---

## Launch Offer

Founding User Promo: First 100 users get 40% off Basic for 3 months.

Promo code: JRLAUNCH100

Example:
- Regular Basic monthly: $4.99
- Promo monthly (first 3 months): about $2.99

Terms:
- First 100 successful paid signups only.
- One use per account.
- Valid for 30 days from launch.
- Cannot be combined with other offers.

---

## Why Users Love JOBREADY

- Easy for anyone to use.
- Clean and simple interface.
- Fast results for common document tasks.
- Trusted flows for convert, compress, merge, split, and OCR.

---

## Short FAQ

Is there only one paid plan?
- Yes. We keep pricing simple with one Basic plan for all.

Will free users still get useful tools?
- Yes. Core tools remain available on the Free plan.

Where do ads appear?
- Only in reserved spaces. Never over core actions or final results.

Can I apply promo codes in the app?
- Promo code support is planned as an in-app option.

---

Start free today on getreadyjob.com
