import 'package:flutter/material.dart';
import '../Widgets/upload_card_v2.dart';
import '../Widgets/tool_selector_v2.dart';

class HomePageV2 extends StatelessWidget {
  const HomePageV2({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FC),

      appBar: AppBar(
        backgroundColor: const Color(0xFF1F2937),
        centerTitle: true,
        toolbarHeight: 64,
        title: Row(
  mainAxisSize: MainAxisSize.min,
  children: [
    Container(
      width: 38,
      height: 38,
      decoration: const BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
      ),
      child: const Center(
        child: Text(
          "G",
          style: TextStyle(
            color: Color(0xFFFFC72C),
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    ),

    const SizedBox(width: 12),

    const Text(
      "JOBREADY",
      style: TextStyle(
        color: Colors.white,
        fontWeight: FontWeight.bold,
        letterSpacing: 2,
      ),
    ),
  ],
),
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 20),

        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            // Compact JOBREADY tagline strip
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(
                horizontal: 20,
                vertical: 8,
              ),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                gradient: const LinearGradient(
                  colors: [
                    Color(0xFF1F4E79),
                    Color(0xFFFFC72C),
                  ],
                ),
              ),
              child: const Text(
                "Upload Once.  •  Convert Anything.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.3,
                ),
              ),
            ),

            const SizedBox(height: 12),

            // Upload area + selected file card
            const UploadCardV2(),

            const SizedBox(height: 20),

            // Other document tools
            const ToolSelectorV2(),

            const SizedBox(height: 30),
          ],
        ),
      ),
    );
  }
}