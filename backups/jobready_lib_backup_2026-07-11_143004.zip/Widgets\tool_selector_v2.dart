import 'package:flutter/material.dart';

class ToolSelectorV2 extends StatelessWidget {
  const ToolSelectorV2({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 6,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),

        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            const Text(
  "✨ AI Premium Features",
  style: TextStyle(
    fontSize: 30,
    fontWeight: FontWeight.bold,
    color: Color(0xFF1F2A44),
  ),
),

const SizedBox(height: 6),

const Text(
  "Professional AI-powered tools for document optimization",
  style: TextStyle(
    fontSize: 16,
    color: Colors.grey,
  ),
),

const SizedBox(height: 20),

            GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),

              crossAxisCount: 2,

              crossAxisSpacing: 14,
              mainAxisSpacing: 14,

              childAspectRatio: 3.2,

              children: [

                _tool(
  Icons.picture_as_pdf,
  "Compress PDF",
  "Reduce PDF size in KB or MB while maintaining excellent quality.",
),

_tool(
  Icons.image,
  "Compress Images",
  "Reduce JPG & PNG size in KB or MB while preserving image quality.",
),

              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _tool(
    IconData icon,
    String title,
    String subtitle,
  ) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),

      onTap: () {},

      child: Container(
        height: 45,

        decoration: BoxDecoration(
          color: Colors.white,

          borderRadius: BorderRadius.circular(16),

          border: Border.all(
            color: Colors.grey.shade300,
          ),

          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 5,
              offset: const Offset(0, 2),
            ),
          ],
        ),

        padding: const EdgeInsets.symmetric(
          horizontal: 12,
          vertical: 4,
        ),

        child: Row(
          children: [

            CircleAvatar(
              radius: 15,

              backgroundColor:
                  const Color(0xFF1F4E79).withOpacity(.10),

              child: Icon(
                icon,
                size: 16,
                color: const Color(0xFF1F4E79),
              ),
            ),

            const SizedBox(width: 8),

            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment:
                    CrossAxisAlignment.start,

                children: [

                  Text(
                    title,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                    ),
                  ),

                  const SizedBox(height: 2),

                  Text(
                    subtitle,
                    style: const TextStyle(
                      fontSize: 11,
                      color: Colors.grey,
                    ),
                  ),

                ],
              ),
            ),

          ],
        ),
      ),
    );
  }
}