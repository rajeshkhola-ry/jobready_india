import 'package:flutter/material.dart';

class ToolSelector extends StatelessWidget {
  const ToolSelector({super.key});

  Widget buildButton(
      IconData icon,
      String title,
      Color color,
      ) {
    return Card(
      elevation: 3,

      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
      ),

      child: InkWell(
        borderRadius: BorderRadius.circular(16),

        onTap: () {},

        child: Padding(
          padding: const EdgeInsets.all(20),

          child: Column(
            children: [

              Icon(
                icon,
                size: 42,
                color: color,
              ),

              const SizedBox(height: 12),

              Text(
                title,
                textAlign: TextAlign.center,

                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {

    return Column(

      crossAxisAlignment: CrossAxisAlignment.start,

      children: [

        const Text(
          "Choose a Tool",
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.bold,
          ),
        ),

        const SizedBox(height: 20),

        GridView.count(

          shrinkWrap: true,

          physics: const NeverScrollableScrollPhysics(),

          crossAxisCount: 3,

          mainAxisSpacing: 15,

          crossAxisSpacing: 15,

          childAspectRatio: 1.3,

          children: [

            buildButton(
              Icons.picture_as_pdf,
              "PDF → Word",
              Colors.red,
            ),

            buildButton(
              Icons.description,
              "Word → PDF",
              Colors.blue,
            ),

            buildButton(
              Icons.image,
              "Image → PDF",
              Colors.orange,
            ),

            buildButton(
              Icons.merge_type,
              "Merge PDF",
              Colors.green,
            ),

            buildButton(
              Icons.content_cut,
              "Split PDF",
              Colors.purple,
            ),

            buildButton(
              Icons.compress,
              "Compress PDF",
              Colors.teal,
            ),
          ],
        ),
      ],
    );
  }
}