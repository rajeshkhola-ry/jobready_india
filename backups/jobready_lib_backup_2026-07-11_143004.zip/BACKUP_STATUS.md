# JOBREADY Backup Status

Last backup: Not run yet
Last backup file: Not available
Backup task: JOBREADY_Daily_Backup (daily at 21:00)
Backup folder: C:\JobReadyIndia\jobready_india\backups
