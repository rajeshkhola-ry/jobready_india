import 'package:flutter/material.dart';

class WhyChooseCard extends StatelessWidget {
  const WhyChooseCard({super.key});

  Widget item(
      IconData icon,
      String title,
      ) {
    return ListTile(
      leading: Icon(
        icon,
        color: const Color(0xFFFFC72C),
      ),

      title: Text(
        title,
        style: const TextStyle(
          fontWeight: FontWeight.bold,
          fontSize: 17,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {

    return Card(

      elevation: 3,

      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),

      child: Padding(

        padding: const EdgeInsets.all(22),

        child: Column(

          crossAxisAlignment: CrossAxisAlignment.start,

          children: [

            const Text(
              "Why Choose JOBREADY?",
              style: TextStyle(
                fontSize: 28,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 20),

            item(
              Icons.flash_on,
              "Lightning Fast Conversion",
            ),

            item(
              Icons.security,
              "100% Secure Documents",
            ),

            item(
              Icons.cloud_done,
              "Cloud Ready",
            ),

            item(
              Icons.workspace_premium,
              "Professional Quality Output",
            ),

            item(
              Icons.support_agent,
              "24×7 Customer Support",
            ),
          ],
        ),
      ),
    );
  }
}