import 'package:flutter/material.dart';

void main() {
runApp(const JobReadyApp());
}

class JobReadyApp extends StatelessWidget {
const JobReadyApp({super.key});

@override
Widget build(BuildContext context) {
return MaterialApp(
debugShowCheckedModeBanner: false,
title: 'JOBREADY',
theme: ThemeData(
scaffoldBackgroundColor: const Color(0xFFF8F9FA),
useMaterial3: true,
),
home: const HomePage(),
);
}
}

class HomePage extends StatelessWidget {
const HomePage({super.key});

void showMessage(BuildContext context, String title) {
ScaffoldMessenger.of(context).showSnackBar(
SnackBar(
content: Text('$title feature coming soon'),
),
);
}

@override
Widget build(BuildContext context) {
return Scaffold(
appBar: AppBar(
backgroundColor: const Color(0xFF1F2937),
centerTitle: true,
title: const Text(
'JOBREADY',
style: TextStyle(
color: Colors.white,
fontWeight: FontWeight.bold,
letterSpacing: 1.5,
),
),
),
body: SingleChildScrollView(
padding: const EdgeInsets.all(15),
child: Column(
crossAxisAlignment: CrossAxisAlignment.stretch,
children: [


        Container(
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(28),
            gradient: const LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFF003A70),
                Color(0xFFFFC72C),
              ],
            ),
          ),
          child: const Column(
            children: [

              CircleAvatar(
                radius: 30,
                backgroundColor: Colors.white,
                child: Text(
                  'G',
                  style: TextStyle(
                    fontSize: 26,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1F2937),
                  ),
                ),
              ),

              SizedBox(height: 18),

              Text(
                'JOBREADY',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 26,
                  fontWeight: FontWeight.w800,
                  letterSpacing: 2,
                ),
              ),

              SizedBox(height: 10),

              Text(
                'Smart Document & Career Toolkit',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white70,
                  fontSize: 18,
                ),
              ),

              SizedBox(height: 14),

              Text(
                "Tell us what you need.\nWe'll do the rest.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 16,
                ),
              ),
            ],
          ),
        ),

        const SizedBox(height: 20),

        Container(
          padding: const EdgeInsets.all(24),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(24),
            boxShadow: const [
              BoxShadow(
                color: Colors.black12,
                blurRadius: 12,
                offset: Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [

              Text(
                '🚀 What would you like to do today?',
                style: TextStyle(
                  fontSize: 26,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF1F2937),
                ),
              ),

              SizedBox(height: 24),

              Container(
height: 260,
child: GridView.count(
crossAxisCount: 2,
shrinkWrap: true,
physics: const NeverScrollableScrollPhysics(),
crossAxisSpacing: 12,
mainAxisSpacing: 12,
childAspectRatio: 1.2,
children: [
InkWell(
  onTap: () {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => const PdfToolsPage(),
      ),
    );
  },
  child: Card(
    elevation: 10,
    color: const Color(0xFFFFF0F0),
    shape: RoundedRectangleBorder(
      borderRadius: BorderRadius.circular(20),
    ),
    child: Column(
  mainAxisAlignment: MainAxisAlignment.start,
  children: const [
    SizedBox(height: 30),
Icon(Icons.picture_as_pdf, size: 50, color: Colors.red),
SizedBox(height: 8),
Text(
'PDF Tools',
style: TextStyle(fontWeight: FontWeight.bold),
),
Text('Convert & Edit'),
],
),
),
),

  Card(
    elevation: 10,
    color: const Color(0xFFF0FFF4),
    shape: RoundedRectangleBorder(
    borderRadius: BorderRadius.circular(20),
  ),
    child: Column(
  mainAxisAlignment: MainAxisAlignment.start,
  children: const [
    SizedBox(height: 30),
        Icon(Icons.photo, size: 50, color: Colors.green),
        SizedBox(height: 8),
        Text(
          'Photo Tools',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        Text('Resize & Repair'),
      ],
    ),
  ),

  Card(
    elevation: 10,
    color: const Color(0xFFF0F8FF),
  shape: RoundedRectangleBorder(
    borderRadius: BorderRadius.circular(20),
  ),
    child: Column(
  mainAxisAlignment: MainAxisAlignment.start,
  children: const [
    SizedBox(height: 30),
        Icon(Icons.folder, size: 50, color: Colors.blue),
        SizedBox(height: 8),
        Text(
          'Documents',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        Text('Organize Files'),
      ],
    ),
  ),

  Card(
    elevation: 10,
    color: const Color(0xFFFFF8E8),
  shape: RoundedRectangleBorder(
    borderRadius: BorderRadius.circular(20),
  ),
    child: Column(
  mainAxisAlignment: MainAxisAlignment.start,
  children: const [
    SizedBox(height: 30),
        Icon(Icons.work, size: 50, color: Colors.orange),
        SizedBox(height: 8),
        Text(
          'Career Tools',
          style: TextStyle(fontWeight: FontWeight.bold),
        ),
        Text('Resume & Jobs'),
      ],
    ),
  ),
],

),
),

            ],
          ),
        ),

        const SizedBox(height: 20),

        ElevatedButton(
          onPressed: () {},
          child: const Padding(
            padding: EdgeInsets.all(15),
            child: Text(
              'Launch Tools',
              style: TextStyle(fontSize: 18),
            ),
          ),
        ),

        const SizedBox(height: 25),

const Text(
'PDF Tools',
style: TextStyle(
fontSize: 24,
fontWeight: FontWeight.bold,
),
),

const SizedBox(height: 10),

FeatureTile(
icon: Icons.picture_as_pdf,
title: 'PDF to Word',
onTap: () => showMessage(context, 'PDF to Word'),
),

FeatureTile(
icon: Icons.description,
title: 'Word to PDF',
onTap: () => showMessage(context, 'Word to PDF'),
),

FeatureTile(
icon: Icons.image,
title: 'Image to PDF',
onTap: () => showMessage(context, 'Image to PDF'),
),

FeatureTile(
icon: Icons.merge_type,
title: 'Merge PDF',
onTap: () => showMessage(context, 'Merge PDF'),
),

FeatureTile(
icon: Icons.call_split,
title: 'Split PDF',
onTap: () => showMessage(context, 'Split PDF'),
),

FeatureTile(
icon: Icons.compress,
title: 'Compress PDF',
onTap: () => showMessage(context, 'Compress PDF'),
),

const SizedBox(height: 25),

const Text(
'Why Choose JOBREADY?',
style: TextStyle(
fontSize: 24,
fontWeight: FontWeight.bold,
),
),

const SizedBox(height: 10),

const Card(
child: Padding(
padding: EdgeInsets.all(15),
child: Column(
children: [
ListTile(
leading: Icon(Icons.speed),
title: Text('Fast Processing'),
),
ListTile(
leading: Icon(Icons.security),
title: Text('Secure Files'),
),
ListTile(
leading: Icon(Icons.public),
title: Text('Global Access'),
),
ListTile(
leading: Icon(Icons.phone_android),
title: Text('Mobile & Desktop Friendly'),
),
],
),
),
),

const SizedBox(height: 25),

const Text(
'Pricing Plans',
style: TextStyle(
fontSize: 24,
fontWeight: FontWeight.bold,
),
),

const SizedBox(height: 10),

pricingCard(
title: 'Weekly Pass',
price: '\$0.99',
color: Colors.green,
),

pricingCard(
title: 'Pro Monthly',
price: '\$2.99',
color: Colors.blue,
),

pricingCard(
title: 'Lifetime Pro',
price: '\$24.99',
color: Colors.orange,
),

const SizedBox(height: 25),

Container(
padding: const EdgeInsets.all(20),
decoration: BoxDecoration(
color: Colors.blue.shade50,
borderRadius: BorderRadius.circular(15),
),
child: const Column(
children: [
Text(
'Contact Us',
style: TextStyle(
fontSize: 22,
fontWeight: FontWeight.bold,
),
),
SizedBox(height: 10),
Text('Website: getreadyjob.com'),
Text('WhatsApp: +91 98991 15572'),
Text('Email: Coming Soon'),
],
),
),

const SizedBox(height: 25),

const Divider(),

const Center(
child: Column(
children: [
Text(
'JOBREADY',
style: TextStyle(
fontWeight: FontWeight.bold,
),
),
Text('Smart Document & Career Toolkit'),
Text('getreadyjob.com'),
SizedBox(height: 5),
Text('© 2026 JOBREADY'),
],
),
),

const SizedBox(height: 20),
],
),
),
);
}

Widget pricingCard({
required String title,
required String price,
required Color color,
}) {
return Card(
child: ListTile(
leading: Icon(
Icons.workspace_premium,
color: color,
),
title: Text(title),
trailing: Text(
price,
style: TextStyle(
color: color,
fontWeight: FontWeight.bold,
fontSize: 18,
),
),
),
);
}
}

class FeatureTile extends StatelessWidget {
final IconData icon;
final String title;
final VoidCallback onTap;

const FeatureTile({
super.key,
required this.icon,
required this.title,
required this.onTap,
});

@override
Widget build(BuildContext context) {
return Card(
elevation: 3,
child: ListTile(
leading: Icon(
icon,
size: 30,
color: Colors.blue,
),
title: Text(title),
trailing: const Icon(Icons.arrow_forward_ios),
onTap: onTap,
),
);
}
}

class PdfToolsPage extends StatelessWidget {
  const PdfToolsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF1F2937),
        title: const Text(
          'PDF Tools',
          style: TextStyle(color: Colors.white),
        ),
      ),

      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [

            ElevatedButton(
              onPressed: () {},
              child: const Text('PDF to Word'),
            ),

            const SizedBox(height: 10),

            ElevatedButton(
              onPressed: () {},
              child: const Text('Word to PDF'),
            ),

            const SizedBox(height: 10),

            ElevatedButton(
              onPressed: () {},
              child: const Text('Merge PDF'),
            ),

            const SizedBox(height: 10),

            ElevatedButton(
              onPressed: () {},
              child: const Text('Split PDF'),
            ),

            const SizedBox(height: 10),

            ElevatedButton(
              onPressed: () {},
              child: const Text('Compress PDF'),
            ),
          ],
        ),
      ),
    );
  }
}