import 'package:flutter/material.dart';
void main() {
  runApp(const JobReadyApp());
}
class JobReadyApp extends StatelessWidget {
  const JobReadyApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'JOBREADY',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const HomePage(),
    );
  }
}
class HomePage extends StatelessWidget {
  const HomePage({super.key});
  void showMessage(BuildContext context, String title) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('$title feature coming soon'),
      ),
    );
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('JOBREADY'),
        centerTitle: true,
        backgroundColor: const Color(0xFF1565C0),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(15),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [

            // Hero Section
            Container(
              padding: const EdgeInsets.all(25),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(20),
                gradient: const LinearGradient(
                  colors: [
                    Color(0xFF1565C0),
                    Color(0xFFFFC107),
                  ],
                ),
              ),
              child: const Column(
                children: [
                  Icon(
                    Icons.public,
                    color: Colors.white,
                    size: 70,
                  ),
                  SizedBox(height: 15),
                  Text(
                    'JOBREADY',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 32,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'The Fastest PDF Toolkit for Global Users',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 18,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text(
                    'Convert • Merge • Split • Compress',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 20),

            ElevatedButton(
              onPressed: () {},
              child: const Padding(
                padding: EdgeInsets.all(15),
                child: Text(
                  'Convert PDFs Instantly',
                  style: TextStyle(fontSize: 18),
                ),
              ),
            ),

            const SizedBox(height: 25),

            const Text(
              'PDF Tools',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 10),

            FeatureTile(
              icon: Icons.picture_as_pdf,
              title: 'PDF to Word',
              onTap: () => showMessage(context, 'PDF to Word'),
            ),

            FeatureTile(
              icon: Icons.description,
              title: 'Word to PDF',
              onTap: () => showMessage(context, 'Word to PDF'),
            ),

            FeatureTile(
              icon: Icons.image,
              title: 'Image to PDF',
              onTap: () => showMessage(context, 'Image to PDF'),
            ),

            FeatureTile(
              icon: Icons.merge_type,
              title: 'Merge PDF',
              onTap: () => showMessage(context, 'Merge PDF'),
            ),

            FeatureTile(
              icon: Icons.call_split,
              title: 'Split PDF',
              onTap: () => showMessage(context, 'Split PDF'),
            ),

            FeatureTile(
              icon: Icons.compress,
              title: 'Compress PDF',
              onTap: () => showMessage(context, 'Compress PDF'),
            ),

            const SizedBox(height: 25),

            const Text(
              'Why Choose JOBREADY?',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 10),

            const Card(
              child: Padding(
                padding: EdgeInsets.all(15),
                child: Column(
                  children: [
                    ListTile(
                      leading: Icon(Icons.speed),
                      title: Text('Fast Processing'),
                    ),
                    ListTile(
                      leading: Icon(Icons.security),
                      title: Text('Secure Files'),
                    ),
                    ListTile(
                      leading: Icon(Icons.public),
                      title: Text('Global Access'),
                    ),
                    ListTile(
                      leading: Icon(Icons.phone_android),
                      title: Text('Mobile & Desktop Friendly'),
                    ),
                  ],
                ),
              ),
            ),

            const SizedBox(height: 25),

            const Text(
              'Pricing Plans',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 10),

            pricingCard(
              title: 'Weekly Pass',
              price: '\$0.99',
              color: Colors.green,
            ),

            pricingCard(
              title: 'Pro Monthly',
              price: '\$2.99',
              color: Colors.blue,
            ),

            pricingCard(
              title: 'Lifetime Pro',
              price: '\$24.99',
              color: Colors.orange,
            ),

            const SizedBox(height: 25),

            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                borderRadius: BorderRadius.circular(15),
              ),
              child: const Column(
                children: [
                  Text(
                    'Contact Us',
                    style: TextStyle(
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  SizedBox(height: 10),
                  Text('Website: getreadyjob.com'),
                  Text('WhatsApp: +91 98991 15572'),
                  Text('Email: Coming Soon'),
                ],
              ),
            ),

            const SizedBox(height: 25),

            const Divider(),

            const Center(
              child: Column(
                children: [
                  Text(
                    'JOBREADY',
                    style: TextStyle(
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text('The Fastest PDF Toolkit for Global Users'),
                  Text('getreadyjob.com'),
                  SizedBox(height: 5),
                  Text('© 2026 JOBREADY'),
                ],
              ),
            ),

            const SizedBox(height: 20),
          ],
        ),
      ),
    );
  }

  Widget pricingCard({
    required String title,
    required String price,
    required Color color,
  }) {
    return Card(
      child: ListTile(
        leading: Icon(
          Icons.workspace_premium,
          color: color,
        ),
        title: Text(title),
        trailing: Text(
          price,
          style: TextStyle(
            color: color,
            fontWeight: FontWeight.bold,
            fontSize: 18,
          ),
        ),
      ),
    );
  }
}

class FeatureTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;

  const FeatureTile({
    super.key,
    required this.icon,
    required this.title,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3,
      child: ListTile(
        leading: Icon(
          icon,
          size: 30,
          color: Colors.blue,
        ),
        title: Text(title),
        trailing: const Icon(Icons.arrow_forward_ios),
        onTap: onTap,
      ),
    );
  }
}