# JOBREADY Pricing and Promo Policy (One-Page)

Brand: JOBREADY  
Website: getreadyjob.com  
Support: hello@getreadyjob.com
Launch Language: English only (multilingual rollout planned)

Effective Date: 2026-07-11  
Version: 1.0

---

## 1) Simple Plans

### Free Plan - $0/month
Best for occasional use.

Includes:
- Core PDF tools with standard speed.
- Limited daily actions for AI and OCR features.
- Ads shown only in reserved ad spaces.

Limits (recommended launch defaults):
- AI actions: up to 5 per day.
- OCR actions: up to 10 per day.
- Max file size: up to 25 MB per file.
- Batch processing: limited.

### Basic Plan - $4.99/month or $49/year
One paid plan for all users.

Includes:
- No ads.
- Faster processing queue.
- Higher file size and daily usage limits.
- Better limits for AI, OCR, conversion, and batch actions.
- Priority support response.

Recommended Basic limits:
- AI actions: up to 100 per day.
- OCR actions: up to 200 per day.
- Max file size: up to 200 MB per file.
- Batch processing: enabled.

Note:
- Final limits can be tuned using analytics after first launch.

---

## 2) Advertisement Placement Policy

To keep the app clean and easy for everyone:
- Ads appear only in dedicated ad spaces.
- Ads must not block or interrupt Upload, Convert, Merge, Split, Compress, or Download actions.
- No full-screen ad before result delivery.
- No ad overlays on processing dialogs or output preview.

Goal:
- Maintain a neat, simple, and trustworthy user experience.

---

## 3) First 100 Users Promo Campaign

Campaign Name:
- First 100 Founding Users Offer

Promo Code (launch example):
- JRLAUNCH100

Offer Structure:
- 40% off Basic monthly for first 3 months.
- Standard pricing resumes after promo term.

Example Pricing:
- Normal monthly: $4.99
- Promo monthly: about $2.99

Eligibility Rules:
- First 100 successful paid signups only.
- 1 redemption per account.
- Payment method required.
- Non-transferable and cannot be combined with other offers.
- Valid for 30 days from public launch date.

Abuse Prevention:
- Duplicate account checks.
- Device/payment fingerprint checks where legally permitted.
- Automatic rejection for repeated suspicious attempts.

---

## 4) Future In-App Promo Code System (Planned)

Planned capabilities:
- Promo code field at checkout.
- Backend validation for:
  - Expiry date
  - Usage limit (global and per user)
  - Plan eligibility
  - Region or country restrictions
- Discount types:
  - Percentage discount (for example 10%, 25%, 40%)
  - Fixed discount (for example $1 or $5 off)
- Admin controls:
  - Create, edit, pause, disable, and archive promo codes
- Reporting:
  - Redemption rate
  - Conversion uplift
  - Revenue impact

---

## 5) Billing and Refund Basics (Starter)

Billing:
- Subscriptions renew automatically unless canceled.
- Users can cancel anytime; benefits continue until period end.

Refund suggestion (starter policy):
- Monthly plans: no partial refund after cycle starts.
- Annual plans: 7-day refund window for first purchase only.
- Abuse or repeated claims may be rejected after review.

Important:
- Final refund terms should be reviewed with legal/payment provider requirements.

---

## 6) In-App Copy (Ready to Use)

Headline:
- Simple pricing. Powerful document tools.

Free card subtitle:
- Start free with essential tools.

Basic card subtitle:
- Go ad-free with faster processing and higher limits.

Promo banner text:
- Founding Offer: First 100 users get 40% off Basic for 3 months.

Checkout helper text:
- Have a promo code? Enter it at checkout.

---

## 7) FAQ (Short)

Q: Why is there only one paid plan?
A: To keep pricing simple and easy to understand for all users.

Q: Will free users still get core tools?
A: Yes, core tools remain available with fair daily limits.

Q: Where will ads appear?
A: Only in reserved spaces, never over core actions or final results.

Q: Can I use more than one promo code?
A: At launch, promo codes are single-use and cannot be combined.

Q: Can this policy change later?
A: Yes, pricing and limits may be updated based on usage, feedback, and costs.

---

## 8) Launch Checklist for Pricing

- [ ] Confirm Free vs Basic feature gates.
- [ ] Configure promo code and usage cap (100 users).
- [ ] Test checkout with and without promo code.
- [ ] Validate ad placement rules in production UI.
- [ ] Publish pricing page and in-app pricing screen.
- [ ] Add support article for billing and promo terms.
- [ ] Keep all launch copy in English and localization-ready for future languages.

Prepared For: JOBREADY
