import 'package:flutter/material.dart';
import '../Pages/compression_benchmark_page.dart';

class ToolSelectorV2 extends StatelessWidget {
  const ToolSelectorV2({super.key});

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 6,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(20),
      ),
      child: Padding(
        padding: const EdgeInsets.all(20),

        child: LayoutBuilder(
          builder: (context, constraints) {
            final isWide = constraints.maxWidth >= 520;

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                const Text(
                  "✨ AI Premium Features",
                  style: TextStyle(
                    fontSize: 20,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1F2A44),
                  ),
                ),

                const SizedBox(height: 6),

                const Text(
                  "Professional AI-powered tools for document optimization",
                  style: TextStyle(
                    fontSize: 12,
                    color: Colors.grey,
                  ),
                ),

                const SizedBox(height: 16),

                if (isWide)
                  Row(
                    children: [
                      Expanded(
                        child: _tool(
                          Icons.picture_as_pdf,
                          "Compress PDF",
                          "Reduce PDF size without hurting quality.",
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: _tool(
                          Icons.image,
                          "Compress Images",
                          "Reduce JPG and PNG size with quality preserved.",
                        ),
                      ),
                    ],
                  )
                else ...[
                  _tool(
                    Icons.picture_as_pdf,
                    "Compress PDF",
                    "Reduce PDF size without hurting quality.",
                  ),
                  const SizedBox(height: 14),
                  _tool(
                    Icons.image,
                    "Compress Images",
                    "Reduce JPG and PNG size with quality preserved.",
                  ),
                ],

                const SizedBox(height: 12),
                Align(
                  alignment: Alignment.centerLeft,
                  child: TextButton.icon(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => const CompressionBenchmarkPage(),
                        ),
                      );
                    },
                    icon: const Icon(Icons.analytics_outlined, size: 18),
                    label: const Text(
                      'Run Benchmark',
                      style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    style: TextButton.styleFrom(
                      foregroundColor: const Color(0xFF1F4E79),
                      padding: const EdgeInsets.symmetric(
                        horizontal: 10,
                        vertical: 6,
                      ),
                    ),
                  ),
                ),
              ],
            );
          },
        ),
      ),
    );
  }

  Widget _tool(
    IconData icon,
    String title,
    String subtitle,
  ) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),

      onTap: () {},

      child: Container(
        height: 88,

        decoration: BoxDecoration(
          color: Colors.white,

          borderRadius: BorderRadius.circular(16),

          border: Border.all(
            color: Colors.grey.shade300,
          ),

          boxShadow: [
            BoxShadow(
                      color: Colors.black.withValues(alpha: 0.05),
              blurRadius: 5,
              offset: const Offset(0, 2),
            ),
          ],
        ),

        padding: const EdgeInsets.symmetric(
          horizontal: 10,
          vertical: 8,
        ),

        child: Row(
          children: [

            CircleAvatar(
                radius: 13,

              backgroundColor:
                  const Color(0xFF1F4E79).withValues(alpha: 0.10),

              child: Icon(
                icon,
                size: 14,
                color: const Color(0xFF1F4E79),
              ),
            ),

            const SizedBox(width: 8),

            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment:
                    CrossAxisAlignment.start,

                children: [

                  Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontWeight: FontWeight.bold,
                      fontSize: 11,
                    ),
                  ),

                  const SizedBox(height: 2),

                  Text(
                    subtitle,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                      fontSize: 10,
                      color: Colors.grey,
                    ),
                  ),

                ],
              ),
            ),

          ],
        ),
      ),
    );
  }
}
