import 'dart:convert';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart';
import 'package:pdf_text/pdf_text.dart';

import 'compression_service.dart';
import 'word_generator_service.dart';

class ConversionResult {
  final bool success;
  final String message;
  final Uint8List? outputBytes;
  final String? outputFileName;

  const ConversionResult({
    required this.success,
    required this.message,
    this.outputBytes,
    this.outputFileName,
  });
}

class ConversionService {
  const ConversionService();

  Future<ConversionResult> convert({
    required Uint8List inputBytes,
    required String inputFileName,
    required String outputFormat,
  }) async {
    try {
      await Future.delayed(const Duration(seconds: 2));

      final format = outputFormat.toLowerCase();

      switch (format) {
        case 'word (.docx)':
          if (!inputFileName.toLowerCase().endsWith('.pdf')) {
            return const ConversionResult(
              success: false,
              message: 'Word conversion currently supports only PDF input.',
            );
          }

          final String extractedText =
              await _extractTextFromPdf(inputBytes, inputFileName);

          final wordBytes = await const WordGeneratorService().createWordDocument(
            pdfFileName: inputFileName,
            extractedText: extractedText,
          );

          return ConversionResult(
            success: true,
            message: 'Word document created successfully.',
            outputBytes: wordBytes,
            outputFileName: _changeExtension(inputFileName, 'docx'),
          );

        case 'text (.txt)':
          if (!inputFileName.toLowerCase().endsWith('.pdf')) {
            return const ConversionResult(
              success: false,
              message: 'Text conversion currently supports only PDF input.',
            );
          }

          final String extractedText =
              await _extractTextFromPdf(inputBytes, inputFileName);

          return ConversionResult(
            success: true,
            message: 'Text file created successfully.',
            outputBytes: Uint8List.fromList(utf8.encode(extractedText)),
            outputFileName: _changeExtension(inputFileName, 'txt'),
          );

        case 'jpg images':
        case 'png images':
          return const ConversionResult(
            success: false,
            message: 'Image conversion is not yet supported.',
          );

        case 'compress pdf':
          if (!inputFileName.toLowerCase().endsWith('.pdf')) {
            return const ConversionResult(
              success: false,
              message: 'PDF compression currently supports only PDF input.',
            );
          }

          final compressedBytes = await CompressionService().compressPdf(
            inputBytes,
            0,
            inputFileName,
          );

          if (compressedBytes.isEmpty) {
            return const ConversionResult(
              success: false,
              message: 'PDF compression failed.',
            );
          }

          return ConversionResult(
            success: true,
            message: 'PDF compressed successfully.',
            outputBytes: compressedBytes,
            outputFileName: inputFileName,
          );

        default:
          return const ConversionResult(
            success: false,
            message: 'Unsupported conversion format.',
          );
      }
    } catch (e) {
      return ConversionResult(
        success: false,
        message: 'Conversion failed: $e',
      );
    }
  }

  String _changeExtension(
    String fileName,
    String newExtension,
  ) {
    final dotIndex = fileName.lastIndexOf('.');

    if (dotIndex == -1) {
      return '$fileName.$newExtension';
    }

    return '${fileName.substring(0, dotIndex)}.$newExtension';
  }

  Future<String> _extractTextFromPdf(
    Uint8List pdfBytes,
    String pdfName,
  ) async {
    if (kIsWeb) {
      return 'PDF text extraction is not supported on web. Run the app on mobile or desktop.';
    }

    final Directory tempDir = await getTemporaryDirectory();
    final File tempFile = File(path.join(
      tempDir.path,
      'pdf_extract_${DateTime.now().millisecondsSinceEpoch}_${pdfName.replaceAll(RegExp(r"[^a-zA-Z0-9._-]"), '_')}.pdf',
    ));

    await tempFile.writeAsBytes(pdfBytes, flush: true);

    try {
      final PDFDoc document = await PDFDoc.fromFile(tempFile);
      final String extractedText = await document.text;
      return extractedText.trim().isEmpty
          ? 'No readable text was found in the selected PDF file.'
          : extractedText;
    } catch (e) {
      return 'Unable to extract text from the selected PDF. Error: $e';
    } finally {
      try {
        await tempFile.delete();
      } catch (_) {
        // Ignore temporary delete errors.
      }
    }
  }
}