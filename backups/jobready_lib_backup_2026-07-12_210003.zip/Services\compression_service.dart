import 'dart:math';
import 'dart:typed_data';

import 'package:image/image.dart' as img;
import 'package:pdf/pdf.dart' as pdf;
import 'package:pdf_render/pdf_render.dart' as pdf_render;

class CompressionService {
  const CompressionService();

  Uint8List compressImage(
    Uint8List bytes,
    int targetBytes,
    String fileName,
  ) {
    final lowerName = fileName.toLowerCase();

    if (lowerName.endsWith('.png')) {
      return _compressPng(bytes, targetBytes);
    }

    if (lowerName.endsWith('.jpg') || lowerName.endsWith('.jpeg')) {
      return _compressJpeg(bytes, targetBytes);
    }

    return bytes;
  }

  Future<Uint8List> compressPdf(
    Uint8List bytes,
    int targetBytes,
    String fileName,
  ) async {
    if (bytes.length <= targetBytes) {
      return bytes;
    }

    final pdfDoc = await pdf_render.PdfDocument.openData(bytes);
    try {
      final outputPdf = pdf.PdfDocument();
      const maxRenderDimension = 1200;
      final pageCount = pdfDoc.pageCount;
      final pageTarget = max(1, (targetBytes / pageCount).floor());

      for (var pageIndex = 1; pageIndex <= pageCount; pageIndex++) {
        final page = await pdfDoc.getPage(pageIndex);

        final int originalWidth = page.width.round();
        final int originalHeight = page.height.round();
        final renderScale = min(
          1.0,
          maxRenderDimension / max(originalWidth, originalHeight),
        );

        final int renderWidth = max(1, (originalWidth * renderScale).round());
        final int renderHeight = max(1, (originalHeight * renderScale).round());

        final pageImage = await page.render(
          width: renderWidth,
          height: renderHeight,
          backgroundFill: true,
        );

        final image = img.Image.fromBytes(
          width: renderWidth,
          height: renderHeight,
          bytes: pageImage.pixels.buffer,
          bytesOffset: pageImage.pixels.offsetInBytes,
          numChannels: 4,
          order: img.ChannelOrder.rgba,
        );

        int quality = 80;
        Uint8List jpegBytes = Uint8List.fromList(
          img.encodeJpg(image, quality: quality),
        );
        while (quality > 30 && jpegBytes.length > pageTarget * 1.2) {
          quality -= 10;
          jpegBytes = Uint8List.fromList(
            img.encodeJpg(image, quality: quality),
          );
        }

        final outputPage = pdf.PdfPage(
          outputPdf,
          pageFormat: pdf.PdfPageFormat(page.width, page.height),
        );

        final graphics = outputPage.getGraphics();
        final pdfImage = pdf.PdfImage.jpeg(
          outputPdf,
          image: jpegBytes,
        );

        graphics.drawImage(
          pdfImage,
          0,
          0,
          page.width,
          page.height,
        );

        pageImage.dispose();
      }

      final compressedOutput = await outputPdf.save();
      return compressedOutput.length < bytes.length
          ? compressedOutput
          : bytes;
    } finally {
      await pdfDoc.dispose();
    }
  }

  Uint8List _compressJpeg(Uint8List bytes, int targetBytes) {
    final image = img.decodeImage(bytes);
    if (image == null) return bytes;

    int quality = 90;
    Uint8List result = bytes;

    while (quality >= 10) {
      final compressed = img.encodeJpg(image, quality: quality);
      if (compressed.length <= targetBytes || quality <= 10) {
        result = Uint8List.fromList(compressed);
        break;
      }
      quality -= 10;
    }

    return result;
  }

  Uint8List _compressPng(Uint8List bytes, int targetBytes) {
    final image = img.decodeImage(bytes);
    if (image == null) return bytes;

    for (final level in [9, 7, 5, 3, 1]) {
      final compressed = img.encodePng(image, level: level);
      if (compressed.length <= targetBytes) {
        return Uint8List.fromList(compressed);
      }
    }

    return bytes;
  }
}
