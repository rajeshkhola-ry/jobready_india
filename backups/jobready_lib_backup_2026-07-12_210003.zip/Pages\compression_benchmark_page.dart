import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';
import '../Services/compression_benchmark.dart';
import '../Widgets/apple_button.dart';

/// Compression Benchmark Control Page (Debug/Development)
/// Used for Day 2-3 baseline testing and tuning
class CompressionBenchmarkPage extends StatefulWidget {
  const CompressionBenchmarkPage({super.key});

  @override
  State<CompressionBenchmarkPage> createState() =>
      _CompressionBenchmarkPageState();
}

class _CompressionBenchmarkPageState extends State<CompressionBenchmarkPage> {
  final _benchmark = CompressionBenchmark();
  bool _isRunning = false;
  String _statusMessage = 'Ready to run benchmark';
  List<String> _reportLines = [];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF1F2937),
        title: const Text(
          'V1-C1 Compression Benchmark',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (kIsWeb) ...[
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(
                  color: Colors.orange.shade50,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.orange.shade300),
                ),
                child: const Text(
                  'Web runtime detected. Compression benchmark may be runtime-blocked by pdf_render plugin on web. Use desktop/mobile runtime for valid quality metrics.',
                  style: TextStyle(
                    fontSize: 13,
                    color: Colors.black87,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
              const SizedBox(height: 12),
            ],

            // Status Card
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.blue.shade50,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: Colors.blue.shade200),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Status',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    _statusMessage,
                    style: const TextStyle(
                      fontSize: 14,
                      color: Colors.black87,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Test Configuration
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: Colors.grey.shade100,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Benchmark Configuration',
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  _buildConfigRow(
                    'Small Files',
                    '100KB – 500KB',
                  ),
                  _buildConfigRow(
                    'Medium Files',
                    '5MB – 20MB',
                  ),
                  _buildConfigRow(
                    'Large Files',
                    '50MB – 100MB',
                  ),
                  const SizedBox(height: 8),
                  _buildConfigRow(
                    'Tolerance Threshold',
                    '85% (15% max quality loss)',
                    isHighlight: true,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Control Buttons
            Row(
              children: [
                Expanded(
                  child: AppleButton(
                    label: _isRunning ? 'Running...' : 'Run Benchmark',
                    icon: Icons.play_arrow,
                    onPressed: _isRunning ? null : _runBenchmark,
                    isPrimary: true,
                    height: 48,
                  ),
                ),
                const SizedBox(width: 12),
                AppleButton(
                  label: 'Clear',
                  icon: Icons.delete_outline,
                  onPressed: _isRunning ? null : _clearResults,
                  isPrimary: false,
                  height: 48,
                ),
              ],
            ),
            const SizedBox(height: 20),

            // Results Report
            if (_reportLines.isNotEmpty) ...[
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(16),
                decoration: BoxDecoration(
                  color: Colors.grey.shade900,
                  borderRadius: BorderRadius.circular(12),
                  border: Border.all(color: Colors.grey.shade700),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Benchmark Report',
                      style: TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Colors.green,
                        fontFamily: 'Courier',
                      ),
                    ),
                    const SizedBox(height: 12),
                    ..._reportLines
                        .map(
                          (line) => Text(
                            line,
                            style: const TextStyle(
                              fontSize: 12,
                              color: Colors.green,
                              fontFamily: 'Courier',
                            ),
                          ),
                        )
                        .toList(),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              AppleButton(
                label: 'Export to CSV',
                icon: Icons.download,
                onPressed: _exportResults,
                isPrimary: true,
                isFullWidth: true,
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildConfigRow(String label, String value, {bool isHighlight = false}) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: TextStyle(
              fontWeight: isHighlight ? FontWeight.bold : FontWeight.normal,
            ),
          ),
          Text(
            value,
            style: TextStyle(
              color: isHighlight ? Colors.red : Colors.grey.shade700,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  Future<void> _runBenchmark() async {
    setState(() {
      _isRunning = true;
      _statusMessage =
          kIsWeb
              ? 'Running benchmark in web diagnostic mode...'
              : 'Running benchmark suite...';
      _reportLines = [];
    });

    try {
      // Run benchmark with 2 files per category
      await _benchmark.runFullBenchmark(
        filesPerCategory: 2,
        useSyntheticFallbackOnRuntimeBlock: kIsWeb,
      );

      // Generate report
      final report = _benchmark.generateSummaryReport();
      final lines = report.split('\n');

      setState(() {
        _reportLines = lines;
        final hasSyntheticRows = _benchmark.results.any(
          (r) => r.runNote.startsWith('SYNTHETIC_FALLBACK:'),
        );

        _statusMessage = hasSyntheticRows
            ? '✓ Benchmark completed in synthetic fallback mode (web runtime)'
            : '✓ Benchmark completed successfully';
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('✓ Benchmark completed. Results ready for export.'),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      setState(() {
        _statusMessage = '✗ Error: $e';
        _reportLines = ['Error running benchmark:', e.toString()];
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('✗ Benchmark failed: $e'),
          backgroundColor: Colors.red,
        ),
      );
    } finally {
      setState(() {
        _isRunning = false;
      });
    }
  }

  Future<void> _exportResults() async {
    try {
      final csvFile = await _benchmark.exportToCsv();

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('✓ Results exported to: ${csvFile.path}'),
          backgroundColor: Colors.green,
          duration: const Duration(seconds: 3),
        ),
      );

      setState(() {
        _statusMessage = 'Results exported to CSV file';
      });
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('✗ Export failed: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _clearResults() {
    setState(() {
      _benchmark.clearResults();
      _reportLines = [];
      _statusMessage = 'Results cleared';
    });
  }

  @override
  void dispose() {
    CompressionBenchmark.cleanupBenchmarkDir();
    super.dispose();
  }
}
