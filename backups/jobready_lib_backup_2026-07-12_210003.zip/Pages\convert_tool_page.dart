import 'package:flutter/material.dart';
import 'dart:typed_data';
import '../Widgets/apple_button.dart';
import '../Services/file_picker_service.dart';

/// Convert Tool Page - File format conversion (PDF, Word, Excel, Images, etc.)
/// User selects input format → Output format → Converts
/// NO size picker (conversion only, not compression)
class ConvertToolPage extends StatefulWidget {
  const ConvertToolPage({super.key});

  @override
  State<ConvertToolPage> createState() => _ConvertToolPageState();
}

class _ConvertToolPageState extends State<ConvertToolPage> {
  String? _selectedInputFormat;
  String? _selectedOutputFormat;
  bool _isConverting = false;
  String _statusMessage = 'Ready to convert';

  Uint8List? _selectedFile;
  String? _selectedFileName;

  // Available format conversions
  static const Map<String, List<String>> formatConversions = {
    'PDF': ['Word (.docx)', 'Excel (.xlsx)', 'PowerPoint (.pptx)', 'Image (PNG)', 'Image (JPG)', 'Text (.txt)'],
    'Word': ['PDF', 'Excel (.xlsx)', 'Image (PNG)', 'Text (.txt)'],
    'Excel': ['PDF', 'CSV', 'Image (PNG)', 'Text (.txt)'],
    'Image': ['PDF', 'PNG', 'JPG', 'WebP', 'BMP'],
    'PowerPoint': ['PDF', 'Image (PNG)', 'Video (MP4)'],
  };

  static const Map<String, List<String>> inputExtensions = {
    'PDF': ['pdf'],
    'Word': ['doc', 'docx'],
    'Excel': ['xls', 'xlsx', 'csv'],
    'Image': ['jpg', 'jpeg', 'png', 'webp', 'bmp'],
    'PowerPoint': ['ppt', 'pptx'],
  };

  @override
  Widget build(BuildContext context) {
    final availableFormats = _selectedInputFormat == null
        ? const <String>[]
        : (formatConversions[_selectedInputFormat!] ?? const <String>[]);

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF1F2937),
        iconTheme: const IconThemeData(
          color: Color(0xFF0051BA),
        ),
        title: const Text(
          'Convert File',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final isWide = constraints.maxWidth >= 760;

          return SingleChildScrollView(
            child: ConstrainedBox(
              constraints: BoxConstraints(minHeight: constraints.maxHeight),
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
                      decoration: BoxDecoration(
                        color: const Color(0xFF007AFF).withOpacity(0.08),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: const Color(0xFF007AFF).withOpacity(0.25)),
                      ),
                      child: const Text(
                        '1. Select input format. 2. Select output format. 3. Choose file and convert. All steps stay on this page.',
                        style: TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF1F2937),
                        ),
                      ),
                    ),
                    const SizedBox(height: 14),
                    if (isWide)
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.stretch,
                        children: [
                          Expanded(
                            child: _buildToolPanel(
                              step: 1,
                              title: 'Input Format',
                              subtitle: 'Choose the file type you have',
                              child: _buildFormatGrid(
                                formats: formatConversions.keys.toList(),
                                isInput: true,
                                crossAxisCount: 2,
                                childAspectRatio: 2.8,
                              ),
                            ),
                          ),
                          Container(
                            width: 18,
                            margin: const EdgeInsets.symmetric(horizontal: 10),
                            alignment: Alignment.center,
                            child: Container(
                              width: 6,
                              height: double.infinity,
                              decoration: BoxDecoration(
                                color: const Color(0xFF003A70),
                                borderRadius: BorderRadius.circular(6),
                              ),
                            ),
                          ),
                          Expanded(
                            child: _buildToolPanel(
                              step: 2,
                              title: 'Output Format',
                              subtitle: 'Choose what you want to create',
                              child: _buildFormatGrid(
                                formats: availableFormats,
                                isInput: false,
                                crossAxisCount: 2,
                                childAspectRatio: 2.8,
                              ),
                              footer: _selectedInputFormat == null
                                  ? 'Select an input format first'
                                  : 'Target: ${_selectedInputFormat!} → ${_selectedOutputFormat ?? 'not selected'}',
                            ),
                          ),
                        ],
                      )
                    else
                      Column(
                        children: [
                          _buildToolPanel(
                            step: 1,
                            title: 'Input Format',
                            subtitle: 'Choose the file type you have',
                            child: _buildFormatGrid(
                              formats: formatConversions.keys.toList(),
                              isInput: true,
                              crossAxisCount: 3,
                              childAspectRatio: 2.2,
                            ),
                          ),
                          const SizedBox(height: 12),
                          Container(
                            height: 14,
                            width: double.infinity,
                            alignment: Alignment.center,
                            child: Container(
                              width: double.infinity,
                              height: 6,
                              decoration: BoxDecoration(
                                color: const Color(0xFF003A70),
                                borderRadius: BorderRadius.circular(6),
                              ),
                            ),
                          ),
                          const SizedBox(height: 12),
                          _buildToolPanel(
                            step: 2,
                            title: 'Output Format',
                            subtitle: 'Choose what you want to create',
                            child: _buildFormatGrid(
                              formats: availableFormats,
                              isInput: false,
                              crossAxisCount: 3,
                              childAspectRatio: 2.2,
                            ),
                            footer: _selectedInputFormat == null
                                ? 'Select an input format first'
                                : 'Target: ${_selectedInputFormat!} → ${_selectedOutputFormat ?? 'not selected'}',
                          ),
                        ],
                      ),
                    const SizedBox(height: 14),
                    _buildUploadPanel(),
                    const SizedBox(height: 12),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: _getStatusColor().withOpacity(0.08),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: _getStatusColor().withOpacity(0.4)),
                      ),
                      child: Text(
                        _statusMessage,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w600,
                          color: _getStatusColor(),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildToolPanel({
    required int step,
    required String title,
    required String subtitle,
    required Widget child,
    String? footer,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade300),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  color: const Color(0xFF0051BA),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Center(
                  child: Text(
                    '$step',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.bold,
                        color: Color(0xFF1F2937),
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      subtitle,
                      style: TextStyle(
                        fontSize: 12,
                        color: Colors.grey.shade600,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          child,
          if (footer != null) ...[
            const SizedBox(height: 10),
            Text(
              footer,
              style: TextStyle(
                fontSize: 12,
                color: Colors.grey.shade600,
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildUploadPanel() {
    final canPickFile = _selectedInputFormat != null && _selectedOutputFormat != null;
    final selectedExtensions = _selectedInputFormat == null
        ? const <String>[]
        : (inputExtensions[_selectedInputFormat!] ?? const <String>[]);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.grey.shade300),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.04),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 30,
                height: 30,
                decoration: BoxDecoration(
                  color: const Color(0xFF003A70),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: const Center(
                  child: Text(
                    '3',
                    style: TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              const Expanded(
                child: Text(
                  'Choose File and Convert',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF1F2937),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            canPickFile
                ? 'Pick a file that matches your input format, then convert it right here.'
                : 'Choose input and output formats first.',
            style: TextStyle(
              fontSize: 12,
              color: Colors.grey.shade600,
            ),
          ),
          const SizedBox(height: 10),
          if (_selectedFileName != null)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                color: Colors.green.withOpacity(0.08),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.green.shade300),
              ),
              child: Text(
                'Selected file: $_selectedFileName',
                style: const TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w600,
                  color: Colors.green,
                ),
              ),
            ),
          if (_selectedFileName != null) const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: AppleButton(
                  label: _isConverting ? 'Converting...' : 'Choose File',
                  icon: _isConverting ? Icons.hourglass_empty : Icons.upload_file,
                  onPressed: (_isConverting || !canPickFile) ? null : _pickFileAndConvert,
                  isPrimary: true,
                  isFullWidth: true,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: AppleButton(
                  label: _isConverting ? 'Working...' : 'Convert Now',
                  icon: Icons.auto_fix_high,
                  onPressed: (_isConverting || !canPickFile || _selectedFileName == null) ? null : _convertSelectedFile,
                  isPrimary: false,
                  isFullWidth: true,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            selectedExtensions.isEmpty
                ? 'Supported: choose input format first'
                : 'Supported: ${selectedExtensions.map((item) => '.${item.toUpperCase()}').join(', ')}',
            style: TextStyle(
              fontSize: 12,
              color: Colors.grey.shade600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFormatGrid({
    required List<String> formats,
    required bool isInput,
    int crossAxisCount = 3,
    double childAspectRatio = 1.6,
  }) {
    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: crossAxisCount,
      mainAxisSpacing: 6,
      crossAxisSpacing: 6,
      childAspectRatio: childAspectRatio,
      children: formats
          .map(
            (format) => _buildFormatButton(
              format: format,
              isInput: isInput,
            ),
          )
          .toList(),
    );
  }

  Widget _buildFormatButton({
    required String format,
    required bool isInput,
  }) {
    final isSelected = isInput
        ? _selectedInputFormat == format
        : _selectedOutputFormat == format;

    return GestureDetector(
      onTap: () {
        setState(() {
          if (isInput) {
            _selectedInputFormat = format;
            _selectedOutputFormat = null; // Reset output when input changes
          } else {
            _selectedOutputFormat = format;
          }
        });
      },
      child: Container(
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF007AFF) : Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(
            color: isSelected ? const Color(0xFF007AFF) : Colors.grey.shade300,
            width: isSelected ? 2 : 1,
          ),
          boxShadow: isSelected
              ? [
                  BoxShadow(
                    color: const Color(0xFF007AFF).withOpacity(0.3),
                    blurRadius: 8,
                    offset: const Offset(0, 2),
                  ),
                ]
              : [],
        ),
        child: Center(
          child: Text(
            format,
            textAlign: TextAlign.center,
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w600,
              color: isSelected ? Colors.white : Colors.grey.shade700,
            ),
          ),
        ),
      ),
    );
  }

  void _startConversion() {
    if (_selectedInputFormat == null || _selectedOutputFormat == null) return;

    _pickFileAndConvert();
  }

  Future<void> _pickFileAndConvert() async {
    try {
      final file = await FilePickerService.pickFile(
        allowedExtensions: inputExtensions[_selectedInputFormat!] ?? [],
      );

      if (file == null) {
        // User cancelled the picker
        setState(() {
          _statusMessage = 'File selection cancelled';
        });
        return;
      }
      final bytes = file.bytes;

      if (bytes == null) {
        setState(() {
          _statusMessage = '✗ Error: Could not read the file';
        });
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Error: Could not read file bytes'),
            backgroundColor: Colors.red,
          ),
        );
        return;
      }

      setState(() {
        _selectedFile = bytes;
        _selectedFileName = file.name;
        _statusMessage = 'File ready. Tap Convert Now to continue.';
      });
    } catch (e) {
      setState(() {
        _statusMessage = '✗ Error: $e';
      });
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _convertSelectedFile() async {
    if (_selectedFile == null || _selectedFileName == null) {
      setState(() {
        _statusMessage = 'Please choose a file first.';
      });
      return;
    }

    setState(() {
      _isConverting = true;
      _statusMessage = 'Converting $_selectedFileName to $_selectedOutputFormat...';
    });

    try {
      await Future.delayed(const Duration(seconds: 2));

      if (!mounted) return;

      setState(() {
        _isConverting = false;
        _statusMessage = '✓ Converted successfully';
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('✓ $_selectedFileName converted to $_selectedOutputFormat'),
          backgroundColor: Colors.green,
        ),
      );
    } catch (e) {
      if (!mounted) return;

      setState(() {
        _isConverting = false;
        _statusMessage = '✗ Error: $e';
      });
    }
  }

  Color _getStatusColor() {
    if (_statusMessage.startsWith('✓')) return Colors.green;
    if (_statusMessage.startsWith('✗')) return Colors.red;
    if (_statusMessage.startsWith('Converting')) return Colors.blue;
    return Colors.grey;
  }
}
