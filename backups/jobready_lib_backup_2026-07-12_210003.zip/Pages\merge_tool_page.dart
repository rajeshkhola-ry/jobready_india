import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:typed_data';
import '../Widgets/apple_button.dart';

/// Merge Tool Page - Combine multiple PDFs into one
/// User selects multiple files → Sets merge order → Merges
class MergeToolPage extends StatefulWidget {
  const MergeToolPage({super.key});

  @override
  State<MergeToolPage> createState() => _MergeToolPageState();
}

class _MergeToolPageState extends State<MergeToolPage> {
  List<String> _selectedFiles = [];
  List<Uint8List> _selectedFileBytes = [];
  bool _isMerging = false;
  String _statusMessage = 'Ready to merge';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF1F2937),
        iconTheme: const IconThemeData(
          color: Color(0xFF0051BA),
        ),
        title: const Text(
          'Merge PDFs',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Step 1: Select Files
            _buildStepCard(
              step: 1,
              title: 'Select Files',
              content: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  AppleButton(
                    label: 'Add PDF Files',
                    icon: Icons.add_circle,
                    onPressed: _selectFiles,
                    isPrimary: true,
                    isFullWidth: true,
                  ),
                  const SizedBox(height: 12),
                  if (_selectedFiles.isEmpty)
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(20),
                      decoration: BoxDecoration(
                        color: Colors.grey.shade100,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: Colors.grey.shade300),
                      ),
                      child: Center(
                        child: Column(
                          children: [
                            Icon(
                              Icons.description,
                              size: 48,
                              color: Colors.grey.shade400,
                            ),
                            const SizedBox(height: 12),
                            Text(
                              'No files selected',
                              style: TextStyle(
                                fontSize: 14,
                                color: Colors.grey.shade600,
                              ),
                            ),
                          ],
                        ),
                      ),
                    )
                  else
                    _buildFileList(),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Step 2: Merge Order
            if (_selectedFiles.isNotEmpty)
              _buildStepCard(
                step: 2,
                title: 'Merge Order',
                content: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Drag to reorder files (top to bottom)',
                      style: TextStyle(
                        fontSize: 13,
                        color: Colors.grey,
                      ),
                    ),
                    const SizedBox(height: 12),
                    _buildOrderList(),
                  ],
                ),
              ),
            const SizedBox(height: 20),

            // Step 3: Merge
            if (_selectedFiles.isNotEmpty)
              _buildStepCard(
                step: 3,
                title: 'Merge Files',
                content: AppleButton(
                  label: _isMerging ? 'Merging...' : 'Start Merge',
                  icon: _isMerging ? Icons.hourglass_empty : Icons.merge_type,
                  onPressed: _isMerging ? null : _startMerge,
                  isPrimary: true,
                  isFullWidth: true,
                ),
              ),
            const SizedBox(height: 20),

            // Status
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _getStatusColor().withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _getStatusColor()),
              ),
              child: Text(
                _statusMessage,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  color: _getStatusColor(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStepCard({
    required int step,
    required String title,
    required Widget content,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  color: const Color(0xFF0051BA),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Center(
                  child: Text(
                    '$step',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF1F2937),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          content,
        ],
      ),
    );
  }

  Widget _buildFileList() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: ListView.separated(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: _selectedFiles.length,
        separatorBuilder: (_, __) => Divider(height: 1, color: Colors.grey.shade200),
        itemBuilder: (context, index) {
          return ListTile(
            leading: Icon(
              Icons.description,
              color: Colors.grey.shade600,
            ),
            title: Text(
              _selectedFiles[index],
              style: const TextStyle(fontSize: 13),
            ),
            trailing: GestureDetector(
              onTap: () {
                setState(() {
                  _selectedFiles.removeAt(index);
                });
              },
              child: const Icon(
                Icons.close,
                color: Colors.red,
                size: 20,
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildOrderList() {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: ListView.separated(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        itemCount: _selectedFiles.length,
        separatorBuilder: (_, __) => Divider(height: 1, color: Colors.grey.shade200),
        itemBuilder: (context, index) {
          return ListTile(
            leading: Container(
              width: 28,
              height: 28,
              decoration: BoxDecoration(
                color: const Color(0xFF007AFF).withOpacity(0.1),
                borderRadius: BorderRadius.circular(6),
              ),
              child: Center(
                child: Text(
                  '${index + 1}',
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.bold,
                    color: Color(0xFF007AFF),
                  ),
                ),
              ),
            ),
            title: Text(
              _selectedFiles[index],
              style: const TextStyle(fontSize: 13),
            ),
            trailing: const Icon(
              Icons.drag_handle,
              color: Colors.grey,
              size: 20,
            ),
          );
        },
      ),
    );
  }

  void _selectFiles() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf'],
        allowMultiple: true,
      );

      if (result != null && result.files.isNotEmpty) {
        setState(() {
          _selectedFiles = result.files.map((f) => f.name).toList();
          _selectedFileBytes = result.files.map((f) => f.bytes!).toList();
          _statusMessage = '✓ ${result.files.length} files selected';
        });
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _startMerge() {
    if (_selectedFiles.isEmpty) return;

    setState(() {
      _isMerging = true;
      _statusMessage = 'Merging ${_selectedFiles.length} files...';
    });

    Future.delayed(const Duration(seconds: 3), () {
      setState(() {
        _isMerging = false;
        _statusMessage = '✓ Merge completed successfully';
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('✓ Files merged successfully'),
          backgroundColor: Colors.green,
        ),
      );
    });
  }

  Color _getStatusColor() {
    if (_statusMessage.startsWith('✓')) return Colors.green;
    if (_statusMessage.startsWith('✗')) return Colors.red;
    if (_statusMessage.startsWith('Merging')) return Colors.blue;
    return Colors.grey;
  }
}
