import 'package:flutter/material.dart';
import '../Widgets/offer_card.dart';
import '../Widgets/pricing_card.dart';
import '../Widgets/why_choose_card.dart';
import '../Widgets/upload_card.dart';
import '../Widgets/tool_selector.dart';
import '../Widgets/upload_card_v2.dart';
import '../Widgets/tool_selector_v2.dart';

class HomePageV2 extends StatelessWidget {
  const HomePageV2({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FC),

      appBar: AppBar(
        backgroundColor: const Color(0xFF1F2937),
        centerTitle: true,
        toolbarHeight: 64,
        title: Row(
  mainAxisSize: MainAxisSize.min,
  children: [
    Container(
      width: 38,
      height: 38,
      decoration: const BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
      ),
      child: const Center(
        child: Text(
          "G",
          style: TextStyle(
            color: Color(0xFFFFC72C),
            fontSize: 22,
            fontWeight: FontWeight.bold,
          ),
        ),
      ),
    ),

    const SizedBox(width: 12),

    const Text(
      "JOBREADY",
      style: TextStyle(
        color: Colors.white,
        fontWeight: FontWeight.bold,
        letterSpacing: 2,
      ),
    ),
  ],
),
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(14, 10, 14, 18),
        child: LayoutBuilder(
          builder: (context, constraints) {
            final isWide = constraints.maxWidth >= 1000;

            return Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(18),
                    gradient: const LinearGradient(
                      colors: [Color(0xFF1F4E79), Color(0xFFFFC72C)],
                    ),
                  ),
                  child: const Text(
                    "One screen. Two layouts. All JOBREADY tools.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Colors.white,
                      fontSize: 14,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.3,
                    ),
                  ),
                ),

                const SizedBox(height: 10),

                if (isWide)
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: const [
                      Expanded(child: _V1Column()),
                      SizedBox(width: 12),
                      Expanded(child: _V2Column()),
                    ],
                  )
                else ...[
                  const _V1Column(),
                  const SizedBox(height: 18),
                  const _V2Column(),
                ],

                const SizedBox(height: 14),

                const OfferCard(),
                const SizedBox(height: 10),
                const WhyChooseCard(),
                const SizedBox(height: 12),
                const PricingCard(
                  title: 'Starter',
                  price: 'Free',
                  color: Color(0xFF1F4E79),
                ),
                const PricingCard(
                  title: 'Premium',
                  price: 'Coming Soon',
                  color: Color(0xFFFFC72C),
                ),

                const SizedBox(height: 12),

                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(14),
                    border: Border.all(color: const Color(0xFFE5E7EB)),
                  ),
                  child: const Text(
                    "Version 1 is now live. Version 2 content is merged into the same screen for easier review.",
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: Color(0xFF374151),
                      fontSize: 12,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),

                const SizedBox(height: 8),
              ],
            );
          },
        ),
      ),
    );
  }
}

class _V1Column extends StatelessWidget {
  const _V1Column();

  @override
  Widget build(BuildContext context) {
    return const Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _SectionHeader(
          title: 'V1 Document Toolkit',
          subtitle: 'Classic upload-first workflow and core tools.',
        ),
        SizedBox(height: 12),
        UploadCard(),
        SizedBox(height: 16),
        ToolSelector(),
      ],
    );
  }
}

class _V2Column extends StatelessWidget {
  const _V2Column();

  @override
  Widget build(BuildContext context) {
    return const Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        _SectionHeader(
          title: 'V2 AI Premium Flow',
          subtitle: 'Modern card layout with benchmark-ready tools.',
        ),
        SizedBox(height: 12),
        UploadCardV2(),
        SizedBox(height: 16),
        ToolSelectorV2(),
      ],
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  final String subtitle;

  const _SectionHeader({
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Color(0xFF1F2937),
          ),
        ),
        const SizedBox(height: 4),
        Text(
          subtitle,
          style: const TextStyle(
            fontSize: 12,
            color: Colors.grey,
          ),
        ),
      ],
    );
  }
}
