/// API Configuration and Service Layer
/// Future-ready for advertisements, analytics, app links, and third-party integrations

enum ApiEnvironment { development, staging, production }

class ApiConfig {
  static const ApiEnvironment environment = ApiEnvironment.production;

  // ==================== BASE URLs ====================
  static String get baseUrl {
    switch (environment) {
      case ApiEnvironment.development:
        return 'http://localhost:8080/api/v1';
      case ApiEnvironment.staging:
        return 'https://staging-api.getreadyjob.com/api/v1';
      case ApiEnvironment.production:
        return 'https://api.getreadyjob.com/api/v1';
    }
  }

  // ==================== ANALYTICS ====================
  static const String analyticsEndpoint = '/analytics';
  static const String eventsEndpoint = '/events';

  // Supported events: app_open, tool_used, file_processed, error, ad_shown, etc.
  static const List<String> supportedEvents = [
    'app_open',
    'tool_used',
    'file_processed',
    'compression_completed',
    'conversion_completed',
    'merge_completed',
    'split_completed',
    'error_occurred',
    'ad_shown',
    'ad_clicked',
    'user_signup',
    'user_login',
  ];

  // ==================== ADVERTISEMENTS ====================
  /// Ad Network Configurations (ready for integration)
  static const String admobAppId = 'ca-app-pub-xxxxxxxxxxxxxxxx~yyyyyyyyyy'; // Update with real ID
  static const String admobBannerId = 'ca-app-pub-3940256099942544/6300978111'; // Test ID
  static const String admobInterstitialId = 'ca-app-pub-3940256099942544/1033173712'; // Test ID
  static const String admobRewardedId = 'ca-app-pub-3940256099942544/5224354917'; // Test ID

  /// Facebook Ads (future integration)
  static const String facebookAppId = 'YOUR_FACEBOOK_APP_ID';
  static const String facebookPlacementId = 'YOUR_FACEBOOK_PLACEMENT_ID';

  /// MoPub (future integration)
  static const String mopubAdUnitId = 'YOUR_MOPUB_AD_UNIT_ID';

  // ==================== APP LINKS & DEEPLINKS ====================
  static const String appLinkBaseUrl = 'https://getreadyjob.com';
  static const String appDeepLinkScheme = 'jobready://';

  static const Map<String, String> deepLinks = {
    'compress': 'jobready://tool/compress',
    'convert': 'jobready://tool/convert',
    'merge': 'jobready://tool/merge',
    'split': 'jobready://tool/split',
    'settings': 'jobready://settings',
    'about': 'jobready://about',
  };

  // ==================== EXTERNAL APP LINKS ====================
  static const String websiteUrl = 'https://getreadyjob.com';
  static const String supportEmailUrl = 'https://getreadyjob.com/support';
  static const String privacyPolicyUrl = 'https://getreadyjob.com/privacy';
  static const String termsOfServiceUrl = 'https://getreadyjob.com/terms';

  // Play Store / App Store Links
  static const String playStoreUrl =
      'https://play.google.com/store/apps/details?id=com.jobready.app';
  static const String appStoreUrl =
      'https://apps.apple.com/app/jobready/id1234567890';

  // ==================== SOCIAL MEDIA LINKS ====================
  static const Map<String, String> socialLinks = {
    'website': 'https://getreadyjob.com',
    'email': 'hello@getreadyjob.com',
    'twitter': 'https://twitter.com/getreadyjob',
    'facebook': 'https://facebook.com/getreadyjob',
    'instagram': 'https://instagram.com/getreadyjob',
    'linkedin': 'https://linkedin.com/company/getreadyjob',
  };

  // ==================== CRASH REPORTING ====================
  /// Firebase Crashlytics (ready for integration)
  static const String firebaseProjectId = 'jobready-production';
  static const bool enableCrashReporting = true;

  // ==================== FEATURE FLAGS ====================
  static const Map<String, bool> featureFlags = {
    'ads_enabled': true,
    'premium_enabled': true,
    'offline_mode': true,
    'dark_mode': true,
    'beta_features': false,
  };

  // ==================== API ENDPOINTS ====================
  /// Compression Service Endpoints
  static const String compressionEndpoint = '/files/compress';
  static const String compressionStatusEndpoint = '/files/compress/status';

  /// Conversion Service Endpoints
  static const String conversionEndpoint = '/files/convert';
  static const String conversionStatusEndpoint = '/files/convert/status';

  /// Merge Service Endpoints
  static const String mergeEndpoint = '/files/merge';
  static const String mergeStatusEndpoint = '/files/merge/status';

  /// Split Service Endpoints
  static const String splitEndpoint = '/files/split';
  static const String splitStatusEndpoint = '/files/split/status';

  /// User & Auth Endpoints
  static const String authEndpoint = '/auth';
  static const String userProfileEndpoint = '/user/profile';
  static const String userStatsEndpoint = '/user/stats';

  /// Feedback & Support
  static const String feedbackEndpoint = '/feedback';
  static const String bugReportEndpoint = '/bug-report';

  // ==================== TIMEOUT & RETRY CONFIG ====================
  static const Duration connectionTimeout = Duration(seconds: 30);
  static const Duration receiveTimeout = Duration(seconds: 30);
  static const int maxRetries = 3;
  static const Duration retryDelay = Duration(seconds: 2);

  // ==================== HEADERS ====================
  static const Map<String, String> defaultHeaders = {
    'Content-Type': 'application/json',
    'Accept': 'application/json',
    'User-Agent': 'JOBREADY/1.0 (Flutter)',
  };

  // ==================== VERSION INFO ====================
  static const String appVersion = '1.0.0';
  static const String apiVersion = 'v1';
  static const int buildNumber = 1;

  // ==================== RATE LIMITS ====================
  static const int maxCompressionPerDay = 100; // Free tier
  static const int maxConversionPerDay = 50; // Free tier
  static const int maxMergePerDay = 50; // Free tier
  static const int maxSplitPerDay = 50; // Free tier

  // ==================== FILE SIZE LIMITS ====================
  static const int maxFileSize = 500 * 1024 * 1024; // 500MB
  static const int maxCompressionTargetSize = 100 * 1024 * 1024; // 100MB
  static const int minCompressionTargetSize = 100 * 1024; // 100KB

  // ==================== PROMO & MONETIZATION ====================
  static const String promoCodeEndpoint = '/promo-codes';
  static const String subscriptionEndpoint = '/subscriptions';
  static const String purchaseEndpoint = '/purchases';

  /// Ad Placement Strategy
  static const Map<String, dynamic> adStrategy = {
    'banner_home': {'frequency': 'always', 'position': 'bottom'},
    'interstitial_after_compress': {'frequency': 'every_3rd_use', 'delay': 2000},
    'interstitial_after_convert': {'frequency': 'every_3rd_use', 'delay': 2000},
    'rewarded_after_5_uses': {'frequency': 'every_5th_use', 'reward': 'ad_free_hour'},
  };
}

/// API Service Manager - Centralized API handling
class ApiService {
  static const String logTag = 'ApiService';

  /// Log API request (for debugging/analytics)
  static Future<void> logApiRequest({
    required String endpoint,
    required String method,
    Map<String, dynamic>? data,
  }) async {
    print('[$logTag] $method $endpoint');
    if (data != null) {
      print('[$logTag] Payload: $data');
    }
  }

  /// Log API response
  static Future<void> logApiResponse({
    required String endpoint,
    required int statusCode,
    dynamic response,
  }) async {
    print('[$logTag] Response [$statusCode]: $endpoint');
    if (response != null) {
      print('[$logTag] Body: $response');
    }
  }

  /// Log analytics event
  static Future<void> logEvent({
    required String eventName,
    Map<String, dynamic>? parameters,
  }) async {
    if (!ApiConfig.supportedEvents.contains(eventName)) {
      print('[$logTag] Warning: Unknown event - $eventName');
      return;
    }

    print('[$logTag] Event logged: $eventName');
    if (parameters != null) {
      print('[$logTag] Parameters: $parameters');
    }

    // TODO: Send to Analytics endpoint
    // Example: POST /api/v1/analytics/events
  }

  /// Get compression estimate
  static Future<Map<String, dynamic>> getCompressionEstimate({
    required int originalSize,
    required int targetSize,
  }) async {
    // Placeholder for future API call
    return {
      'status': 'success',
      'estimate_time_seconds': 5,
      'quality_score': 92,
      'compression_ratio': 0.45,
    };
  }

  /// Check ad eligibility (for frequency capping)
  static Future<bool> isEligibleForAd({
    required String adPlacement,
  }) async {
    // TODO: Check against frequency cap rules
    return true;
  }

  /// Get promo code validation
  static Future<Map<String, dynamic>> validatePromoCode({
    required String promoCode,
  }) async {
    // Placeholder for promo validation
    return {
      'valid': true,
      'discount_percent': 20,
      'expiry_date': DateTime.now().add(Duration(days: 30)).toIso8601String(),
    };
  }

  /// Submit feedback
  static Future<bool> submitFeedback({
    required String feedbackText,
    required double rating,
  }) async {
    print('[$logTag] Submitting feedback: $feedbackText (Rating: $rating)');
    // TODO: POST to /api/v1/feedback
    return true;
  }

  /// Report bug
  static Future<bool> reportBug({
    required String bugDescription,
    required String stackTrace,
  }) async {
    print('[$logTag] Reporting bug: $bugDescription');
    // TODO: POST to /api/v1/bug-report
    return true;
  }
}

/// Example Usage
/*
// Logging an event
await ApiService.logEvent(
  eventName: 'compression_completed',
  parameters: {
    'original_size_mb': 50,
    'compressed_size_mb': 20,
    'quality_score': 92,
    'time_seconds': 5,
  },
);

// Getting compression estimate
final estimate = await ApiService.getCompressionEstimate(
  originalSize: 50 * 1024 * 1024,
  targetSize: 20 * 1024 * 1024,
);

// Checking ad eligibility
final canShowAd = await ApiService.isEligibleForAd(
  adPlacement: 'interstitial_after_compress',
);

// Validating promo code
final promoValidation = await ApiService.validatePromoCode(
  promoCode: 'SAVE20',
);
*/
