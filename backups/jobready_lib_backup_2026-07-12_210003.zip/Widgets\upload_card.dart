import 'package:flutter/material.dart';
import 'apple_button.dart';

class UploadCard extends StatelessWidget {
  final VoidCallback? onChooseFile;

  const UploadCard({super.key, this.onChooseFile});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFF1F2937),
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(.2),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        children: [
          const Icon(
            Icons.cloud_upload_rounded,
            size: 48,
            color: Color(0xFFFFCC00),
          ),
          const SizedBox(height: 8),
          const Text(
            "Drag & Drop your document here",
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 6),
          const Text(
            "PDF • Word • Excel • PowerPoint • Images",
            style: TextStyle(
              fontSize: 12,
              color: Colors.white70,
            ),
          ),
          const SizedBox(height: 14),
          AppleButton(
            label: "Choose File",
            icon: Icons.upload_file,
            onPressed: onChooseFile ?? () {},
            isPrimary: true,
            isFullWidth: true,
            height: 44,
            backgroundColor: const Color(0xFFFFCC00),
            foregroundColor: const Color(0xFF0051BA),
          ),
        ],
      ),
    );
  }
}
