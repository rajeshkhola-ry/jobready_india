import 'dart:convert';
import 'dart:typed_data';

import 'package:archive/archive.dart';
import 'package:docx_template/docx_template.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

class WordGeneratorService {
  const WordGeneratorService();

  Future<Uint8List> createWordDocument({
    required String pdfFileName,
    required String extractedText,
  }) async {
    try {
      debugPrint(
        'WORD STEP 1: Loading template.docx...',
      );

      final ByteData templateData =
          await rootBundle.load(
        'assets/template.docx',
      );

      debugPrint(
        'WORD STEP 2: Template loaded. '
        'Size: ${templateData.lengthInBytes} bytes',
      );

      // Create a completely independent
      // and growable List<int>.
      final Uint8List templateBytes =
          templateData.buffer.asUint8List(
        templateData.offsetInBytes,
        templateData.lengthInBytes,
      );

      final Uint8List mutableTemplateBytes =
          Uint8List.fromList(templateBytes);

      final String cleanText =
          extractedText.trim().isEmpty
              ? 'No readable text was found in the uploaded PDF.'
              : extractedText.trim();

      debugPrint(
        'WORD STEP 3: Mutable byte list created. '
        'Size: ${mutableTemplateBytes.length} bytes',
      );

      final bool templateHasTag =
          _templateHasTag(mutableTemplateBytes, 'document_content');
      if (!templateHasTag) {
        debugPrint(
          'WORD STEP 4: Template missing document_content tag. '
          'Using plain DOCX builder fallback.',
        );

        return _buildSimpleDocx(cleanText, pdfFileName);
      }

      final DocxTemplate? docx =
          await DocxTemplate.fromBytes(
        mutableTemplateBytes,
      );

      if (docx == null) {
        throw Exception(
          'Unable to load assets/template.docx',
        );
      }

      debugPrint(
        'WORD STEP 4: DOCX template parsed successfully.',
      );

      debugPrint(
        'WORD STEP 5: Preparing document content...',
      );

      final Content content = Content();

      content.add(
        TextContent(
          'document_content',
          cleanText,
        ),
      );

      debugPrint(
        'WORD STEP 6: Calling docx.generate()...',
      );

      final List<int>? generatedBytes =
          await docx.generate(
        content,
      );

      debugPrint(
        'WORD STEP 7: docx.generate() completed.',
      );

      if (generatedBytes == null || generatedBytes.isEmpty) {
        debugPrint(
          'WORD STEP 8: Generated docx from template was empty. '
          'Falling back to plain DOCX builder.',
        );

        return _buildSimpleDocx(cleanText, pdfFileName);
      }

      debugPrint(
        'WORD STEP 8: Word document generated successfully. '
        'Size: ${generatedBytes.length} bytes',
      );

      return Uint8List.fromList(
        generatedBytes,
      );
    } catch (e, stackTrace) {
      debugPrint(
        'WORD GENERATOR ERROR: $e',
      );

      debugPrint(
        'WORD GENERATOR STACK TRACE:\n$stackTrace',
      );

      throw Exception(
        'Word document generation failed: $e',
      );
    }
  }

  bool _templateHasTag(Uint8List bytes, String tagName) {
    try {
      final archive = ZipDecoder().decodeBytes(bytes, verify: true);
      for (final file in archive.files) {
        if (file.name == 'word/document.xml' && file.content is List<int>) {
          final String xml = utf8.decode(file.content as List<int>);
          return xml.contains(tagName);
        }
      }
    } catch (_) {
      // If we cannot inspect the template, fallback to plain DOCX.
    }
    return false;
  }

  Uint8List _buildSimpleDocx(String text, String pdfFileName) {
    String escapeXml(String value) {
      return value
          .replaceAll('&', '&amp;')
          .replaceAll('<', '&lt;')
          .replaceAll('>', '&gt;')
          .replaceAll('"', '&quot;')
          .replaceAll("'", '&apos;');
    }

    final escapedLines = text
        .split(RegExp(r'\r\n?|\n'))
        .map((line) => escapeXml(line))
        .toList();

    final buffer = StringBuffer();
    for (final line in escapedLines) {
      buffer.writeln(
        '    <w:p><w:r><w:t xml:space="preserve">$line</w:t></w:r></w:p>',
      );
    }

    final String sanitizedTitle = escapeXml(pdfFileName);
    final documentXml = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:body>
    <w:p>
      <w:pPr>
        <w:jc w:val="center"/>
      </w:pPr>
      <w:r>
        <w:rPr>
          <w:b/>
          <w:sz w:val="32"/>
        </w:rPr>
        <w:t xml:space="preserve">$sanitizedTitle</w:t>
      </w:r>
    </w:p>
    <w:p><w:r><w:t xml:space="preserve">Generated from PDF file: $sanitizedTitle</w:t></w:r></w:p>
    <w:p><w:r><w:t xml:space="preserve"/></w:r></w:p>
$buffer    <w:sectPr>
      <w:pgSz w:w="12240" w:h="15840"/>
      <w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" w:header="720" w:footer="720" w:gutter="0"/>
    </w:sectPr>
  </w:body>
</w:document>''';

    final contentTypes = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
</Types>''';

    final relsXml = '''<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
</Relationships>''';

    final archive = Archive();
    archive.addFile(ArchiveFile('[Content_Types].xml', utf8.encode(contentTypes).length, utf8.encode(contentTypes)));
    archive.addFile(ArchiveFile('_rels/.rels', utf8.encode(relsXml).length, utf8.encode(relsXml)));
    archive.addFile(ArchiveFile('word/document.xml', utf8.encode(documentXml).length, utf8.encode(documentXml)));

    final List<int>? encoded = ZipEncoder().encode(archive);
    return Uint8List.fromList(encoded ?? <int>[]);
  }
}