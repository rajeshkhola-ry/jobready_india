import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import '../Widgets/target_size_selector.dart';
import '../Widgets/apple_button.dart';
import '../Services/compression_service.dart';
import 'dart:typed_data';

/// Compression Tool Page - Main UI for file compression
/// User uploads file → Sets target size → Compresses → Downloads result
class CompressionToolPage extends StatefulWidget {
  const CompressionToolPage({super.key});

  @override
  State<CompressionToolPage> createState() => _CompressionToolPageState();
}

class _CompressionToolPageState extends State<CompressionToolPage> {
  final _compressionService = const CompressionService();

  int? _targetSizeBytes;
  String? _selectedUnit;
  bool _isCompressing = false;
  String _statusMessage = 'Ready to compress';

  Uint8List? _selectedFile;
  String? _selectedFileName;

  // Compression result
  int? _originalFileSize;
  int? _compressedFileSize;
  double? _compressionRatio;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF1F2937),
        iconTheme: const IconThemeData(
          color: Color(0xFF0051BA),
        ),
        title: const Text(
          'Compress File',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Step 1: Upload File
            _buildStepCard(
              step: 1,
              title: 'Choose File',
              content: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  if (_selectedFile == null)
                    AppleButton(
                      label: 'Select File to Compress',
                      icon: Icons.upload_file,
                      onPressed: _selectFile,
                      isPrimary: true,
                      isFullWidth: true,
                    )
                  else
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.green.shade50,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.green.shade300),
                      ),
                      child: Row(
                        children: [
                          const Icon(
                            Icons.check_circle,
                            color: Colors.green,
                            size: 24,
                          ),
                          const SizedBox(width: 12),
                          Expanded(
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text(
                                  _selectedFileName ?? 'File selected',
                                  style: const TextStyle(
                                    fontSize: 14,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                                const SizedBox(height: 4),
                                Text(
                                  'Size: ${_formatBytes(_selectedFile!.length)}',
                                  style: const TextStyle(
                                    fontSize: 12,
                                    color: Colors.grey,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          AppleButton(
                            label: 'Change',
                            onPressed: _selectFile,
                            isPrimary: false,
                            height: 36,
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Step 2: Set Target Size
            if (_selectedFile != null)
              _buildStepCard(
                step: 2,
                title: 'Set Target Size',
                content: TargetSizeSelector(
                  onTargetSet: (targetBytes, unit) {
                    setState(() {
                      _targetSizeBytes = targetBytes;
                      _selectedUnit = unit;
                    });
                  },
                  initialValue: _targetSizeBytes != null
                      ? (_selectedUnit == 'KB'
                          ? _targetSizeBytes! ~/ 1024
                          : _targetSizeBytes! ~/ (1024 * 1024))
                      : null,
                  initialUnit: _selectedUnit ?? 'MB',
                ),
              ),
            const SizedBox(height: 20),

            // Step 3: Compress
            if (_selectedFile != null && _targetSizeBytes != null)
              _buildStepCard(
                step: 3,
                title: 'Compress File',
                content: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    CompactTargetSizeDisplay(
                      targetBytes: _targetSizeBytes!,
                      unit: _selectedUnit ?? 'MB',
                    ),
                    const SizedBox(height: 16),
                    AppleButton(
                      label: _isCompressing ? 'Compressing...' : 'Start Compression',
                      icon: _isCompressing ? Icons.hourglass_empty : Icons.compress,
                      onPressed: _isCompressing ? null : _startCompression,
                      isPrimary: true,
                      isFullWidth: true,
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 20),

            // Status
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _getStatusColor().withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(
                  color: _getStatusColor(),
                ),
              ),
              child: Text(
                _statusMessage,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  color: _getStatusColor(),
                ),
              ),
            ),
            const SizedBox(height: 20),

            // Results
            if (_compressedFileSize != null)
              _buildResultsCard(),
          ],
        ),
      ),
    );
  }

  Widget _buildStepCard({
    required int step,
    required String title,
    required Widget content,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  color: const Color(0xFF0051BA),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Center(
                  child: Text(
                    '$step',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF1F2937),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          content,
        ],
      ),
    );
  }

  Widget _buildResultsCard() {
    final originalMB = _originalFileSize! / (1024 * 1024);
    final compressedMB = _compressedFileSize! / (1024 * 1024);
    final reduction =
        ((_originalFileSize! - _compressedFileSize!) / _originalFileSize!) * 100;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: Colors.green.shade50,
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: Colors.green.shade300),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Row(
            children: [
              Icon(
                Icons.check_circle,
                color: Colors.green,
                size: 24,
              ),
              SizedBox(width: 12),
              Text(
                'Compression Complete!',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: Colors.green,
                ),
              ),
            ],
          ),
          const SizedBox(height: 16),
          _buildResultRow(
            'Original Size',
            '${originalMB.toStringAsFixed(2)} MB',
          ),
          const SizedBox(height: 8),
          _buildResultRow(
            'Compressed Size',
            '${compressedMB.toStringAsFixed(2)} MB',
            isHighlight: true,
          ),
          const SizedBox(height: 8),
          _buildResultRow(
            'Size Reduction',
            '${reduction.toStringAsFixed(1)}%',
            isHighlight: true,
          ),
          const SizedBox(height: 16),
          AppleButton(
            label: 'Download Compressed File',
            icon: Icons.download,
            onPressed: _downloadCompressed,
            isPrimary: true,
            isFullWidth: true,
          ),
        ],
      ),
    );
  }

  Widget _buildResultRow(String label, String value, {bool isHighlight = false}) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(
          label,
          style: const TextStyle(
            fontSize: 14,
            color: Colors.grey,
          ),
        ),
        Text(
          value,
          style: TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.bold,
            color: isHighlight ? const Color(0xFF007AFF) : Colors.black,
          ),
        ),
      ],
    );
  }

  void _selectFile() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf', 'doc', 'docx', 'jpg', 'jpeg', 'png', 'pptx'],
      );

      if (result != null && result.files.isNotEmpty) {
        final file = result.files.first;
        final bytes = file.bytes;

        if (bytes != null) {
          setState(() {
            _selectedFile = bytes;
            _selectedFileName = file.name;
            _statusMessage = '✓ File selected: ${file.name}';
            _originalFileSize = bytes.length;
            _compressedFileSize = null; // Reset previous results
          });
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Error: Could not read file'),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  Future<void> _startCompression() async {
    if (_selectedFile == null || _targetSizeBytes == null) return;

    setState(() {
      _isCompressing = true;
      _statusMessage = 'Compressing file...';
    });

    try {
      final compressed = await _compressionService.compressPdf(
        _selectedFile!,
        _targetSizeBytes!,
        _selectedFileName ?? 'file.pdf',
      );

      setState(() {
        _compressedFileSize = compressed.length;
        _originalFileSize = _selectedFile!.length;
        _compressionRatio = compressed.length / _selectedFile!.length;
        _isCompressing = false;
        _statusMessage =
            '✓ Compressed successfully to ${_formatBytes(compressed.length)}';
      });
    } catch (e) {
      setState(() {
        _isCompressing = false;
        _statusMessage = '✗ Compression failed: $e';
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _downloadCompressed() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Download feature coming soon'),
      ),
    );
  }

  String _formatBytes(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(2)} KB';
    return '${(bytes / 1024 / 1024).toStringAsFixed(2)} MB';
  }

  Color _getStatusColor() {
    if (_statusMessage.startsWith('✓')) return Colors.green;
    if (_statusMessage.startsWith('✗')) return Colors.red;
    if (_statusMessage.startsWith('Compressing')) return Colors.blue;
    return Colors.grey;
  }
}
