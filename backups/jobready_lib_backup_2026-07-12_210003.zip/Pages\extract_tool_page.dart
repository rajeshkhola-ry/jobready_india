import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:typed_data';
import '../Widgets/apple_button.dart';

/// Extract Tool Page - Extract text, images, or pages from PDF
/// User selects file → Chooses extraction type → Extracts
class ExtractToolPage extends StatefulWidget {
  const ExtractToolPage({super.key});

  @override
  State<ExtractToolPage> createState() => _ExtractToolPageState();
}

class _ExtractToolPageState extends State<ExtractToolPage> {
  String? _selectedFile;
  Uint8List? _selectedFileBytes;
  String _extractType = 'text'; // 'text', 'images', 'pages'
  bool _isExtracting = false;
  String _statusMessage = 'Ready to extract';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF1F2937),
        iconTheme: const IconThemeData(
          color: Color(0xFF0051BA),
        ),
        title: const Text(
          'Extract from PDF',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Step 1: Select File
            _buildStepCard(
              step: 1,
              title: 'Select File',
              content: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  AppleButton(
                    label: 'Select PDF File',
                    icon: Icons.upload_file,
                    onPressed: _selectFile,
                    isPrimary: true,
                    isFullWidth: true,
                  ),
                  const SizedBox(height: 12),
                  if (_selectedFile != null)
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.green.shade50,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.green.shade300),
                      ),
                      child: Row(
                        children: [
                          const Icon(
                            Icons.check_circle,
                            color: Colors.green,
                            size: 20,
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              _selectedFile!,
                              style: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Step 2: Choose Extraction Type
            if (_selectedFile != null)
              _buildStepCard(
                step: 2,
                title: 'What to Extract',
                content: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildExtractionOption('text', 'Extract Text', Icons.text_fields),
                    const SizedBox(height: 8),
                    _buildExtractionOption('images', 'Extract Images', Icons.image),
                    const SizedBox(height: 8),
                    _buildExtractionOption('pages', 'Extract as Images', Icons.photo),
                  ],
                ),
              ),
            const SizedBox(height: 20),

            // Step 3: Extract
            if (_selectedFile != null)
              _buildStepCard(
                step: 3,
                title: 'Extract',
                content: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: const Color(0xFF007AFF).withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Row(
                        children: [
                          const Icon(
                            Icons.info,
                            color: Color(0xFF007AFF),
                            size: 20,
                          ),
                          const SizedBox(width: 8),
                          Expanded(
                            child: Text(
                              _getExtractionTypeLabel(),
                              style: const TextStyle(
                                fontSize: 13,
                                fontWeight: FontWeight.w500,
                                color: Color(0xFF007AFF),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(height: 16),
                    AppleButton(
                      label: _isExtracting ? 'Extracting...' : 'Start Extract',
                      icon: _isExtracting ? Icons.hourglass_empty : Icons.download,
                      onPressed: _isExtracting ? null : _startExtract,
                      isPrimary: true,
                      isFullWidth: true,
                    ),
                  ],
                ),
              ),
            const SizedBox(height: 20),

            // Status
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _getStatusColor().withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _getStatusColor()),
              ),
              child: Text(
                _statusMessage,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  color: _getStatusColor(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStepCard({
    required int step,
    required String title,
    required Widget content,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  color: const Color(0xFF0051BA),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Center(
                  child: Text(
                    '$step',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF1F2937),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          content,
        ],
      ),
    );
  }

  Widget _buildExtractionOption(String value, String label, IconData icon) {
    final isSelected = _extractType == value;
    return GestureDetector(
      onTap: () {
        setState(() {
          _extractType = value;
        });
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF007AFF).withOpacity(0.1) : Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: isSelected ? const Color(0xFF007AFF) : Colors.grey.shade300,
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Row(
          children: [
            Icon(
              icon,
              color: isSelected ? const Color(0xFF007AFF) : Colors.grey.shade600,
              size: 22,
            ),
            const SizedBox(width: 12),
            Text(
              label,
              style: TextStyle(
                fontSize: 14,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                color: isSelected ? const Color(0xFF007AFF) : Colors.grey.shade700,
              ),
            ),
            const Spacer(),
            if (isSelected)
              const Icon(
                Icons.check_circle,
                color: Color(0xFF007AFF),
                size: 22,
              ),
          ],
        ),
      ),
    );
  }

  void _selectFile() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf', 'jpg', 'jpeg', 'png', 'doc', 'docx'],
      );

      if (result != null && result.files.isNotEmpty) {
        final file = result.files.first;
        final bytes = file.bytes;

        if (bytes != null) {
          setState(() {
            _selectedFile = file.name;
            _selectedFileBytes = bytes;
            _statusMessage = '✓ ${file.name} selected';
          });
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Error: Could not read file'),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _startExtract() {
    setState(() {
      _isExtracting = true;
      _statusMessage = 'Extracting $_extractType from PDF...';
    });

    Future.delayed(const Duration(seconds: 3), () {
      setState(() {
        _isExtracting = false;
        _statusMessage = '✓ Extraction completed successfully';
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('✓ ${_getExtractionTypeLabel()} completed'),
          backgroundColor: Colors.green,
        ),
      );
    });
  }

  String _getExtractionTypeLabel() {
    switch (_extractType) {
      case 'text':
        return 'Extract text from PDF';
      case 'images':
        return 'Extract images from PDF';
      case 'pages':
        return 'Extract pages as images';
      default:
        return 'Extract from PDF';
    }
  }

  Color _getStatusColor() {
    if (_statusMessage.startsWith('✓')) return Colors.green;
    if (_statusMessage.startsWith('✗')) return Colors.red;
    if (_statusMessage.startsWith('Extracting')) return Colors.blue;
    return Colors.grey;
  }
}
