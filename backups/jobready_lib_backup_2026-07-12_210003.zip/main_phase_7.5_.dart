﻿// Starting file
// Phase 7.5
import 'package:flutter/material.dart';
import 'Pages/home_page.dart';
//
// ===============================
// GLOBAL RESUME DATA MODEL
// ===============================
//
class ResumeData {
  static String fullName = "RAJESH YADAV";
  static String jobTitle = "Cargo Revenue Accounting Specialist";
  static String email = "";
  static String phone = "";
  static String city = "";
  static String summary = "";
  static String experience = "";
  static String education = "";
//
  static List<String> skills = [
    "Cargo Accounting",
    "Revenue Accounting",
    "SAP",
    "Excel",
  ];
}
//
void main() {
  runApp(const JobReadyApp());
}
//
class JobReadyApp extends StatelessWidget {
  const JobReadyApp({super.key});
//
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'JOBREADY',
      theme: ThemeData(
        scaffoldBackgroundColor: const Color(0xFFF8F9FA),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}
