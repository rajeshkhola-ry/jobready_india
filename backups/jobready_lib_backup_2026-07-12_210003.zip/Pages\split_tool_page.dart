import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'dart:typed_data';
import '../Widgets/apple_button.dart';

/// Split Tool Page - Extract pages from PDF or split into multiple files
/// User selects file → Sets page ranges → Splits
class SplitToolPage extends StatefulWidget {
  const SplitToolPage({super.key});

  @override
  State<SplitToolPage> createState() => _SplitToolPageState();
}

class _SplitToolPageState extends State<SplitToolPage> {
  String? _selectedFile;
  Uint8List? _selectedFileBytes;
  int _totalPages = 0;
  String _splitMethod = 'range'; // 'range' or 'extract'
  List<String> _pageRanges = ['1-5']; // e.g., ['1-5', '10-15']
  TextEditingController _pageRangeController = TextEditingController();
  bool _isSplitting = false;
  String _statusMessage = 'Ready to split';

  @override
  void dispose() {
    _pageRangeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF1F2937),
        iconTheme: const IconThemeData(
          color: Color(0xFF0051BA),
        ),
        title: const Text(
          'Split PDF',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Step 1: Select File
            _buildStepCard(
              step: 1,
              title: 'Select File',
              content: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  AppleButton(
                    label: 'Select PDF File',
                    icon: Icons.upload_file,
                    onPressed: _selectFile,
                    isPrimary: true,
                    isFullWidth: true,
                  ),
                  const SizedBox(height: 12),
                  if (_selectedFile != null)
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        color: Colors.green.shade50,
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: Colors.green.shade300),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Row(
                            children: [
                              const Icon(
                                Icons.check_circle,
                                color: Colors.green,
                                size: 20,
                              ),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  _selectedFile!,
                                  style: const TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w600,
                                  ),
                                ),
                              ),
                            ],
                          ),
                          const SizedBox(height: 6),
                          Text(
                            'Total pages: $_totalPages',
                            style: const TextStyle(
                              fontSize: 12,
                              color: Colors.grey,
                            ),
                          ),
                        ],
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 20),

            // Step 2: Split Method
            if (_selectedFile != null)
              _buildStepCard(
                step: 2,
                title: 'Split Method',
                content: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildMethodButton('range', 'By Page Range'),
                    const SizedBox(height: 8),
                    _buildMethodButton('extract', 'Extract Specific Pages'),
                  ],
                ),
              ),
            const SizedBox(height: 20),

            // Step 3: Configure Split
            if (_selectedFile != null)
              _buildStepCard(
                step: 3,
                title: 'Configure Split',
                content: _splitMethod == 'range'
                    ? _buildRangeInput()
                    : _buildExtractInput(),
              ),
            const SizedBox(height: 20),

            // Step 4: Split
            if (_selectedFile != null && _pageRanges.isNotEmpty)
              _buildStepCard(
                step: 4,
                title: 'Split File',
                content: AppleButton(
                  label: _isSplitting ? 'Splitting...' : 'Start Split',
                  icon: _isSplitting ? Icons.hourglass_empty : Icons.content_cut,
                  onPressed: _isSplitting ? null : _startSplit,
                  isPrimary: true,
                  isFullWidth: true,
                ),
              ),
            const SizedBox(height: 20),

            // Status
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: _getStatusColor().withOpacity(0.1),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: _getStatusColor()),
              ),
              child: Text(
                _statusMessage,
                style: TextStyle(
                  fontSize: 13,
                  fontWeight: FontWeight.w500,
                  color: _getStatusColor(),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStepCard({
    required int step,
    required String title,
    required Widget content,
  }) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.grey.shade50,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: Colors.grey.shade300),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 28,
                height: 28,
                decoration: BoxDecoration(
                  color: const Color(0xFF0051BA),
                  borderRadius: BorderRadius.circular(6),
                ),
                child: Center(
                  child: Text(
                    '$step',
                    style: const TextStyle(
                      color: Colors.white,
                      fontWeight: FontWeight.bold,
                      fontSize: 14,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              Text(
                title,
                style: const TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF1F2937),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          content,
        ],
      ),
    );
  }

  Widget _buildMethodButton(String value, String label) {
    final isSelected = _splitMethod == value;
    return GestureDetector(
      onTap: () {
        setState(() {
          _splitMethod = value;
          _pageRanges = value == 'range' ? ['1-5'] : [];
        });
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: isSelected ? const Color(0xFF007AFF).withOpacity(0.1) : Colors.white,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: isSelected ? const Color(0xFF007AFF) : Colors.grey.shade300,
            width: isSelected ? 2 : 1,
          ),
        ),
        child: Row(
          children: [
            Container(
              width: 20,
              height: 20,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(
                  color: isSelected ? const Color(0xFF007AFF) : Colors.grey.shade400,
                  width: 2,
                ),
              ),
              child: isSelected
                  ? const Center(
                      child: SizedBox(
                        width: 10,
                        height: 10,
                        child: DecoratedBox(
                          decoration: BoxDecoration(
                            color: Color(0xFF007AFF),
                            shape: BoxShape.circle,
                          ),
                        ),
                      ),
                    )
                  : null,
            ),
            const SizedBox(width: 12),
            Text(
              label,
              style: TextStyle(
                fontSize: 14,
                fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                color: isSelected ? const Color(0xFF007AFF) : Colors.grey.shade700,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildRangeInput() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Page ranges (e.g., 1-5, 10-15)',
          style: TextStyle(
            fontSize: 13,
            color: Colors.grey,
          ),
        ),
        const SizedBox(height: 8),
        TextField(
          controller: _pageRangeController,
          decoration: InputDecoration(
            hintText: 'Enter page range',
            border: OutlineInputBorder(
              borderRadius: BorderRadius.circular(10),
            ),
            suffix: GestureDetector(
              onTap: _addPageRange,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 8),
                child: const Icon(Icons.add_circle, color: Color(0xFF007AFF)),
              ),
            ),
          ),
        ),
        const SizedBox(height: 12),
        if (_pageRanges.isNotEmpty)
          Wrap(
            spacing: 8,
            children: _pageRanges
                .map(
                  (range) => Chip(
                    label: Text(range),
                    onDeleted: () {
                      setState(() => _pageRanges.remove(range));
                    },
                  ),
                )
                .toList(),
          ),
      ],
    );
  }

  Widget _buildExtractInput() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Select pages to extract',
          style: TextStyle(
            fontSize: 13,
            color: Colors.grey,
          ),
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          decoration: BoxDecoration(
            border: Border.all(color: Colors.grey.shade300),
            borderRadius: BorderRadius.circular(10),
          ),
          child: ListView.separated(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: _totalPages,
            separatorBuilder: (_, __) => Divider(height: 1),
            itemBuilder: (context, index) {
              return CheckboxListTile(
                title: Text('Page ${index + 1}'),
                value: _pageRanges.contains('${index + 1}'),
                onChanged: (value) {
                  setState(() {
                    if (value == true) {
                      _pageRanges.add('${index + 1}');
                    } else {
                      _pageRanges.remove('${index + 1}');
                    }
                  });
                },
                contentPadding: EdgeInsets.zero,
              );
            },
          ),
        ),
      ],
    );
  }

  void _addPageRange() {
    final range = _pageRangeController.text.trim();
    if (range.isNotEmpty) {
      setState(() {
        _pageRanges.add(range);
        _pageRangeController.clear();
      });
    }
  }

  void _selectFile() async {
    try {
      final result = await FilePicker.platform.pickFiles(
        type: FileType.custom,
        allowedExtensions: ['pdf'],
      );

      if (result != null && result.files.isNotEmpty) {
        final file = result.files.first;
        final bytes = file.bytes;

        if (bytes != null) {
          setState(() {
            _selectedFile = file.name;
            _selectedFileBytes = bytes;
            _totalPages = 25; // This would be calculated from actual PDF
            _statusMessage = '✓ ${file.name} selected (${_totalPages} pages)';
          });
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
              content: Text('Error: Could not read file'),
              backgroundColor: Colors.red,
            ),
          );
        }
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e'),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  void _startSplit() {
    setState(() {
      _isSplitting = true;
      _statusMessage = 'Splitting file into ${_pageRanges.length} part(s)...';
    });

    Future.delayed(const Duration(seconds: 3), () {
      setState(() {
        _isSplitting = false;
        _statusMessage = '✓ Split completed successfully';
      });

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('✓ File split successfully'),
          backgroundColor: Colors.green,
        ),
      );
    });
  }

  Color _getStatusColor() {
    if (_statusMessage.startsWith('✓')) return Colors.green;
    if (_statusMessage.startsWith('✗')) return Colors.red;
    if (_statusMessage.startsWith('Splitting')) return Colors.blue;
    return Colors.grey;
  }
}
