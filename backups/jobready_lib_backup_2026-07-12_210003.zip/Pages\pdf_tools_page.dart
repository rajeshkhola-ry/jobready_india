import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as path;
import 'package:path_provider/path_provider.dart';
import 'package:pdf_text/pdf_text.dart';

import '../Widgets/pdf_tool_card.dart';
import '../Services/word_generator_service.dart';

class PdfToolsPage extends StatefulWidget {
  const PdfToolsPage({super.key});

  @override
  State<PdfToolsPage> createState() => _PdfToolsPageState();
}

class _PdfToolsPageState extends State<PdfToolsPage> {
  String? selectedPdfName;
  int? selectedPdfSize;

  // Stores the actual uploaded PDF data.
  Uint8List? selectedPdfBytes;

  bool isConverting = false;
  bool conversionCompleted = false;

  double progressValue = 0;

  String conversionStatus = '';
  String generatedFileName = '';

  final WordGeneratorService wordService =
      const WordGeneratorService();

  Future<void> pickPdf() async {
    final FilePickerResult? result =
        await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],

      // Very important for Flutter Web:
      // this loads the actual PDF file into memory.
      withData: true,
    );

    if (result == null) {
      return;
    }

    final PlatformFile selectedFile =
        result.files.single;

    if (selectedFile.bytes == null) {
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Unable to read the selected PDF file.',
          ),
        ),
      );

      return;
    }

    setState(() {
      selectedPdfName = selectedFile.name;
      selectedPdfSize = selectedFile.size;
      selectedPdfBytes = selectedFile.bytes;

      conversionCompleted = false;
      generatedFileName = '';
      progressValue = 0;
      conversionStatus = '';
    });

    if (!mounted) return;

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          'Selected: ${selectedFile.name}',
        ),
      ),
    );
  }

  Future<void> convertPdfToWord() async {
    if (selectedPdfName == null ||
        selectedPdfBytes == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Please select a PDF file first.',
          ),
        ),
      );

      return;
    }

    setState(() {
      isConverting = true;
      conversionCompleted = false;
      generatedFileName = '';
      progressValue = 0;
      conversionStatus = '📄 Preparing PDF...';
    });

    try {
      // Progress UI.
      for (int i = 1; i <= 80; i++) {
        await Future.delayed(
          const Duration(milliseconds: 20),
        );

        if (!mounted) return;

        setState(() {
          progressValue = i / 100;

          if (i < 20) {
            conversionStatus =
                '📄 Preparing PDF...';
          } else if (i < 40) {
            conversionStatus =
                '🔍 Reading PDF...';
          } else if (i < 60) {
            conversionStatus =
                '✍️ Preparing Text Extraction...';
          } else {
            conversionStatus =
                '📄 Preparing Word File...';
          }
        });
      }

      final String extractedText = await _extractTextFromPdf(
        selectedPdfBytes!,
        selectedPdfName!,
      );

      final Uint8List outputBytes =
          await wordService.createWordDocument(
        pdfFileName: selectedPdfName!,
        extractedText: extractedText,
      );

      if (outputBytes.isEmpty) {
        throw Exception(
          'Generated Word document is empty.',
        );
      }

      final String outputFileName =
          selectedPdfName!.replaceAll(
        RegExp(
          r'\.pdf$',
          caseSensitive: false,
        ),
        '.docx',
      );

      if (!mounted) return;

      setState(() {
        progressValue = 1.0;
        conversionStatus = '✅ Finalizing...';

        conversionCompleted = true;
        generatedFileName = outputFileName;
        isConverting = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            '$outputFileName created successfully.',
          ),
        ),
      );
    } catch (e) {
      if (!mounted) return;

      setState(() {
        isConverting = false;
        conversionCompleted = false;
        conversionStatus = '';
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Conversion failed: $e',
          ),
        ),
      );
    }
  }

  Future<String> _extractTextFromPdf(
    Uint8List pdfBytes,
    String pdfName,
  ) async {
    if (kIsWeb) {
      return 'PDF text extraction is not available on web.\nPlease run this app on mobile or desktop to convert PDF to Word.';
    }

    final Directory tempDir = await getTemporaryDirectory();
    final File tempFile = File(path.join(
      tempDir.path,
      'pdf_to_word_${DateTime.now().millisecondsSinceEpoch}_${pdfName.replaceAll(RegExp(r"[^a-zA-Z0-9._-]"), '_')}.pdf',
    ));

    await tempFile.writeAsBytes(pdfBytes, flush: true);

    try {
      final PDFDoc document = await PDFDoc.fromFile(tempFile);
      final String extractedText = await document.text;

      return extractedText.trim().isEmpty
          ? 'No readable text was found in the selected PDF file.'
          : extractedText;
    } catch (e) {
      debugPrint('PDF extraction failed: $e');
      return 'Unable to extract text from the selected PDF. The file may contain scanned images or unsupported content.';
    } finally {
      await tempFile.delete().catchError((_) {});
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor:
            const Color(0xFF1F2937),
        iconTheme: const IconThemeData(
          color: Color(0xFFFFC72C),
        ),
        title: const Text(
          'PDF Tools',
          style: TextStyle(
            color: Color(0xFFFFC72C),
            fontWeight: FontWeight.bold,
          ),
        ),
      ),

      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const Text(
            'PDF Toolkit',
            style: TextStyle(
              fontSize: 28,
              fontWeight: FontWeight.bold,
              color: Color(0xFF1F2937),
            ),
          ),

          const SizedBox(height: 8),

          const Text(
            'Convert, Merge, Split & Compress PDFs',
            style: TextStyle(
              fontSize: 16,
              color: Colors.grey,
            ),
          ),

          const SizedBox(height: 20),
          const Divider(),
          const SizedBox(height: 20),

          if (selectedPdfName != null)
            Card(
              color: Colors.green.shade50,
              elevation: 2,
              child: Padding(
                padding:
                    const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment:
                      CrossAxisAlignment.start,
                  children: [
                    const Text(
                      'Selected PDF',
                      style: TextStyle(
                        fontWeight:
                            FontWeight.bold,
                        fontSize: 18,
                      ),
                    ),

                    const SizedBox(height: 10),

                    Text(
                      selectedPdfName!,
                      style: const TextStyle(
                        fontSize: 16,
                      ),
                    ),

                    const SizedBox(height: 6),

                    Text(
                      'Size : '
                      '${(selectedPdfSize! / 1024).toStringAsFixed(2)} KB',
                    ),

                    const SizedBox(height: 6),

                    Text(
                      conversionCompleted
                          ? '✅ Status : Process Completed'
                          : 'Status : Ready to Convert',
                      style: TextStyle(
                        color:
                            conversionCompleted
                                ? Colors.blue
                                : Colors.green,
                        fontWeight:
                            FontWeight.bold,
                      ),
                    ),

                    if (conversionCompleted) ...[
                      const SizedBox(height: 12),

                      const Text(
                        'Generated Word File',
                        style: TextStyle(
                          fontWeight:
                              FontWeight.bold,
                        ),
                      ),

                      const SizedBox(height: 6),

                      Text(
                        generatedFileName,
                        style: const TextStyle(
                          color: Colors.indigo,
                          fontWeight:
                              FontWeight.w600,
                        ),
                      ),
                    ],

                    const SizedBox(height: 18),

                    SizedBox(
                      width: double.infinity,
                      child: ElevatedButton.icon(
                        icon: const Icon(
                          Icons.auto_fix_high,
                        ),
                        label: const Text(
                          'Convert to Word',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight:
                                FontWeight.bold,
                          ),
                        ),
                        onPressed: isConverting
                            ? null
                            : convertPdfToWord,
                      ),
                    ),

                    const SizedBox(height: 20),

                    if (isConverting) ...[
                      const Text(
                        'Conversion Progress',
                        style: TextStyle(
                          fontSize: 18,
                          fontWeight:
                              FontWeight.bold,
                        ),
                      ),

                      const SizedBox(height: 12),

                      LinearProgressIndicator(
                        value: progressValue,
                        minHeight: 10,
                      ),

                      const SizedBox(height: 12),

                      Text(
                        '${(progressValue * 100).toInt()} %',
                        style: const TextStyle(
                          fontWeight:
                              FontWeight.bold,
                        ),
                      ),

                      const SizedBox(height: 12),

                      Text(
                        conversionStatus,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight:
                              FontWeight.w600,
                          color: Colors.indigo,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),

          if (selectedPdfName != null)
            const SizedBox(height: 20),

          PdfToolCard(
            icon: Icons.picture_as_pdf,
            title: 'PDF to Word',
            subtitle:
                'Convert PDF into editable Word documents',
            onTap: pickPdf,
          ),

          const SizedBox(height: 14),

          PdfToolCard(
            icon: Icons.description,
            title: 'Word to PDF',
            subtitle:
                'Convert Word documents into PDF',
            onTap: () {
              ScaffoldMessenger.of(context)
                  .showSnackBar(
                const SnackBar(
                  content: Text(
                    'Word to PDF coming in Phase 9',
                  ),
                ),
              );
            },
          ),

          const SizedBox(height: 14),

          PdfToolCard(
            icon: Icons.merge_type,
            title: 'Merge PDF',
            subtitle:
                'Combine multiple PDF files',
            onTap: () {
              ScaffoldMessenger.of(context)
                  .showSnackBar(
                const SnackBar(
                  content: Text(
                    'Merge PDF coming in Phase 9',
                  ),
                ),
              );
            },
          ),

          const SizedBox(height: 14),

          PdfToolCard(
            icon: Icons.content_cut,
            title: 'Split PDF',
            subtitle:
                'Extract pages from PDF files',
            onTap: () {
              ScaffoldMessenger.of(context)
                  .showSnackBar(
                const SnackBar(
                  content: Text(
                    'Split PDF coming in Phase 9',
                  ),
                ),
              );
            },
          ),

          const SizedBox(height: 14),

          PdfToolCard(
            icon: Icons.compress,
            title: 'Compress PDF',
            subtitle: 'Reduce PDF size',
            onTap: () {
              ScaffoldMessenger.of(context)
                  .showSnackBar(
                const SnackBar(
                  content: Text(
                    'Compress PDF coming in Phase 9',
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}