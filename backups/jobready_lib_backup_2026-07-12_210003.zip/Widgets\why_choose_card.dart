import 'package:flutter/material.dart';

class WhyChooseCard extends StatelessWidget {
  const WhyChooseCard({super.key});

  Widget item(IconData icon, String title) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          Icon(
            icon,
            color: const Color(0xFFFFCC00),
            size: 20,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Text(
              title,
              style: const TextStyle(
                fontWeight: FontWeight.w600,
                fontSize: 14,
                color: Color(0xFF1F2937),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {

    return Card(

      elevation: 2,

      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
      ),

      child: Padding(

        padding: const EdgeInsets.all(18),

        child: Column(

          crossAxisAlignment: CrossAxisAlignment.start,

          children: [

            const Text(
              "Why Choose JOBREADY?",
              style: TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.bold,
                color: Color(0xFF1F2937),
              ),
            ),

            const SizedBox(height: 12),

            item(
              Icons.flash_on,
              "Lightning Fast Conversion",
            ),

            item(
              Icons.security,
              "100% Secure Documents",
            ),

            item(
              Icons.cloud_done,
              "Cloud Ready",
            ),

            item(
              Icons.workspace_premium,
              "Professional Quality Output",
            ),

            item(
              Icons.support_agent,
              "24×7 Customer Support",
            ),
          ],
        ),
      ),
    );
  }
}
