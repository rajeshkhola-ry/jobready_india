import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart' as sfpdf;

import '../Services/file_picker_service.dart';
import '../Widgets/download_result_dialog.dart';

class PdfEditPage extends StatefulWidget {
  final String? initialFileName;
  final Uint8List? initialBytes;

  const PdfEditPage({
    super.key,
    this.initialFileName,
    this.initialBytes,
  });

  @override
  State<PdfEditPage> createState() => _PdfEditPageState();
}

class _PdfEditPageState extends State<PdfEditPage> {
  Uint8List? _selectedBytes;
  String? _selectedName;
  bool _isSaving = false;
  bool _isLoadingText = false;

  final TextEditingController _editorController = TextEditingController();

  @override
  void initState() {
    super.initState();
    _selectedBytes = widget.initialBytes;
    _selectedName = widget.initialFileName;
    if (_selectedBytes != null) {
      _loadPdfTextIntoEditor();
    }
  }

  @override
  void dispose() {
    _editorController.dispose();
    super.dispose();
  }

  Future<void> _pickPdf() async {
    final files = await FilePickerService.pickMultipleFileData(
      allowedExtensions: const ['pdf'],
    );

    if (files.isEmpty) {
      return;
    }

    setState(() {
      _selectedBytes = files.first.bytes;
      _selectedName = files.first.name;
    });

    await _loadPdfTextIntoEditor();
  }

  Future<void> _loadPdfTextIntoEditor() async {
    if (_selectedBytes == null) {
      return;
    }

    setState(() {
      _isLoadingText = true;
    });

    try {
      final document = sfpdf.PdfDocument(inputBytes: _selectedBytes!);
      try {
        final extractedText = sfpdf.PdfTextExtractor(document).extractText();
        _editorController.text = extractedText.trim();
      } finally {
        document.dispose();
      }
    } catch (_) {
      _editorController.text = '';
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Unable to load editable text from this PDF.')),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoadingText = false;
        });
      }
    }
  }

  Future<void> _saveEditedPdf() async {
    if (_selectedBytes == null || _selectedName == null) {
      return;
    }

    final editedText = _editorController.text.trim();
    if (editedText.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please edit or enter text before saving.')),
      );
      return;
    }

    setState(() {
      _isSaving = true;
    });

    try {
      final outputDocument = sfpdf.PdfDocument();
      try {
        final page = outputDocument.pages.add();
        final bodyFont = sfpdf.PdfStandardFont(sfpdf.PdfFontFamily.helvetica, 11);

        final textElement = sfpdf.PdfTextElement(
          text: editedText,
          font: bodyFont,
          brush: sfpdf.PdfSolidBrush(sfpdf.PdfColor(17, 24, 39)),
        );
        textElement.draw(
          page: page,
          bounds: Rect.fromLTWH(20, 20, page.size.width - 40, page.size.height - 40),
          format: sfpdf.PdfLayoutFormat(layoutType: sfpdf.PdfLayoutType.paginate),
        );

        final bytes = Uint8List.fromList(outputDocument.saveSync());
        final outputName =
            _selectedName!.replaceAll(RegExp(r'\.pdf$', caseSensitive: false), '_edited.pdf');

        if (!mounted) return;

        setState(() {
          _isSaving = false;
        });

        await showDialog(
          context: context,
          builder: (_) => DownloadResultDialog(
            outputFormat: 'Edited PDF',
            fileName: outputName,
            outputBytes: bytes,
          ),
        );
      } finally {
        outputDocument.dispose();
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isSaving = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Unable to edit PDF: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF1F2937),
        iconTheme: const IconThemeData(color: Color(0xFFFFC72C), size: 28),
        title: const Text(
          'PDF to PDF (Edit)',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ElevatedButton.icon(
            onPressed: _pickPdf,
            icon: const Icon(Icons.upload_file_rounded),
            label: Text(_selectedName == null ? 'Upload PDF' : 'Change PDF'),
          ),
          const SizedBox(height: 12),
          if (_selectedName != null)
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFEFF6FF),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFBFDBFE)),
              ),
              child: Text(
                'Editing: $_selectedName',
                style: const TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF1E3A8A)),
              ),
            ),
          const SizedBox(height: 14),
          const Text(
            'Manual PDF Text Editor',
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: Color(0xFF1E3A8A)),
          ),
          const SizedBox(height: 8),
          if (_isLoadingText)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 24),
              child: Center(child: CircularProgressIndicator()),
            )
          else
            TextField(
              controller: _editorController,
              minLines: 12,
              maxLines: 20,
              decoration: const InputDecoration(
                labelText: 'Edit text manually here (multiple changes in one shot)',
                border: OutlineInputBorder(),
                alignLabelWithHint: true,
              ),
            ),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0xFFFFFBEB),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: const Color(0xFFFCD34D)),
            ),
            child: const Text(
              'Upload PDF -> edit text manually -> save/download as PDF.',
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Color(0xFF92400E)),
            ),
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: (_selectedBytes == null || _isSaving) ? null : _saveEditedPdf,
            icon: _isSaving
                ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.save_alt_rounded),
            label: Text(_isSaving ? 'Saving Edited PDF...' : 'Save & Download Edited PDF'),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF1F4E79),
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
          ),
        ],
      ),
    );
  }
}
