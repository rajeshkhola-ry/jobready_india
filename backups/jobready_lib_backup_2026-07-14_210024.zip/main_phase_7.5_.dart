﻿// Starting file
// Phase 7.5
import 'package:flutter/material.dart';
import 'Pages/coming_soon_page.dart';
import 'Pages/home_page_v2.dart';
import 'Pages/system_check_page.dart';
import 'Pages/compression_tool_page.dart';
import 'Pages/convert_tool_page.dart';
import 'Pages/merge_tool_page.dart';
import 'Pages/split_tool_page.dart';
import 'Pages/extract_tool_page.dart';
import 'Pages/pdf_tools_page.dart';
import 'Pages/pdf_edit_page.dart';
import 'Pages/terms_conditions_page.dart';
//
// ===============================
// GLOBAL RESUME DATA MODEL
// ===============================
//
class ResumeData {
  static String fullName = "RAJESH YADAV";
  static String jobTitle = "Cargo Revenue Accounting Specialist";
  static String email = "";
  static String phone = "";
  static String city = "";
  static String summary = "";
  static String experience = "";
  static String education = "";
//
  static List<String> skills = [
    "Cargo Accounting",
    "Revenue Accounting",
    "SAP",
    "Excel",
  ];
}
//
void main() {
  runApp(const JobReadyApp());
}
//
class JobReadyApp extends StatelessWidget {
  const JobReadyApp({super.key});
//
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'JOBREADY',
      theme: ThemeData(
        scaffoldBackgroundColor: const Color(0xFFF8F9FA),
        useMaterial3: true,
      ),
      initialRoute: '/',
      routes: {
        '/': (_) => const ComingSoonPage(),
        '/home': (_) => const HomePageV2(),
        '/system-check': (_) => const SystemCheckPage(),
        '/compress': (_) => const CompressionToolPage(),
        '/convert': (_) => const ConvertToolPage(),
        '/merge': (_) => const MergeToolPage(),
        '/split': (_) => const SplitToolPage(),
        '/extract': (_) => const ExtractToolPage(),
        '/pdf-tools': (_) => const PdfToolsPage(),
        '/pdf-edit': (_) => const PdfEditPage(),
        '/terms': (_) => const TermsConditionsPage(),
      },
    );
  }
}
