# JOBREADY Roadmap Rate Card (V1 vs V2 vs V3)

Last updated: 2026-07-14
Purpose: One-file requirement comparison with tick or X so launch readiness can be tracked quickly.

Legend:
- TICK = requirement is available in that version
- X = requirement is not available in that version
- PARTIAL = available but limited or still stabilizing

## Version Availability

| Version | Status |
|---|---|
| V1 | TICK (available) |
| V2 | TICK (available, active advanced build via Phase 7.5 routes) |
| V3 | X (no dedicated V3 entry/home implementation found) |

## Requirement Comparison (Rate Card)

| # | Requirement | V1 | V2 | V3 |
|---|---|---|---|---|
| 1 | Home entry and navigation baseline | TICK | TICK | X |
| 2 | Upload and start workflow | TICK | TICK | X |
| 3 | Compress tool page and flow | TICK | TICK | X |
| 4 | Convert tool page and flow | TICK | TICK | X |
| 5 | Merge tool page and flow | TICK | TICK | X |
| 6 | Split tool page and flow | TICK | TICK | X |
| 7 | Extract tool page and flow | TICK | TICK | X |
| 8 | PDF tools workspace access | TICK | TICK (expanded) | X |
| 9 | Word to PDF entry from PDF tools | PARTIAL | TICK (now routed to convert flow) | X |
| 10 | Merge/Split/Compress cards avoid placeholder message | PARTIAL | TICK | X |
| 11 | Compression benchmark control page | TICK | TICK | X |
| 12 | Benchmark history page | X | TICK | X |
| 13 | Launch readiness page | TICK | TICK | X |
| 14 | Launch runbook page | X | TICK | X |
| 15 | Post-launch control page | X | TICK | X |
| 16 | API configuration layer (analytics, ads, links, flags) | TICK | TICK | X |
| 17 | Pricing plans block (commercial setup) | X | TICK | X |
| 18 | Coupon and promo control panel | X | TICK | X |
| 19 | Ad slot and ad-link layer | X | TICK | X |
| 20 | Footer release/support info block | TICK | TICK (expanded) | X |
| 21 | PDF-to-Word with layout-first strategy | PARTIAL | TICK | X |
| 22 | Optional language-change toggle during convert | X | X | X (planned roadmap item only) |

## V1 + V2 Launch Focus (High Priority)

Use this block as launch gate for first release decision (V1 + VA/V2 blend):

| Launch Gate Requirement | Status |
|---|---|
| Core tools open correctly (Compress, Convert, Merge, Split, Extract) | TICK |
| No Phase-9 placeholder messages in active V2 app pages | TICK |
| PDF tools card routes wired to real pages | TICK |
| Diagnose and recover script available for emergency reset | TICK |
| Stability validation run after diagnose | PARTIAL (needs repeated owner test rounds) |
| Final owner acceptance test for converter and reduce size | PENDING |

## Recommended Execution Order (for fast, safer launch)

1. Lock V1 + V2 launch scope (no new feature additions during stabilization window).
2. Run Diagnose And Recover task before each test session.
3. Execute owner acceptance checklist on core flows:
   - Convert
   - Compress
   - Merge
   - Split
   - Extract
4. Fix only blocker defects.
5. Freeze launch evidence and go-live when all launch gate rows are TICK.

## Source Basis

This file is based on the current repository and audit basis from:
- V1_V2_V3_Audit_Report_2026-07-14.html
- main_v1.dart
- main_phase_7.5_.dart
- Pages/home_page_v2.dart
- Pages/pdf_tools_page.dart
- Pages/launch_readiness_page.dart
- Pages/launch_runbook_page.dart
- Pages/post_launch_control_page.dart
- Services/api_config.dart
- Services/coupon_service.dart
