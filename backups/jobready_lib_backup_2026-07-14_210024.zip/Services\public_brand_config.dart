class PublicBrandConfig {
  static const String websiteDomain = 'www.getreadyjob.com';
  static const String websiteHost = 'getreadyjob.com';
  static const String supportEmail = 'rajesh.khola@outlook.com';
  static const String supportEmailMailto = 'mailto:rajesh.khola@outlook.com';
  static const String publicTitle = 'JOBREADY';
  static const String comingSoonMessage = 'We are preparing the public version of JOBREADY.\nPlease check back soon.';
}
