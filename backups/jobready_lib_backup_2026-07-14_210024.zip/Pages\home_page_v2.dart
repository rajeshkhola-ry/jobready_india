import 'package:flutter/material.dart';
import 'package:universal_html/html.dart' as html;

import '../Widgets/why_choose_card.dart';
import '../Widgets/glowing_logo_badge.dart';
import '../Widgets/upload_card_v2.dart';
import '../Widgets/tool_selector_v2.dart';
import '../Services/public_brand_config.dart';
import '../Services/api_config.dart';
import '../Services/coupon_service.dart';
import '../Services/integration_hub_service.dart';
import 'compression_benchmark_page.dart';
import 'launch_readiness_page.dart';
import 'launch_runbook_page.dart';
import 'post_launch_control_page.dart';
import 'plan_features_page.dart';
import 'terms_conditions_page.dart';

class HomePageV2 extends StatefulWidget {
  const HomePageV2({super.key});

  @override
  State<HomePageV2> createState() => _HomePageV2State();
}

class _HomePageV2State extends State<HomePageV2> {
  int _pricingDiscountPercent = 0;
  String _activeGateway = ApiService.getActivePaymentGateway();
  String _selectedPlanForPayment = 'Pro';
  String? _selectedUsageType;
  bool _showLiveOfferBanner = false;
  String _liveOfferText = '';
  static const String _ownerOfferCode = 'JR-OWNER-2026';

  // Manual pricing control (USD): update these two values any time.
  static const double _proPlanUsd = 7.99;
  static const double _aiPremiumPlanUsd = 19.99;
  static const double _lifetimePlanUsd = 999.99;
  static const double _businessIncreaseMultiplier = 1.75;

  String _formatUsd(double amount) {
    final rounded = amount.roundToDouble();
    if (amount == rounded) {
      return '\$${amount.toStringAsFixed(0)}';
    }
    return '\$${amount.toStringAsFixed(2)}';
  }

  double _priceForUsage(double personalMonthlyPrice) {
    if (_selectedUsageType == 'Business') {
      return personalMonthlyPrice * _businessIncreaseMultiplier;
    }
    return personalMonthlyPrice;
  }

  double _monthlyPriceForPlan(String plan) {
    if (plan == 'Pro') {
      return _priceForUsage(_proPlanUsd);
    }
    if (plan == 'AI Premium') {
      return _priceForUsage(_aiPremiumPlanUsd);
    }
    return 0;
  }

  void _openMailComposer({required String subject, required String body}) {
    final mailto =
        '${PublicBrandConfig.supportEmailMailto}?subject=${Uri.encodeComponent(subject)}&body=${Uri.encodeComponent(body)}';
    final opened = html.window.open(mailto, '_blank');
    if (opened == null) {
      html.window.open(mailto, '_self');
    }
  }

  void _showSuggestionDialog() {
    final suggestionController = TextEditingController();

    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Send Suggestion'),
        content: TextField(
          controller: suggestionController,
          maxLines: 5,
          decoration: const InputDecoration(
            hintText: 'Write your suggestion here',
            border: OutlineInputBorder(),
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              final message = suggestionController.text.trim();
              Navigator.of(dialogContext).pop();
              if (message.isEmpty) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('Please write your suggestion first.')),
                );
                return;
              }

              _openMailComposer(
                subject: 'JOBREADY User Suggestion',
                body: 'Customer suggestion:\n\n$message\n\nSource: V2 app',
              );

              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(
                  content: Text('Suggestion mailbox opened. Press Send in your email app.'),
                ),
              );
            },
            child: const Text('Submit'),
          ),
        ],
      ),
    ).then((_) {
      suggestionController.dispose();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: const Color(0xFFF7F8FC),

      appBar: AppBar(
        backgroundColor: const Color(0xFF1F2937),
        centerTitle: true,
        toolbarHeight: 64,
        actions: [
          _TopActionIcon(
            tooltip: 'Benchmark',
            icon: Icons.bar_chart_rounded,
            iconColor: const Color(0xFF9BD7FF),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const CompressionBenchmarkPage(),
                ),
              );
            },
          ),
          _TopActionIcon(
            tooltip: 'Readiness',
            icon: Icons.rocket_launch_rounded,
            iconColor: const Color(0xFFB7F59E),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const LaunchReadinessPage(),
                ),
              );
            },
          ),
          _TopActionIcon(
            tooltip: 'Runbook',
            icon: Icons.task_alt_rounded,
            iconColor: const Color(0xFFC6D2FF),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const LaunchRunbookPage(),
                ),
              );
            },
          ),
          _TopActionIcon(
            tooltip: 'Post-Launch',
            icon: Icons.monitor_heart_rounded,
            iconColor: const Color(0xFFFFD6A5),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const PostLaunchControlPage(),
                ),
              );
            },
          ),
          _TopActionIcon(
            tooltip: 'Support Email',
            icon: Icons.email_outlined,
            iconColor: const Color(0xFFFFC72C),
            onTap: () {
              _openMailComposer(
                subject: 'JOBREADY Support Request',
                body: 'Hi JOBREADY Team,%0A%0APlease help me with:%0A',
              );
            },
          ),
          _TopActionIcon(
            tooltip: 'Terms & Conditions',
            icon: Icons.gavel_rounded,
            iconColor: const Color(0xFFFFC72C),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const TermsConditionsPage(),
                ),
              );
            },
          ),
          const SizedBox(width: 8),
        ],
        title: Row(
          mainAxisSize: MainAxisSize.min,
          children: const [
            GlowingLogoBadge(size: 34, circular: true),
            SizedBox(width: 8),
            Flexible(
              child: FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text(
                  'JOBREADY',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.4,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),

      body: SingleChildScrollView(
        padding: const EdgeInsets.fromLTRB(14, 10, 14, 18),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                gradient: const LinearGradient(
                  colors: [Color(0xFF1F4E79), Color(0xFFFFC72C)],
                ),
              ),
              child: const Text(
                "Upload one document or multiple files together and start working instantly.",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontSize: 14,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.3,
                ),
              ),
            ),

            const SizedBox(height: 10),
            const _BrowserSupportNotice(),

            const SizedBox(height: 10),
            const _V2Column(),
            const SizedBox(height: 10),
            if (_showLiveOfferBanner && _liveOfferText.trim().isNotEmpty) ...[
              _LiveOfferBanner(text: _liveOfferText),
              const SizedBox(height: 10),
            ],
            const _WhyChooseAdSection(),
            const SizedBox(height: 12),
            const SizedBox(height: 4),
            const SizedBox(height: 12),
            const _FixedAdSpace(adPlacement: 'banner_home'),
            const SizedBox(height: 12),
            const _SectionHeader(
              title: 'Plans',
              subtitle: 'Simple access today, premium workspace upgrades coming next.',
            ),
            const SizedBox(height: 12),
            _UsageTypeSelector(
              selectedType: _selectedUsageType,
              onChanged: (value) {
                setState(() {
                  _selectedUsageType = value;
                });
              },
            ),
            const SizedBox(height: 12),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFFFFFBEB), Color(0xFFFDE68A)],
                ),
                borderRadius: BorderRadius.circular(14),
                border: Border.all(color: const Color(0xFFF59E0B), width: 1.1),
              ),
              child: Row(
                children: [
                  Container(
                    width: 30,
                    height: 30,
                    decoration: BoxDecoration(
                      color: Colors.white.withValues(alpha: 0.9),
                      borderRadius: BorderRadius.circular(9),
                    ),
                    child: const Icon(
                      Icons.verified_rounded,
                      color: Color(0xFFB45309),
                      size: 18,
                    ),
                  ),
                  const SizedBox(width: 10),
                  const Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Text(
                          'Usage type required before payment',
                          style: TextStyle(
                            fontSize: 12,
                            fontWeight: FontWeight.w800,
                            color: Color(0xFF7C2D12),
                          ),
                        ),
                        SizedBox(height: 2),
                        Text(
                          'Select Personal or Business first, then continue with your plan. Annual access uses 10-month payment for 12 months.',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            color: Color(0xFF92400E),
                            height: 1.25,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            _GatewayControlPanel(
              activeGateway: _activeGateway,
              onGatewayChanged: (gateway) {
                setState(() {
                  _activeGateway = gateway;
                });
              },
            ),
            const SizedBox(height: 12),
            _OwnerOfferManagerPanel(
              ownerCode: _ownerOfferCode,
              onOfferUpdated: (enabled, text, promoCode, validity) {
                setState(() {
                  _showLiveOfferBanner = enabled;
                  _liveOfferText = text.trim();
                });

                if (promoCode.trim().isNotEmpty) {
                  CouponService.upsertCoupon(
                    code: promoCode.trim(),
                    discountPercent: 100,
                    validFor: validity,
                    maxUses: 999999,
                  );
                }
              },
            ),
            const SizedBox(height: 12),
            _CouponControlPanel(
              onDiscountChanged: (discountPercent) {
                setState(() {
                  _pricingDiscountPercent = discountPercent;
                });
              },
            ),
            const SizedBox(height: 12),
            _PlanCardsSection(
              proPrice: _formatUsd(_monthlyPriceForPlan('Pro')),
              premiumPrice: _formatUsd(_monthlyPriceForPlan('AI Premium')),
              lifetimePrice: _formatUsd(_lifetimePlanUsd),
              discountPercent: _pricingDiscountPercent,
              selectedPlan: _selectedPlanForPayment,
              usageType: _selectedUsageType,
              onPlanSelected: (plan) {
                if (_selectedUsageType == null) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Please select Personal or Business first.'),
                    ),
                  );
                  return;
                }
                setState(() {
                  _selectedPlanForPayment = plan;
                });
              },
            ),
            const SizedBox(height: 12),
            _UserPaymentPanel(
              activeGateway: _activeGateway,
              selectedPlan: _selectedPlanForPayment,
              usageType: _selectedUsageType,
              proMonthlyPrice: _monthlyPriceForPlan('Pro'),
              premiumMonthlyPrice: _monthlyPriceForPlan('AI Premium'),
              lifetimePlanPrice: _lifetimePlanUsd,
              onPlanChanged: (plan) {
                setState(() {
                  _selectedPlanForPayment = plan;
                });
              },
              onUsageTypeChanged: (usageType) {
                setState(() {
                  _selectedUsageType = usageType;
                });
              },
            ),

            const SizedBox(height: 10),
            const _AboutUsSection(),
            const SizedBox(height: 10),
            const _FuturePlanSection(),
            const SizedBox(height: 10),
            _SuggestionSection(
              onTap: () {
                _showSuggestionDialog();
              },
            ),
            const SizedBox(height: 10),
            _FooterInfoRow(
              icon: Icons.language_rounded,
              label: 'Website',
              value: PublicBrandConfig.websiteDomain,
            ),
            const SizedBox(height: 8),
            _FooterInfoRow(
              icon: Icons.email_outlined,
              label: 'Support',
              value: PublicBrandConfig.supportEmail,
            ),
            const SizedBox(height: 6),
          ],
        ),
      ),
    );
  }
}

class _FixedAdSpace extends StatefulWidget {
  final String adPlacement;

  const _FixedAdSpace({required this.adPlacement});

  @override
  State<_FixedAdSpace> createState() => _FixedAdSpaceState();
}

class _LiveOfferBanner extends StatelessWidget {
  final String text;

  const _LiveOfferBanner({required this.text});

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF7CC),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFFFE08A)),
      ),
      child: Row(
        children: [
          const Icon(Icons.local_offer_rounded, color: Color(0xFFB45309), size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: const TextStyle(
                fontSize: 12,
                fontWeight: FontWeight.w700,
                color: Color(0xFF78350F),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _WhyChooseAdSection extends StatelessWidget {
  const _WhyChooseAdSection();

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isWide = constraints.maxWidth >= 980;

        if (!isWide) {
          return const Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              WhyChooseCard(scale: 0.6),
              SizedBox(height: 10),
              _FixedAdSpace(adPlacement: 'banner_why_choose_mobile'),
            ],
          );
        }

        return const Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 6,
              child: WhyChooseCard(scale: 0.6),
            ),
            SizedBox(width: 12),
            Expanded(
              flex: 6,
              child: Column(
                children: [
                  _FixedAdSpace(adPlacement: 'banner_why_choose_top'),
                  SizedBox(height: 10),
                  _FixedAdSpace(adPlacement: 'banner_why_choose_bottom'),
                ],
              ),
            ),
          ],
        );
      },
    );
  }
}

class _UsageTypeSelector extends StatelessWidget {
  final String? selectedType;
  final ValueChanged<String> onChanged;

  const _UsageTypeSelector({
    required this.selectedType,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    Widget buildTypeChip({required String label, required String subtitle}) {
      final selected = selectedType == label;
      return Expanded(
        child: InkWell(
          borderRadius: BorderRadius.circular(12),
          onTap: () => onChanged(label),
          child: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: selected ? const Color(0xFFE0F2FE) : Colors.white,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                color: selected ? const Color(0xFF0284C7) : const Color(0xFFD1D5DB),
                width: selected ? 1.6 : 1,
              ),
            ),
            child: Row(
              children: [
                Icon(
                  selected ? Icons.check_circle_rounded : Icons.radio_button_unchecked_rounded,
                  color: selected ? const Color(0xFF0284C7) : const Color(0xFF6B7280),
                  size: 18,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        label,
                        style: const TextStyle(
                          fontSize: 12,
                          fontWeight: FontWeight.w800,
                          color: Color(0xFF111827),
                        ),
                      ),
                      Text(
                        subtitle,
                        style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: Color(0xFF4B5563),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ),
      );
    }

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFF),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFDCE5F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Select Usage Type (Required)',
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w800,
              color: Color(0xFF1F2937),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              buildTypeChip(label: 'Personal', subtitle: 'Standard pricing'),
              const SizedBox(width: 8),
              buildTypeChip(label: 'Business', subtitle: 'Business pricing'),
            ],
          ),
        ],
      ),
    );
  }
}

class _PlanCardsSection extends StatelessWidget {
  final String proPrice;
  final String premiumPrice;
  final String lifetimePrice;
  final int discountPercent;
  final String selectedPlan;
  final String? usageType;
  final ValueChanged<String> onPlanSelected;

  const _PlanCardsSection({
    required this.proPrice,
    required this.premiumPrice,
    required this.lifetimePrice,
    required this.discountPercent,
    required this.selectedPlan,
    required this.usageType,
    required this.onPlanSelected,
  });

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final isWide = constraints.maxWidth > 980;
        final cards = [
          _PlanCardTile(
            title: 'Basic',
            subtitle: 'The basics for individuals and organizations',
            priceLine: '0 USD for 1 year access',
            buttonLabel: 'Start Basic',
            selected: selectedPlan == 'Basic',
            onSelected: () => onPlanSelected('Basic'),
          ),
          _PlanCardTile(
            title: 'Pro',
            subtitle: 'Advanced collaboration for growing teams',
            priceLine:
                '${discountPercent > 0 ? '(Coupon $discountPercent% OFF) ' : ''}$proPrice USD per user/month\nPay 10 months, get 12 months access',
            buttonLabel: 'Continue with Pro',
            selected: selectedPlan == 'Pro',
            onSelected: () => onPlanSelected('Pro'),
          ),
          _PlanCardTile(
            title: 'AI Premium',
            subtitle: 'Security, compliance, and AI-powered workflows',
            priceLine: '$premiumPrice USD per user/month\nPay 10 months, get 12 months access',
            buttonLabel: 'Start AI Premium',
            recommended: true,
            selected: selectedPlan == 'AI Premium',
            onSelected: () => onPlanSelected('AI Premium'),
          ),
          _PlanCardTile(
            title: 'AI Premium Lifetime',
            subtitle: 'One-time purchase for AI Premium forever access',
            priceLine: '$lifetimePrice USD one-time payment',
            buttonLabel: 'Start AI Premium Lifetime',
            selected: selectedPlan == 'Lifetime',
            onSelected: () => onPlanSelected('Lifetime'),
          ),
        ];

        if (isWide) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                children: [
                  for (var i = 0; i < cards.length; i++) ...[
                    Expanded(child: cards[i]),
                    if (i < cards.length - 1) const SizedBox(width: 10),
                  ],
                ],
              ),
              const SizedBox(height: 10),
              _buildFeatureListCta(context),
              const SizedBox(height: 8),
              if (usageType != null)
                Align(
                  alignment: Alignment.centerLeft,
                  child: Text(
                    usageType == 'Business'
                        ? 'Business mode active: business pricing applied.'
                        : 'Personal mode active: personal pricing applied.',
                    style: const TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF334155),
                    ),
                  ),
                ),
            ],
          );
        }

        return Column(
          children: [
            for (var i = 0; i < cards.length; i++) ...[
              cards[i],
              if (i < cards.length - 1) const SizedBox(height: 10),
            ],
            const SizedBox(height: 10),
            _buildFeatureListCta(context),
            const SizedBox(height: 8),
            if (usageType != null)
              Align(
                alignment: Alignment.centerLeft,
                child: Text(
                  usageType == 'Business'
                      ? 'Business mode active: business pricing applied.'
                      : 'Personal mode active: personal pricing applied.',
                  style: const TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF334155),
                  ),
                ),
              ),
          ],
        );
      },
    );
  }

  Widget _buildFeatureListCta(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(14),
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => const PlanFeaturesPage(),
          ),
        );
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 13),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: [Color(0xFFEFF6FF), Color(0xFFDCEAFE)],
          ),
          borderRadius: BorderRadius.circular(14),
          border: Border.all(color: const Color(0xFF93C5FD), width: 1.4),
          boxShadow: [
            BoxShadow(
              color: const Color(0xFF1D4ED8).withValues(alpha: 0.12),
              blurRadius: 12,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Row(
          children: [
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFFBFDBFE)),
              ),
              child: const Icon(
                Icons.list_alt_rounded,
                color: Color(0xFF1D4ED8),
                size: 19,
              ),
            ),
            const SizedBox(width: 10),
            const Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    'View Full Function List',
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      color: Color(0xFF1E3A8A),
                    ),
                  ),
                  SizedBox(height: 2),
                  Text(
                    'Basic / Pro / AI Premium tick-cross matrix',
                    style: TextStyle(
                      fontSize: 11,
                      fontWeight: FontWeight.w600,
                      color: Color(0xFF334155),
                    ),
                  ),
                ],
              ),
            ),
            const Icon(
              Icons.arrow_forward_ios_rounded,
              size: 13,
              color: Color(0xFF1D4ED8),
            ),
          ],
        ),
      ),
    );
  }
}

class _PlanCardTile extends StatelessWidget {
  final String title;
  final String subtitle;
  final String priceLine;
  final String buttonLabel;
  final bool recommended;
  final bool selected;
  final VoidCallback onSelected;

  const _PlanCardTile({
    required this.title,
    required this.subtitle,
    required this.priceLine,
    required this.buttonLabel,
    this.recommended = false,
    required this.selected,
    required this.onSelected,
  });

  @override
  Widget build(BuildContext context) {
    final bool isBasic = title == 'Basic';
    final bool isPro = title == 'Pro';

    final List<Color> backgroundGradient = recommended
        ? const [Color(0xFFEEF6FF), Color(0xFFDDEEFF)]
        : isPro
            ? const [Color(0xFFEFFCF8), Color(0xFFD8F5EC)]
            : const [Color(0xFFF8FAFC), Color(0xFFF1F5F9)];

    final Color outlineColor = selected
        ? const Color(0xFF0F766E)
        : (recommended
            ? const Color(0xFF1D74D8)
            : (isPro ? const Color(0xFF0F766E) : const Color(0xFFD1D5DB)));

    final Color accentColor = recommended
        ? const Color(0xFF1D74D8)
        : (isPro ? const Color(0xFF0F766E) : const Color(0xFF1F2937));

    final IconData planIcon = recommended
        ? Icons.auto_awesome_rounded
        : (isPro ? Icons.bolt_rounded : Icons.shield_outlined);

    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: backgroundGradient,
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: outlineColor,
          width: selected ? 2 : (recommended ? 2 : 1),
        ),
        boxShadow: [
          BoxShadow(
            color: accentColor.withOpacity(selected ? 0.22 : 0.12),
            blurRadius: selected ? 22 : 14,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (recommended)
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 6),
              decoration: const BoxDecoration(
                color: Color(0xFF1D74D8),
                borderRadius: BorderRadius.vertical(top: Radius.circular(14)),
              ),
              child: const Text(
                'RECOMMENDED',
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w800,
                  fontSize: 11,
                  letterSpacing: 0.4,
                ),
              ),
            ),
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 13),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      width: 34,
                      height: 34,
                      decoration: BoxDecoration(
                        color: Colors.white.withOpacity(0.9),
                        borderRadius: BorderRadius.circular(10),
                        border: Border.all(color: accentColor.withOpacity(0.25)),
                      ),
                      child: Icon(planIcon, color: accentColor, size: 20),
                    ),
                    const SizedBox(width: 10),
                    Expanded(
                      child: Text(
                        title,
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.w800,
                          color: Color(0xFF111827),
                        ),
                      ),
                    ),
                    if (selected)
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                        decoration: BoxDecoration(
                          color: accentColor,
                          borderRadius: BorderRadius.circular(999),
                        ),
                        child: const Text(
                          'Selected',
                          style: TextStyle(
                            fontSize: 10,
                            fontWeight: FontWeight.w800,
                            color: Colors.white,
                          ),
                        ),
                      ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  subtitle,
                  style: const TextStyle(
                    fontSize: 12,
                    color: Color(0xFF4B5563),
                    height: 1.35,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 11),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.88),
                    borderRadius: BorderRadius.circular(10),
                    border: Border.all(color: Colors.black.withOpacity(0.06)),
                  ),
                  child: Text(
                    priceLine,
                    style: const TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                      color: Color(0xFF111827),
                    ),
                  ),
                ),
                const SizedBox(height: 11),
                SizedBox(
                  width: double.infinity,
                  child: ElevatedButton(
                    onPressed: onSelected,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: selected ? accentColor : const Color(0xFF1F2937),
                      foregroundColor: Colors.white,
                      elevation: selected ? 2.5 : 1,
                      padding: const EdgeInsets.symmetric(vertical: 13),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
                    ),
                    child: Text(
                      buttonLabel,
                      style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _FixedAdSpaceState extends State<_FixedAdSpace> {
  String _title = 'Sponsored';
  String _subtitle = 'Loading ad slot...';
  String _provider = 'admob';

  @override
  void initState() {
    super.initState();
    _loadAdPayload();
  }

  Future<void> _loadAdPayload() async {
    final payload = await ApiService.getAdPlacementPayload(
      adPlacement: widget.adPlacement,
    );

    if (!mounted) {
      return;
    }

    setState(() {
      _title = payload['fallback_title']?.toString() ?? 'Sponsored';
      _subtitle = payload['fallback_text']?.toString() ?? 'Partner offer space (fixed slot).';
      _provider = payload['provider']?.toString() ?? 'admob';
    });

    await ApiService.trackAdInteraction(
      adPlacement: widget.adPlacement,
      interactionType: 'impression',
      provider: _provider,
    );
  }

  Future<void> _onTapAd() async {
    await ApiService.trackAdInteraction(
      adPlacement: widget.adPlacement,
      interactionType: 'click',
      provider: _provider,
    );

    if (!mounted) {
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Ad click tracked for $_provider (${widget.adPlacement}).'),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _onTapAd,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFFECFEFF), Color(0xFFEFF6FF)],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFBFDBFE)),
        ),
        child: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(
                Icons.campaign_rounded,
                color: Color(0xFF1D4ED8),
              ),
            ),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    _title,
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      color: Color(0xFF1E293B),
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    _subtitle,
                    style: const TextStyle(
                      fontSize: 11,
                      color: Color(0xFF475569),
                      height: 1.3,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(999),
              ),
              child: Text(
                _provider.toUpperCase(),
                style: const TextStyle(
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                  color: Color(0xFF1D4ED8),
                  letterSpacing: 0.3,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _IntegrationHubPanel extends StatefulWidget {
  const _IntegrationHubPanel();

  @override
  State<_IntegrationHubPanel> createState() => _IntegrationHubPanelState();
}

class _IntegrationHubPanelState extends State<_IntegrationHubPanel> {
  late final Future<List<IntegrationApp>> _appsFuture;

  @override
  void initState() {
    super.initState();
    _appsFuture = IntegrationHubService.getEnabledApps();
  }

  Future<void> _runFirstAction(IntegrationApp app) async {
    if (app.actions.isEmpty) {
      return;
    }

    final action = app.actions.first;
    final result = await IntegrationHubService.runAction(
      app: app,
      action: action,
      payload: {
        'source': 'jobready_v2',
        'trigger': 'manual_test',
      },
    );

    if (!mounted) {
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          '${app.name}: ${result['message'] ?? 'Integration action sent'}',
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder<List<IntegrationApp>>(
      future: _appsFuture,
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const SizedBox(
            height: 72,
            child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
          );
        }

        final apps = snapshot.data ?? const <IntegrationApp>[];
        if (apps.isEmpty) {
          return Container(
            width: double.infinity,
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: const Color(0xFFE5E7EB)),
            ),
            child: const Text(
              'No enabled integrations found in manifest.',
              style: TextStyle(
                color: Color(0xFF6B7280),
                fontSize: 12,
                fontWeight: FontWeight.w600,
              ),
            ),
          );
        }

        return Column(
          children: apps
              .map(
                (app) => Padding(
                  padding: const EdgeInsets.only(bottom: 8),
                  child: _IntegrationAppTile(
                    app: app,
                    onTap: () => _runFirstAction(app),
                  ),
                ),
              )
              .toList(),
        );
      },
    );
  }
}

class _BrowserSupportNotice extends StatelessWidget {
  const _BrowserSupportNotice();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFF),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFD8E6FF)),
      ),
      child: const Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            Icons.info_outline_rounded,
            color: Color(0xFF1F4E79),
            size: 18,
          ),
          SizedBox(width: 8),
          Expanded(
            child: Text(
              'Use latest Chrome or Edge for the smoothest and fastest file actions.',
              style: TextStyle(
                fontSize: 12,
                height: 1.35,
                color: Color(0xFF1F2937),
                fontWeight: FontWeight.w600,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _IntegrationAppTile extends StatelessWidget {
  final IntegrationApp app;
  final VoidCallback onTap;

  const _IntegrationAppTile({
    required this.app,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(16),
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFFF8FAFF), Color(0xFFFFFFFF)],
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: const Color(0xFFDCE5F0)),
        ),
        child: Row(
          children: [
            Container(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: const Color(0xFFE0EAFF),
                borderRadius: BorderRadius.circular(10),
              ),
              child: const Icon(
                Icons.hub_rounded,
                color: Color(0xFF1D4ED8),
                size: 19,
              ),
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    app.name,
                    style: const TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.w800,
                      color: Color(0xFF1F2937),
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    '${app.auth.displayLabel} | ${app.actions.length} actions',
                    style: const TextStyle(
                      fontSize: 11,
                      color: Color(0xFF6B7280),
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(
              Icons.arrow_forward_ios_rounded,
              size: 14,
              color: Color(0xFF64748B),
            ),
          ],
        ),
      ),
    );
  }
}

class _GatewayControlPanel extends StatefulWidget {
  final String activeGateway;
  final ValueChanged<String> onGatewayChanged;

  const _GatewayControlPanel({
    required this.activeGateway,
    required this.onGatewayChanged,
  });

  @override
  State<_GatewayControlPanel> createState() => _GatewayControlPanelState();
}

class _GatewayControlPanelState extends State<_GatewayControlPanel> {
  static const String _ownerCode = 'JR-OWNER-2026';
  final TextEditingController _ownerCodeController = TextEditingController();
  bool _isOwnerUnlocked = false;
  String _statusText = 'Owner lock active';

  @override
  void dispose() {
    _ownerCodeController.dispose();
    super.dispose();
  }

  void _unlockOwner() {
    final isValid = _ownerCodeController.text.trim() == _ownerCode;
    setState(() {
      _isOwnerUnlocked = isValid;
      _statusText = isValid
          ? 'Owner unlocked. You can switch payment gateway now.'
          : 'Invalid owner code';
    });
  }

  void _setGateway(String gateway) {
    final result = ApiService.setActivePaymentGateway(gateway);
    if (result['status'] == 'success') {
      final updated = result['gateway']?.toString() ?? gateway;
      widget.onGatewayChanged(updated);
    }

    final message = result['message']?.toString() ?? 'Gateway update failed';
    setState(() {
      _statusText = message;
    });

    if (!mounted) {
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    final gateways = ApiService.getSupportedPaymentGateways();

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [Color(0xFFECFEFF), Color(0xFFF8FAFF)],
        ),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFCFFAFE)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Owner Payment Gateway Control',
            style: TextStyle(
              fontWeight: FontWeight.w800,
              fontSize: 14,
              color: Color(0xFF0F172A),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'Active gateway: ${widget.activeGateway.toUpperCase()}',
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: Color(0xFF0F766E),
            ),
          ),
          const SizedBox(height: 10),
          if (!_isOwnerUnlocked) ...[
            TextField(
              controller: _ownerCodeController,
              obscureText: true,
              decoration: InputDecoration(
                hintText: 'Enter owner code',
                isDense: true,
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _unlockOwner,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1F4E79),
                  foregroundColor: Colors.white,
                ),
                child: const Text('Unlock Owner Controls'),
              ),
            ),
          ] else ...[
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: gateways
                  .map(
                    (gateway) => ChoiceChip(
                      label: Text(gateway.toUpperCase()),
                      selected: widget.activeGateway == gateway,
                      onSelected: (_) => _setGateway(gateway),
                    ),
                  )
                  .toList(),
            ),
          ],
          const SizedBox(height: 8),
          Text(
            _statusText,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w600,
              color: _statusText.toLowerCase().contains('invalid')
                  ? const Color(0xFFB91C1C)
                  : const Color(0xFF475569),
            ),
          ),
        ],
      ),
    );
  }
}

class _OwnerIntegrationHubPanel extends StatefulWidget {
  const _OwnerIntegrationHubPanel();

  @override
  State<_OwnerIntegrationHubPanel> createState() => _OwnerIntegrationHubPanelState();
}

class _OwnerIntegrationHubPanelState extends State<_OwnerIntegrationHubPanel> {
  static const String _ownerCode = 'JR-OWNER-2026';
  final TextEditingController _ownerCodeController = TextEditingController();
  bool _isUnlocked = false;
  String _status = 'Integration Hub is owner-only.';

  @override
  void dispose() {
    _ownerCodeController.dispose();
    super.dispose();
  }

  void _unlock() {
    final ok = _ownerCodeController.text.trim() == _ownerCode;
    setState(() {
      _isUnlocked = ok;
      _status = ok ? 'Owner unlocked.' : 'Invalid owner code';
    });
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFF9FAFB),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE5E7EB)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Owner Integration Hub',
            style: TextStyle(
              fontSize: 14,
              fontWeight: FontWeight.w800,
              color: Color(0xFF111827),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            _status,
            style: TextStyle(
              fontSize: 12,
              color: _status.toLowerCase().contains('invalid')
                  ? const Color(0xFFB91C1C)
                  : const Color(0xFF4B5563),
              fontWeight: FontWeight.w600,
            ),
          ),
          const SizedBox(height: 10),
          if (!_isUnlocked) ...[
            TextField(
              controller: _ownerCodeController,
              obscureText: true,
              decoration: InputDecoration(
                hintText: 'Enter owner code',
                isDense: true,
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _unlock,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF1F4E79),
                  foregroundColor: Colors.white,
                ),
                child: const Text('Unlock Integration Hub'),
              ),
            ),
          ] else ...[
            const _SectionHeader(
              title: 'Integration Hub',
              subtitle: 'Connect external apps via API manifest, without future UI code changes.',
            ),
            const SizedBox(height: 8),
            const _IntegrationHubPanel(),
          ],
        ],
      ),
    );
  }
}

class _UserPaymentPanel extends StatelessWidget {
  final String activeGateway;
  final String selectedPlan;
  final String? usageType;
  final double proMonthlyPrice;
  final double premiumMonthlyPrice;
  final double lifetimePlanPrice;
  final ValueChanged<String> onPlanChanged;
  final ValueChanged<String> onUsageTypeChanged;

  const _UserPaymentPanel({
    required this.activeGateway,
    required this.selectedPlan,
    required this.usageType,
    required this.proMonthlyPrice,
    required this.premiumMonthlyPrice,
    required this.lifetimePlanPrice,
    required this.onPlanChanged,
    required this.onUsageTypeChanged,
  });

  String _formatUsd(double amount) {
    final rounded = amount.roundToDouble();
    if (amount == rounded) {
      return '\$${amount.toStringAsFixed(0)}';
    }
    return '\$${amount.toStringAsFixed(2)}';
  }

  double _monthlyForPlan(String plan) {
    if (plan == 'Pro') return proMonthlyPrice;
    if (plan == 'AI Premium') return premiumMonthlyPrice;
    return 0;
  }

  bool _isSubscriptionPlan(String plan) {
    return plan == 'Pro' || plan == 'AI Premium';
  }

  double _chargeAmountForPlan(String plan) {
    if (plan == 'Lifetime') {
      return lifetimePlanPrice;
    }
    return _monthlyForPlan(plan) * 10;
  }

  Future<void> _continueToPayment(BuildContext context) async {
    if (usageType == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please select Personal or Business first.')),
      );
      return;
    }

    if (selectedPlan == 'Basic') {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Basic plan is free for 1 year. No payment required.')),
      );
      return;
    }

    final amount = _chargeAmountForPlan(selectedPlan);
    final order = await ApiService.createPaymentOrder(
      gateway: activeGateway,
      planId: selectedPlan.toLowerCase().replaceAll(' ', '_'),
      amount: amount,
      customerEmail: PublicBrandConfig.supportEmail,
      customerName: 'JOBREADY User',
      metadata: {
        'source': 'v2_payment_panel',
        'usage_type': usageType,
        'billing_model': _isSubscriptionPlan(selectedPlan) ? 'annual_10_for_12' : 'one_time',
        'billing_months': _isSubscriptionPlan(selectedPlan) ? 12 : 0,
        'payable_months': _isSubscriptionPlan(selectedPlan) ? 10 : 1,
      },
    );

    if (!context.mounted) {
      return;
    }

    final message = order['message']?.toString() ?? 'Payment request created.';
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Gateway ${activeGateway.toUpperCase()}: $message')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFEEF2FF),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFC7D2FE)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Selected payment gateway: ${activeGateway.toUpperCase()}',
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w800,
              color: Color(0xFF1E1B4B),
            ),
          ),
          const SizedBox(height: 8),
          const Text(
            'Usage Type',
            style: TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w700,
              color: Color(0xFF334155),
            ),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: ChoiceChip(
                  label: const Text('Personal'),
                  selected: usageType == 'Personal',
                  onSelected: (_) => onUsageTypeChanged('Personal'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: ChoiceChip(
                  label: const Text('Business'),
                  selected: usageType == 'Business',
                  onSelected: (_) => onUsageTypeChanged('Business'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          DropdownButtonFormField<String>(
            value: selectedPlan,
            items: [
              const DropdownMenuItem(value: 'Basic', child: Text('Basic (Free for 1 Year)')),
              DropdownMenuItem(
                value: 'Pro',
                child: Text('Pro (${_formatUsd(proMonthlyPrice)}/month)'),
              ),
              DropdownMenuItem(
                value: 'AI Premium',
                child: Text('AI Premium (${_formatUsd(premiumMonthlyPrice)}/month)'),
              ),
              DropdownMenuItem(
                value: 'Lifetime',
                child: Text('Lifetime (${_formatUsd(lifetimePlanPrice)} one-time)'),
              ),
            ],
            onChanged: (value) {
              if (value != null) {
                onPlanChanged(value);
              }
            },
            decoration: InputDecoration(
              labelText: 'Choose plan',
              isDense: true,
              filled: true,
              fillColor: Colors.white,
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
            ),
          ),
          const SizedBox(height: 10),
          if (selectedPlan != 'Basic')
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: const Color(0xFFE0F2FE),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: const Color(0xFF7DD3FC)),
              ),
              child: Text(
                _isSubscriptionPlan(selectedPlan)
                    ? 'Offer active: Pay for 10 months (${_formatUsd(_monthlyForPlan(selectedPlan) * 10)}) and get 12 months access.'
                    : 'One-time Lifetime plan payment: ${_formatUsd(lifetimePlanPrice)}.',
                style: const TextStyle(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: Color(0xFF0C4A6E),
                ),
              ),
            ),
          if (selectedPlan != 'Basic') const SizedBox(height: 10),
          SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              onPressed: () => _continueToPayment(context),
              icon: const Icon(Icons.payments_rounded),
              label: const Text('Continue to Payment'),
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF1F4E79),
                foregroundColor: Colors.white,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _OwnerOfferManagerPanel extends StatefulWidget {
  final String ownerCode;
  final void Function(bool enabled, String offerText, String promoCode, Duration? validity)
      onOfferUpdated;

  const _OwnerOfferManagerPanel({
    required this.ownerCode,
    required this.onOfferUpdated,
  });

  @override
  State<_OwnerOfferManagerPanel> createState() => _OwnerOfferManagerPanelState();
}

class _OwnerOfferManagerPanelState extends State<_OwnerOfferManagerPanel> {
  final TextEditingController _unlockController = TextEditingController();
  final TextEditingController _offerController = TextEditingController();
  final TextEditingController _promoController = TextEditingController(text: 'JRFREE1001Y');
  bool _unlocked = false;
  bool _showOffer = false;
  Duration? _validity = const Duration(days: 365);

  @override
  void dispose() {
    _unlockController.dispose();
    _offerController.dispose();
    _promoController.dispose();
    super.dispose();
  }

  void _unlock() {
    setState(() {
      _unlocked = _unlockController.text.trim() == widget.ownerCode;
    });
  }

  void _applyOffer() {
    widget.onOfferUpdated(
      _showOffer,
      _offerController.text,
      _promoController.text,
      _validity,
    );

    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Offer and promo settings updated on home page.')),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFC),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE2E8F0)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            'Owner Offer & Promo Box',
            style: TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF0F172A)),
          ),
          const SizedBox(height: 8),
          if (!_unlocked) ...[
            TextField(
              controller: _unlockController,
              obscureText: true,
              decoration: InputDecoration(
                hintText: 'Enter owner code',
                isDense: true,
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
            const SizedBox(height: 8),
            ElevatedButton(
              onPressed: _unlock,
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF1F4E79), foregroundColor: Colors.white),
              child: const Text('Unlock Offer Box'),
            ),
          ] else ...[
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              value: _showOffer,
              onChanged: (value) => setState(() => _showOffer = value),
              title: const Text('Show offer on home page'),
            ),
            TextField(
              controller: _offerController,
              maxLines: 2,
              decoration: InputDecoration(
                hintText: 'Write offer text here (New Year, Diwali, etc.)',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _promoController,
              decoration: InputDecoration(
                hintText: 'Promo code (example: NEWYEAR100)',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
            const SizedBox(height: 8),
            DropdownButtonFormField<Duration?>(
              value: _validity,
              items: const [
                DropdownMenuItem<Duration?>(value: Duration(days: 365), child: Text('1 Year')),
                DropdownMenuItem<Duration?>(value: Duration(days: 30), child: Text('1 Month')),
                DropdownMenuItem<Duration?>(value: Duration(days: 7), child: Text('1 Week')),
              ],
              onChanged: (value) => setState(() => _validity = value),
              decoration: InputDecoration(
                labelText: 'Promo validity',
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
              ),
            ),
            const SizedBox(height: 8),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton.icon(
                onPressed: _applyOffer,
                icon: const Icon(Icons.publish_rounded),
                label: const Text('Publish Offer & Promo'),
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF1F4E79), foregroundColor: Colors.white),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _AboutUsSection extends StatelessWidget {
  const _AboutUsSection();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE5E7EB)),
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('About Us', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Color(0xFF1F2937))),
          SizedBox(height: 6),
          Text(
            'JOBREADY helps users process documents faster with reliable tools for conversion, compression, and premium workflow automation. We focus on simple steps, stable output quality, and practical productivity for individuals and teams.',
            style: TextStyle(fontSize: 13, height: 1.4, color: Color(0xFF4B5563)),
          ),
        ],
      ),
    );
  }
}

class _FuturePlanSection extends StatelessWidget {
  const _FuturePlanSection();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: const Color(0xFFF8FAFF),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFDCE5F0)),
      ),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text('Future Plan', style: TextStyle(fontSize: 18, fontWeight: FontWeight.w800, color: Color(0xFF1F2937))),
          SizedBox(height: 6),
          Text(
            'Our new Version 2 will deliver a cleaner workspace, stronger payment and plan controls, deeper API integrations, and better performance across browsers. It will include smarter sharing options, offer automation, and owner-level controls for promotions and gateway switching. We are also expanding enterprise-ready features with better operational controls and launch runbooks. The goal is a faster, simpler, and more scalable experience for all users.',
            style: TextStyle(fontSize: 13, height: 1.45, color: Color(0xFF4B5563)),
          ),
        ],
      ),
    );
  }
}

class _SuggestionSection extends StatelessWidget {
  final VoidCallback onTap;

  const _SuggestionSection({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      child: ElevatedButton.icon(
        onPressed: onTap,
        icon: const Icon(Icons.feedback_outlined),
        label: const Text('Send Suggestion'),
        style: ElevatedButton.styleFrom(
          backgroundColor: const Color(0xFF111827),
          foregroundColor: Colors.white,
          padding: const EdgeInsets.symmetric(vertical: 12),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        ),
      ),
    );
  }
}

class _FooterBadge extends StatelessWidget {
  final String label;

  const _FooterBadge({required this.label});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: const Color(0xFFE5E7EB)),
      ),
      child: Text(
        label,
        style: const TextStyle(
          fontSize: 10,
          fontWeight: FontWeight.w800,
          letterSpacing: 0.8,
          color: Color(0xFF1F4E79),
        ),
      ),
    );
  }
}

class _FooterInfoRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String value;

  const _FooterInfoRow({
    required this.icon,
    required this.label,
    required this.value,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.85),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFE5E7EB)),
      ),
      child: Row(
        children: [
          Container(
            width: 38,
            height: 38,
            decoration: BoxDecoration(
              color: const Color(0xFFFFF4CC),
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(icon, size: 18, color: const Color(0xFFFFC72C)),
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: const TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF6B7280),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  value,
                  style: const TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF1F4E79),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TopActionIcon extends StatelessWidget {
  final String tooltip;
  final IconData icon;
  final Color iconColor;
  final VoidCallback onTap;

  const _TopActionIcon({
    required this.tooltip,
    required this.icon,
    required this.iconColor,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 10),
      child: Tooltip(
        message: tooltip,
        child: Material(
          color: Colors.transparent,
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(10),
            child: Ink(
              width: 34,
              height: 34,
              decoration: BoxDecoration(
                color: const Color(0xFF142033),
                borderRadius: BorderRadius.circular(10),
                border: Border.all(color: Colors.white.withOpacity(0.18)),
              ),
              child: Icon(
                icon,
                size: 19,
                color: iconColor,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _CouponControlPanel extends StatefulWidget {
  final ValueChanged<int> onDiscountChanged;

  const _CouponControlPanel({required this.onDiscountChanged});

  @override
  State<_CouponControlPanel> createState() => _CouponControlPanelState();
}

class _CouponControlPanelState extends State<_CouponControlPanel> {
  final TextEditingController _couponInputController = TextEditingController();
  final TextEditingController _discountInputController = TextEditingController(text: '20');
  static const String _ownerAccessCode = String.fromEnvironment('OWNER_ACCESS_CODE');

  int _selectedDiscount = 20;
  Duration? _selectedValidity;
  bool _isSettingsSaved = false;
  bool _isAdminUnlocked = false;
  bool _isPanelExpanded = false;
  CouponData? _lastGenerated;
  String _applyMessage = 'Generate coupon or redeem existing one-time code';
  int _appliedDiscount = 0;

  @override
  void dispose() {
    _couponInputController.dispose();
    _discountInputController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final coupons = CouponService.getAllCoupons();

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: const Color(0xFFE5E7EB)),
        boxShadow: [
          BoxShadow(
            color: const Color(0xFF1F2937).withOpacity(0.06),
            blurRadius: 16,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const Expanded(
                child: Text(
                  'Coupon Control',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    color: Color(0xFF1F2937),
                  ),
                ),
              ),
              TextButton.icon(
                onPressed: () {
                  setState(() {
                    _isPanelExpanded = !_isPanelExpanded;
                  });
                },
                icon: Icon(
                  _isPanelExpanded ? Icons.expand_less_rounded : Icons.expand_more_rounded,
                  size: 16,
                ),
                label: Text(_isPanelExpanded ? 'Hide' : 'Show'),
                style: TextButton.styleFrom(
                  foregroundColor: const Color(0xFF1F4E79),
                  visualDensity: VisualDensity.compact,
                ),
              ),
            ],
          ),
          if (!_isPanelExpanded)
            const Padding(
              padding: EdgeInsets.only(top: 2),
              child: Text(
                'Promo section minimized. Expand when needed.',
                style: TextStyle(fontSize: 11, color: Color(0xFF6B7280)),
              ),
            ),
          if (_isPanelExpanded) ...[
            const SizedBox(height: 4),
            Row(
              children: [
                const Expanded(
                  child: Text(
                    'Users can redeem promo code here. Owner controls are protected.',
                    style: TextStyle(
                      fontSize: 12,
                      color: Color(0xFF6B7280),
                    ),
                  ),
                ),
                const SizedBox(width: 10),
                OutlinedButton.icon(
                  onPressed: _toggleOwnerAccess,
                  icon: Icon(_isAdminUnlocked ? Icons.lock_open_rounded : Icons.lock_rounded, size: 16),
                  label: Text(_isAdminUnlocked ? 'Owner On' : 'Owner'),
                  style: OutlinedButton.styleFrom(
                    foregroundColor: const Color(0xFF1F4E79),
                    side: const BorderSide(color: Color(0xFF1F4E79)),
                    visualDensity: VisualDensity.compact,
                  ),
                ),
              ],
            ),
            if (_isAdminUnlocked) ...[
            const SizedBox(height: 8),
            Theme(
              data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
              child: ExpansionTile(
                tilePadding: const EdgeInsets.symmetric(horizontal: 0, vertical: 0),
                childrenPadding: const EdgeInsets.only(bottom: 8),
                title: const Text(
                  'Owner Tools',
                  style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800, color: Color(0xFF1F4E79)),
                ),
                subtitle: const Text(
                  'Expand only when needed',
                  style: TextStyle(fontSize: 10, color: Color(0xFF64748B)),
                ),
                children: [
                  TextField(
                    controller: _discountInputController,
                    keyboardType: TextInputType.number,
                    onChanged: (_) {
                      setState(() {
                        _isSettingsSaved = false;
                      });
                    },
                    decoration: InputDecoration(
                      labelText: 'Discount Percentage',
                      hintText: 'Enter value between 1 and 100',
                      suffixText: '%',
                      isDense: true,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
                      focusedBorder: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                        borderSide: const BorderSide(color: Color(0xFF007AFF), width: 1.4),
                      ),
                    ),
                  ),
                  const SizedBox(height: 10),
                  const Align(
                    alignment: Alignment.centerLeft,
                    child: Text(
                      'Validity Window',
                      style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Color(0xFF374151)),
                    ),
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      _validityChip('24 Hours', const Duration(hours: 24)),
                      _validityChip('1 Week', const Duration(days: 7)),
                      _validityChip('1 Month', const Duration(days: 30)),
                      _validityChip('No Expiry', null),
                    ],
                  ),
                  const SizedBox(height: 10),
                  SizedBox(
                    width: double.infinity,
                    child: OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(
                        foregroundColor: const Color(0xFF1F4E79),
                        side: const BorderSide(color: Color(0xFF1F4E79)),
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: _savePromoSettings,
                      icon: const Icon(Icons.save_outlined, size: 16),
                      label: const Text(
                        'Save Promo Settings',
                        style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
                      ),
                    ),
                  ),
                  const SizedBox(height: 8),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: const Color(0xFF007AFF),
                        foregroundColor: Colors.white,
                        padding: const EdgeInsets.symmetric(vertical: 10),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                      ),
                      onPressed: _generateCoupon,
                      icon: const Icon(Icons.local_offer_rounded, size: 16),
                      label: const Text(
                        'Create Promo Code',
                        style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
                      ),
                    ),
                  ),
                  if (_lastGenerated != null) ...[
                    const SizedBox(height: 8),
                    Container(
                      width: double.infinity,
                      padding: const EdgeInsets.all(8),
                      decoration: BoxDecoration(
                        color: const Color(0xFFEFF7FF),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: const Color(0xFFCCE7FF)),
                      ),
                      child: SelectableText(
                        'Latest: ${_lastGenerated!.code}  (${_lastGenerated!.discountPercent}% OFF)  '
                        '${_formatExpiryText(_lastGenerated!)}',
                        style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF1F4E79),
                        ),
                      ),
                    ),
                  ],
                  if (coupons.isNotEmpty) ...[
                    const SizedBox(height: 10),
                    const Align(
                      alignment: Alignment.centerLeft,
                      child: Text(
                        'Generated Coupons',
                        style: TextStyle(fontSize: 12, fontWeight: FontWeight.w800),
                      ),
                    ),
                    const SizedBox(height: 8),
                    ...coupons.take(5).map(_couponRow),
                  ],
                ],
              ),
            ),
            ],
            const SizedBox(height: 8),
            TextField(
            controller: _couponInputController,
            decoration: InputDecoration(
              hintText: 'Enter coupon code',
              isDense: true,
              contentPadding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
              border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
              focusedBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(12),
                borderSide: const BorderSide(color: Color(0xFF007AFF), width: 1.4),
              ),
            ),
            ),
            const SizedBox(height: 6),
            SizedBox(
            width: double.infinity,
            child: ElevatedButton.icon(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF1F4E79),
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 9),
                shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
              ),
              onPressed: _redeemCoupon,
              icon: const Icon(Icons.check_circle_outline, size: 16),
              label: const Text(
                'Redeem Promo Code',
                style: TextStyle(fontWeight: FontWeight.w700, fontSize: 12),
              ),
            ),
            ),
            const SizedBox(height: 6),
            Container(
            width: double.infinity,
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: _appliedDiscount > 0 ? const Color(0xFFEAFBF0) : const Color(0xFFFFF4F4),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(
                color: _appliedDiscount > 0 ? const Color(0xFFB9F3CC) : const Color(0xFFFECACA),
              ),
            ),
            child: Text(
              _applyMessage,
              style: TextStyle(
                fontSize: 11,
                color: _appliedDiscount > 0 ? const Color(0xFF166534) : const Color(0xFFB91C1C),
                fontWeight: FontWeight.w700,
              ),
            ),
            ),
          ],
        ],
      ),
    );
  }

  void _toggleOwnerAccess() {
    if (_isAdminUnlocked) {
      setState(() {
        _isAdminUnlocked = false;
      });
      return;
    }

    if (_ownerAccessCode.trim().isEmpty) {
      setState(() {
        _applyMessage = 'Owner access is disabled. Start app with --dart-define=OWNER_ACCESS_CODE=YourCode';
        _appliedDiscount = 0;
      });
      return;
    }

    _showOwnerAccessDialog();
  }

  void _showOwnerAccessDialog() {
    final pinController = TextEditingController();

    showDialog(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('Owner Access'),
        content: TextField(
          controller: pinController,
          obscureText: true,
          decoration: const InputDecoration(
            hintText: 'Enter owner code',
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('Cancel'),
          ),
          ElevatedButton(
            onPressed: () {
              final code = pinController.text.trim();
              Navigator.of(dialogContext).pop();
              if (code == _ownerAccessCode) {
                setState(() {
                  _isAdminUnlocked = true;
                });
              } else {
                setState(() {
                  _applyMessage = 'Invalid owner code';
                  _appliedDiscount = 0;
                });
              }
            },
            child: const Text('Unlock'),
          ),
        ],
      ),
    ).then((_) {
      pinController.dispose();
    });
  }

  Widget _validityChip(String label, Duration? validity) {
    final selected = _selectedValidity == validity;
    return ChoiceChip(
      selected: selected,
      onSelected: (_) {
        setState(() {
          _selectedValidity = validity;
          _isSettingsSaved = false;
        });
      },
      label: Text(label),
      labelStyle: TextStyle(
        color: selected ? Colors.white : const Color(0xFF1F2937),
        fontWeight: FontWeight.w700,
      ),
      selectedColor: const Color(0xFF007AFF),
      backgroundColor: const Color(0xFFF3F4F6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(999)),
      side: BorderSide.none,
    );
  }

  String _formatExpiryText(CouponData coupon) {
    if (coupon.expiresAt == null) {
      return 'No expiry';
    }

    final remaining = coupon.expiresAt!.difference(coupon.createdAt);
    if (remaining.inHours <= 24) {
      return 'Valid 24 hours';
    }
    if (remaining.inDays <= 7) {
      return 'Valid 1 week';
    }
    if (remaining.inDays <= 31) {
      return 'Valid 1 month';
    }
    return 'Expiry set';
  }

  String _currentValidityLabel() {
    if (_selectedValidity == null) {
      return 'No expiry';
    }
    if (_selectedValidity == const Duration(hours: 24)) {
      return '24 hours';
    }
    if (_selectedValidity == const Duration(days: 7)) {
      return '1 week';
    }
    if (_selectedValidity == const Duration(days: 30)) {
      return '1 month';
    }
    return 'Custom';
  }

  Widget _couponRow(CouponData coupon) {
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: const Color(0xFFF9FAFB),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFFE5E7EB)),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              '${coupon.code}  (${coupon.discountPercent}%)',
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
            ),
          ),
          Text(
            coupon.statusLabel,
            style: TextStyle(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: coupon.isActive ? const Color(0xFF166534) : const Color(0xFF991B1B),
            ),
          ),
        ],
      ),
    );
  }

  void _generateCoupon() {
    if (!_isSettingsSaved) {
      setState(() {
        _appliedDiscount = 0;
        _applyMessage = 'Save promo settings first before creating a promo code';
      });
      widget.onDiscountChanged(0);
      return;
    }

    final coupon = CouponService.generateCoupon(
      discountPercent: _selectedDiscount,
      validFor: _selectedValidity,
    );

    setState(() {
      _lastGenerated = coupon;
      _applyMessage = 'Generated ${coupon.code} (${coupon.discountPercent}% OFF, ${_currentValidityLabel()})';
      _appliedDiscount = 0;
    });
    widget.onDiscountChanged(0);
  }

  void _savePromoSettings() {
    final discount = int.tryParse(_discountInputController.text.trim());

    if (discount == null || discount < 1 || discount > 100) {
      setState(() {
        _isSettingsSaved = false;
        _appliedDiscount = 0;
        _applyMessage = 'Enter a valid discount between 1% and 100%';
      });
      widget.onDiscountChanged(0);
      return;
    }

    setState(() {
      _selectedDiscount = discount;
      _isSettingsSaved = true;
      _appliedDiscount = 0;
      _applyMessage = 'Promo settings saved: ${discount}% OFF, ${_currentValidityLabel()}';
    });
    widget.onDiscountChanged(0);
  }

  void _redeemCoupon() {
    final result = CouponService.redeemCoupon(_couponInputController.text);
    setState(() {
      _applyMessage = result.message;
      _appliedDiscount = result.valid ? result.discountPercent : 0;
    });
    widget.onDiscountChanged(result.valid ? result.discountPercent : 0);
  }
}

class _V2Column extends StatelessWidget {
  const _V2Column();

  @override
  Widget build(BuildContext context) {
    return const Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        UploadCardV2(),
        SizedBox(height: 10),
        ToolSelectorV2(),
      ],
    );
  }
}

class _SectionHeader extends StatelessWidget {
  final String title;
  final String subtitle;

  const _SectionHeader({
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 20,
            fontWeight: FontWeight.bold,
            color: Color(0xFF1F2937),
          ),
        ),
        const SizedBox(height: 4),
        Text(
          subtitle,
          style: const TextStyle(
            fontSize: 12,
            color: Colors.grey,
          ),
        ),
      ],
    );
  }
}
