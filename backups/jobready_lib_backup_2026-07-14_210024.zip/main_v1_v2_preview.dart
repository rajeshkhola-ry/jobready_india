import 'package:flutter/material.dart';

import 'Pages/compression_benchmark_page.dart';
import 'Pages/compression_tool_page.dart';
import 'Pages/convert_tool_page.dart';
import 'Pages/extract_tool_page.dart';
import 'Pages/home_page.dart';
import 'Pages/home_page_v2.dart';
import 'Pages/merge_tool_page.dart';
import 'Pages/pdf_tools_page.dart';
import 'Pages/split_tool_page.dart';
import 'Pages/system_check_page.dart';

void main() {
  runApp(const JobReadyPreviewApp());
}

class JobReadyPreviewApp extends StatelessWidget {
  const JobReadyPreviewApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'JOBREADY Preview Hub',
      theme: ThemeData(
        scaffoldBackgroundColor: const Color(0xFFF8F9FA),
        useMaterial3: true,
      ),
      home: const V1V2PreviewHubPage(),
    );
  }
}

class V1V2PreviewHubPage extends StatelessWidget {
  const V1V2PreviewHubPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('JOBREADY V1 + V2 Preview Hub'),
        backgroundColor: const Color(0xFF1F2937),
        foregroundColor: Colors.white,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _sectionTitle(
              title: 'V1 Launch Build (Kept Separate)',
              subtitle: 'Use this section to verify only V1 launch-safe screens.',
            ),
            const SizedBox(height: 10),
            _buttonGrid(
              children: [
                _navButton(
                  context,
                  label: 'Open V1 Home',
                  icon: Icons.home_rounded,
                  page: const HomePage(),
                ),
                _navButton(
                  context,
                  label: 'System Check',
                  icon: Icons.health_and_safety_rounded,
                  page: const SystemCheckPage(),
                ),
                _navButton(
                  context,
                  label: 'PDF Tools',
                  icon: Icons.picture_as_pdf_rounded,
                  page: const PdfToolsPage(),
                ),
              ],
            ),
            const SizedBox(height: 20),
            _sectionTitle(
              title: 'V2 Working Build',
              subtitle: 'Use this section to verify V2 home and complete tool routing.',
            ),
            const SizedBox(height: 10),
            _buttonGrid(
              children: [
                _navButton(
                  context,
                  label: 'Open V2 Home',
                  icon: Icons.home_filled,
                  page: const HomePageV2(),
                ),
                _navButton(
                  context,
                  label: 'Compression Tool',
                  icon: Icons.compress_rounded,
                  page: const CompressionToolPage(),
                ),
                _navButton(
                  context,
                  label: 'Convert Tool',
                  icon: Icons.swap_horiz_rounded,
                  page: const ConvertToolPage(),
                ),
                _navButton(
                  context,
                  label: 'Merge Tool',
                  icon: Icons.merge_type_rounded,
                  page: const MergeToolPage(),
                ),
                _navButton(
                  context,
                  label: 'Split Tool',
                  icon: Icons.content_cut_rounded,
                  page: const SplitToolPage(),
                ),
                _navButton(
                  context,
                  label: 'Extract Tool',
                  icon: Icons.description_rounded,
                  page: const ExtractToolPage(),
                ),
                _navButton(
                  context,
                  label: 'PDF Tools',
                  icon: Icons.picture_as_pdf_rounded,
                  page: const PdfToolsPage(),
                ),
                _navButton(
                  context,
                  label: 'Benchmark',
                  icon: Icons.bar_chart_rounded,
                  page: const CompressionBenchmarkPage(),
                ),
              ],
            ),
            const SizedBox(height: 20),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFEFF6FF),
                border: Border.all(color: const Color(0xFFBFDBFE)),
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Text(
                'Run this file tomorrow morning to test V1 and V2 separately without changing your launch files.',
                style: TextStyle(
                  color: Color(0xFF1E3A8A),
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _sectionTitle({required String title, required String subtitle}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: const TextStyle(
            fontSize: 18,
            fontWeight: FontWeight.w800,
            color: Color(0xFF111827),
          ),
        ),
        const SizedBox(height: 4),
        Text(
          subtitle,
          style: const TextStyle(
            fontSize: 12,
            color: Color(0xFF6B7280),
          ),
        ),
      ],
    );
  }

  Widget _buttonGrid({required List<Widget> children}) {
    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      mainAxisSpacing: 10,
      crossAxisSpacing: 10,
      childAspectRatio: 2.2,
      children: children,
    );
  }

  Widget _navButton(
    BuildContext context, {
    required String label,
    required IconData icon,
    required Widget page,
  }) {
    return FilledButton.icon(
      onPressed: () {
        Navigator.push(
          context,
          MaterialPageRoute(builder: (_) => page),
        );
      },
      icon: Icon(icon),
      label: Text(
        label,
        textAlign: TextAlign.center,
      ),
      style: FilledButton.styleFrom(
        backgroundColor: const Color(0xFF1F4E79),
        foregroundColor: Colors.white,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(12),
        ),
      ),
    );
  }
}
