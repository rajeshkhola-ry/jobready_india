import 'package:flutter/material.dart';

class PlanFeaturesPage extends StatelessWidget {
  const PlanFeaturesPage({super.key});

  @override
  Widget build(BuildContext context) {
    final features = <_PlanFeature>[
      const _PlanFeature(name: 'PDF Compress (Single File)', basic: true, pro: true, premium: true),
      const _PlanFeature(name: 'Batch Compress (Multiple Files)', basic: false, pro: false, premium: true),
      const _PlanFeature(name: 'Convert PDF / Word / Image', basic: true, pro: true, premium: true),
      const _PlanFeature(name: 'Merge PDFs', basic: true, pro: true, premium: true),
      const _PlanFeature(name: 'Split PDFs', basic: true, pro: true, premium: true),
      const _PlanFeature(name: 'Extract PDF Text & Images', basic: true, pro: true, premium: true),
      const _PlanFeature(name: 'PDF to PDF Tools (Edit, Save & Download)', basic: false, pro: false, premium: true),
      const _PlanFeature(name: 'Higher Daily Usage Limit', basic: false, pro: true, premium: true),
      const _PlanFeature(name: 'Priority Processing Queue', basic: false, pro: true, premium: true),
      const _PlanFeature(name: 'Advanced Quality Controls', basic: false, pro: true, premium: true),
      const _PlanFeature(name: 'AI-Assisted Document Workflows', basic: false, pro: false, premium: true),
      const _PlanFeature(name: 'Enterprise Security & Compliance', basic: false, pro: false, premium: true),
      const _PlanFeature(name: 'Priority Support', basic: false, pro: true, premium: true),
    ];

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF1F2937),
        iconTheme: const IconThemeData(
          color: Color(0xFFFFC72C),
          size: 30,
        ),
        title: const Text(
          'Plan Function List',
          style: TextStyle(
            color: Colors.white,
            fontWeight: FontWeight.bold,
            fontSize: 22,
          ),
        ),
      ),
      body: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              width: double.infinity,
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                gradient: const LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: [Color(0xFFEEF6FF), Color(0xFFDCEBFF)],
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFBFDBFE), width: 1.4),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text(
                    'Plan Comparison Matrix',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w800,
                      color: Color(0xFF1E3A8A),
                    ),
                  ),
                  SizedBox(height: 4),
                  Text(
                    'Tick means feature included in that plan. Cross means not included.',
                    style: TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                      color: Color(0xFF1E3A8A),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: const [
                _LegendChip(label: 'Basic', color: Color(0xFF6B7280)),
                _LegendChip(label: 'Pro', color: Color(0xFF0F766E)),
                _LegendChip(label: 'AI Premium', color: Color(0xFF1D4ED8)),
              ],
            ),
            const SizedBox(height: 12),
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  color: Colors.white,
                  borderRadius: BorderRadius.circular(14),
                  border: Border.all(color: const Color(0xFFE5E7EB)),
                  boxShadow: [
                    BoxShadow(
                      color: const Color(0xFF1D4ED8).withValues(alpha: 0.07),
                      blurRadius: 14,
                      offset: const Offset(0, 6),
                    ),
                  ],
                ),
                child: SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  child: SingleChildScrollView(
                    child: DataTable(
                      headingRowColor: WidgetStateProperty.all(const Color(0xFFF8FAFF)),
                      dataRowMinHeight: 44,
                      dataRowMaxHeight: 58,
                      headingTextStyle: const TextStyle(
                        fontSize: 13,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF111827),
                      ),
                      columns: const [
                        DataColumn(label: Text('Function Name')),
                        DataColumn(label: Text('Basic')),
                        DataColumn(label: Text('Pro')),
                        DataColumn(label: Text('AI Premium')),
                      ],
                      rows: features
                          .asMap()
                          .entries
                          .map((entry) {
                        final index = entry.key;
                        final feature = entry.value;

                        return DataRow(
                          color: WidgetStateProperty.all(
                            index.isEven ? const Color(0xFFFFFFFF) : const Color(0xFFFAFCFF),
                          ),
                          cells: [
                            DataCell(
                              SizedBox(
                                width: 320,
                                child: Text(
                                  feature.name,
                                  style: const TextStyle(
                                    fontSize: 13,
                                    fontWeight: FontWeight.w700,
                                    color: Color(0xFF374151),
                                  ),
                                ),
                              ),
                            ),
                            DataCell(_buildAvailabilityIcon(feature.basic)),
                            DataCell(_buildAvailabilityIcon(feature.pro)),
                            DataCell(_buildAvailabilityIcon(feature.premium)),
                          ],
                        );
                      })
                          .toList(),
                    ),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  static Widget _buildAvailabilityIcon(bool enabled) {
    return Center(
      child: Container(
        width: 24,
        height: 24,
        decoration: BoxDecoration(
          color: enabled ? const Color(0xFFE9FBEF) : const Color(0xFFFEECEC),
          borderRadius: BorderRadius.circular(999),
        ),
        child: Icon(
          enabled ? Icons.check_rounded : Icons.close_rounded,
          color: enabled ? const Color(0xFF16A34A) : const Color(0xFFDC2626),
          size: 16,
        ),
      ),
    );
  }
}

class _LegendChip extends StatelessWidget {
  final String label;
  final Color color;

  const _LegendChip({required this.label, required this.color});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: color.withValues(alpha: 0.35)),
      ),
      child: Text(
        label,
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w800,
          color: color,
        ),
      ),
    );
  }
}

class _PlanFeature {
  final String name;
  final bool basic;
  final bool pro;
  final bool premium;

  const _PlanFeature({
    required this.name,
    required this.basic,
    required this.pro,
    required this.premium,
  });
}
