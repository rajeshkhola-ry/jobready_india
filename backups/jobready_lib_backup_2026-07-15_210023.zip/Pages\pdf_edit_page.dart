import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart' as sfpdf;

import '../Services/file_picker_service.dart';
import '../Services/file_storage_service.dart';
import '../Services/pdf_ocr_service.dart';
import '../Widgets/download_result_dialog.dart';

class PdfEditPage extends StatefulWidget {
  final String? initialFileName;
  final Uint8List? initialBytes;

  const PdfEditPage({
    super.key,
    this.initialFileName,
    this.initialBytes,
  });

  @override
  State<PdfEditPage> createState() => _PdfEditPageState();
}

class _PdfEditPageState extends State<PdfEditPage> {
  Uint8List? _selectedBytes;
  String? _selectedName;
  bool _isSaving = false;
  bool _isLoadingText = false;
  String _loadStatus = 'Ready';

  final TextEditingController _editorController = TextEditingController();
  final PdfOcrService _ocrService = const PdfOcrService();

  @override
  void initState() {
    super.initState();
    _selectedBytes = widget.initialBytes;
    _selectedName = widget.initialFileName;

    // If no initial file provided, check for previously uploaded files
    if (_selectedBytes == null) {
      final storedFile = FileStorageService.getLatestFile();
      if (storedFile != null && _isPdfFile(storedFile.name)) {
        _selectedBytes = storedFile.getBytes();
        _selectedName = storedFile.name;
        _loadStatus = 'Loaded previously uploaded file: ${storedFile.name}';
      }
    }

    if (_selectedBytes != null) {
      _loadPdfTextIntoEditor();
    }
  }

  @override
  void dispose() {
    _editorController.dispose();
    super.dispose();
  }

  Future<void> _pickPdf() async {
    final files = await FilePickerService.pickMultipleFileData(
      allowedExtensions: const ['pdf'],
    );

    if (files.isEmpty) {
      return;
    }

    setState(() {
      _selectedBytes = files.first.bytes;
      _selectedName = files.first.name;
      _loadStatus = 'PDF selected. Ready to load text or OCR.';
    });

    await _loadPdfTextIntoEditor();
  }

  Future<void> _loadPdfTextIntoEditor({bool forceOcr = false}) async {
    if (_selectedBytes == null) {
      return;
    }

    setState(() {
      _isLoadingText = true;
    });

    try {
      final result = await _ocrService.extractText(
        pdfBytes: _selectedBytes!,
        fileName: _selectedName ?? 'document.pdf',
        forceOcr: forceOcr,
      );

      if (result.success) {
        _editorController.text = result.text;
        _loadStatus = result.message;
      } else {
        _editorController.text = '';
        _loadStatus = result.message;
      }

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(_loadStatus)),
        );
      }
    } catch (e) {
      _editorController.text = '';
      _loadStatus = 'Unable to load text: $e';
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(_loadStatus)),
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isLoadingText = false;
        });
      }
    }
  }

  Future<void> _extractTables() async {
    if (_selectedBytes == null || _selectedName == null) return;
    setState(() {
      _isLoadingText = true;
      _loadStatus = 'Extracting tables and form data...';
    });
    try {
      final result = await _ocrService.extractText(
        pdfBytes: _selectedBytes!,
        fileName: _selectedName!,
        mode: PdfExtractionMode.tableAware,
      );
      _editorController.text = result.success && result.text.trim().isNotEmpty
          ? result.text
          : 'No table or form content found in this PDF.';
      _loadStatus = result.message;
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_loadStatus)));
      }
    } catch (e) {
      _loadStatus = 'Table extraction failed: $e';
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_loadStatus)));
      }
    } finally {
      if (mounted) setState(() => _isLoadingText = false);
    }
  }

  Future<void> _saveEditedPdf() async {
    if (_selectedBytes == null || _selectedName == null) {
      return;
    }

    final editedText = _editorController.text.trim();
    if (editedText.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please edit or enter text before saving.')),
      );
      return;
    }

    setState(() {
      _isSaving = true;
    });

    try {
      final outputDocument = sfpdf.PdfDocument();
      try {
        final page = outputDocument.pages.add();
        final bodyFont = sfpdf.PdfStandardFont(sfpdf.PdfFontFamily.helvetica, 11);

        final textElement = sfpdf.PdfTextElement(
          text: editedText,
          font: bodyFont,
          brush: sfpdf.PdfSolidBrush(sfpdf.PdfColor(17, 24, 39)),
        );
        textElement.draw(
          page: page,
          bounds: Rect.fromLTWH(20, 20, page.size.width - 40, page.size.height - 40),
          format: sfpdf.PdfLayoutFormat(layoutType: sfpdf.PdfLayoutType.paginate),
        );

        final bytes = Uint8List.fromList(outputDocument.saveSync());
        final outputName =
            _selectedName!.replaceAll(RegExp(r'\.pdf$', caseSensitive: false), '_edited.pdf');

        if (!mounted) return;

        setState(() {
          _isSaving = false;
        });

        await showDialog(
          context: context,
          builder: (_) => DownloadResultDialog(
            outputFormat: 'Edited PDF',
            fileName: outputName,
            outputBytes: bytes,
          ),
        );
      } finally {
        outputDocument.dispose();
      }
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _isSaving = false;
      });

      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Unable to edit PDF: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF1F2937),
        iconTheme: const IconThemeData(color: Color(0xFFFFC72C), size: 28),
        title: const Text(
          'PDF to PDF (Edit)',
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ElevatedButton.icon(
            onPressed: _pickPdf,
            icon: const Icon(Icons.upload_file_rounded),
            label: Text(_selectedName == null ? 'Upload PDF' : 'Change PDF'),
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: (_selectedBytes == null || _isLoadingText)
                      ? null
                      : () => _loadPdfTextIntoEditor(forceOcr: false),
                  icon: const Icon(Icons.text_snippet_outlined, size: 18),
                  label: const Text('Load Text'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: (_selectedBytes == null || _isLoadingText)
                      ? null
                      : () => _loadPdfTextIntoEditor(forceOcr: true),
                  icon: const Icon(Icons.document_scanner_outlined, size: 18),
                  label: const Text('Run OCR'),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: OutlinedButton.icon(
                  onPressed: (_selectedBytes == null || _isLoadingText)
                      ? null
                      : _extractTables,
                  icon: const Icon(Icons.table_chart_outlined, size: 18),
                  label: const Text('Tables'),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          if (_selectedName != null)
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: const Color(0xFFEFF6FF),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: const Color(0xFFBFDBFE)),
              ),
              child: Text(
                'Editing: $_selectedName',
                style: const TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF1E3A8A)),
              ),
            ),
          const SizedBox(height: 8),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0xFFF8FAFC),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: const Color(0xFFE2E8F0)),
            ),
            child: Text(
              'Text/OCR status: $_loadStatus',
              style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Color(0xFF334155)),
            ),
          ),
          const SizedBox(height: 14),
          const Text(
            'PDF Edit and OCR Workspace',
            style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800, color: Color(0xFF1E3A8A)),
          ),
          const SizedBox(height: 8),
          if (_isLoadingText)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 24),
              child: Center(child: CircularProgressIndicator()),
            )
          else
            TextField(
              controller: _editorController,
              minLines: 12,
              maxLines: 20,
              decoration: const InputDecoration(
                labelText: 'Edit text manually here (multiple changes in one shot)',
                border: OutlineInputBorder(),
                alignLabelWithHint: true,
              ),
            ),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              color: const Color(0xFFFFFBEB),
              borderRadius: BorderRadius.circular(10),
              border: Border.all(color: const Color(0xFFFCD34D)),
            ),
            child: const Text(
              'Upload PDF -> Load Text or Run OCR -> edit manually -> save/download as PDF.',
              style: TextStyle(fontSize: 12, fontWeight: FontWeight.w700, color: Color(0xFF92400E)),
            ),
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: (_selectedBytes == null || _isSaving) ? null : _saveEditedPdf,
            icon: _isSaving
                ? const SizedBox(width: 16, height: 16, child: CircularProgressIndicator(strokeWidth: 2))
                : const Icon(Icons.save_alt_rounded),
            label: Text(_isSaving ? 'Saving Edited PDF...' : 'Save & Download Edited PDF'),
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xFF1F4E79),
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 12),
            ),
          ),
        ],
      ),
    );
  }

  bool _isPdfFile(String fileName) {
    return fileName.toLowerCase().endsWith('.pdf');
  }
}
